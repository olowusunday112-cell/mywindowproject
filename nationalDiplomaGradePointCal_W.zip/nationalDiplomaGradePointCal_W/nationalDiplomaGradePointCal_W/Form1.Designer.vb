﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlMainMenu = New Guna.UI2.WinForms.Guna2Panel()
        Me.btnND2 = New Guna.UI2.WinForms.Guna2Button()
        Me.btnND1 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.pnlND1Semesters = New Guna.UI2.WinForms.Guna2Panel()
        Me.btnBackToMain = New Guna.UI2.WinForms.Guna2Button()
        Me.btnSecondSemester = New Guna.UI2.WinForms.Guna2Button()
        Me.btnFirstSemester = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.pnlND1_S1_Calculator = New Guna.UI2.WinForms.Guna2Panel()
        Me.btnClear = New Guna.UI2.WinForms.Guna2Button()
        Me.btnExit = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel13 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel12 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel11 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel10 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.grade_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.gradePoint_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.totalScorePoint_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.GRPCOURSEUNIT = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2Button18 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button17 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button16 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button15 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button12 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button11 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button10 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button9 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button8 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button7 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button6 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button5 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button2 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button13 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button14 = New Guna.UI2.WinForms.Guna2Button()
        Me.calculatebtn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel9 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.gns111_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel8 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.gns101_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.com115_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com114_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com113_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com112_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com111_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.aa = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.mth111_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.btnBackToSemester = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button20 = New Guna.UI2.WinForms.Guna2Button()
        Me.pnlND1_S2_Calculator = New Guna.UI2.WinForms.Guna2Panel()
        Me.gns121_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel27 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.com125_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel26 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.btnBackToChoice_S2 = New Guna.UI2.WinForms.Guna2Button()
        Me.btnClear_S2 = New Guna.UI2.WinForms.Guna2Button()
        Me.btnExit_S2 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel14 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel15 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel16 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel17 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.grade_txt_S2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.gradePoint_txt_S2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.totalScorePoint_txt_S2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.btnCalculate = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel18 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.gns228_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel19 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.eed126_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel20 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.com126_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com124_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com123_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com122_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com121_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel21 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel22 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel23 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel24 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel25 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.gns102_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel29 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.pnlND2Semesters = New Guna.UI2.WinForms.Guna2Panel()
        Me.btnBackToMain_ND2 = New Guna.UI2.WinForms.Guna2Button()
        Me.btnND2SecondSemester = New Guna.UI2.WinForms.Guna2Button()
        Me.btnND2FirstSemester = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel28 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.pnlND2_S2_Calculator = New Guna.UI2.WinForms.Guna2Panel()
        Me.btnClear_ND2S2 = New Guna.UI2.WinForms.Guna2Button()
        Me.btnExit_ND2S2 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel30 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel31 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel32 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel33 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.grade_txt_NDS2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.gradePoint_txt_ND2S2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.totalScorePoint_txt_ND2S2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox2 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2Button43 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button44 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button45 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button46 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button47 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button48 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button50 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button51 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button52 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button53 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button54 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button55 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button56 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button57 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button58 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button49 = New Guna.UI2.WinForms.Guna2Button()
        Me.btnCalculateND2S2 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel34 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.com229_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel35 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.com226_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel36 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.com225_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com224_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com223_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com222_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com221_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel37 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel38 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel39 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel40 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel41 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.gns202_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.btnBack_ND2S2 = New Guna.UI2.WinForms.Guna2Button()
        Me.pnlND2_S1_Calculator = New Guna.UI2.WinForms.Guna2Panel()
        Me.com215_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel54 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.btnClear_ND2S1 = New Guna.UI2.WinForms.Guna2Button()
        Me.btnExit_ND2S1 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel42 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel43 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel44 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel45 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.grade_txt_ND2S1 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.gradePoint_txt_ND2S1 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.totalScorePoint_txt_ND2S1 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2Button62 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button61 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button23 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button24 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button25 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button26 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button27 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button28 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button29 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button30 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button31 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button32 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button33 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button34 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button35 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button36 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button38 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button39 = New Guna.UI2.WinForms.Guna2Button()
        Me.btnCalculateND2S1 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel46 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.gns201_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel47 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.eed216_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel48 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.com216_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com214_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com213_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com212_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.com211_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel49 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel50 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel51 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel52 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel53 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.sws210_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.btnBack_ND2S1 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Button3 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button19 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel55 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel56 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel57 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel58 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2TextBox12 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox13 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox14 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox3 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2Button21 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button22 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button40 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button41 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button63 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button64 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button65 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button66 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button67 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button68 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button69 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button70 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button71 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button72 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button73 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button74 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button75 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel59 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2TextBox15 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel60 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2TextBox16 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel61 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2TextBox17 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox18 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox19 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox20 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox21 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel62 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel63 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel64 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel65 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel66 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2TextBox22 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2Button76 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2GroupBox4 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2Button4 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button37 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button42 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button59 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button60 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button77 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button78 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button79 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button80 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button81 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button82 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button83 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button84 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button85 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button86 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button87 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button88 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button89 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button90 = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button91 = New Guna.UI2.WinForms.Guna2Button()
        Me.pnlMainMenu.SuspendLayout()
        Me.pnlND1Semesters.SuspendLayout()
        Me.pnlND1_S1_Calculator.SuspendLayout()
        Me.GRPCOURSEUNIT.SuspendLayout()
        Me.pnlND1_S2_Calculator.SuspendLayout()
        Me.pnlND2Semesters.SuspendLayout()
        Me.pnlND2_S2_Calculator.SuspendLayout()
        Me.Guna2GroupBox2.SuspendLayout()
        Me.pnlND2_S1_Calculator.SuspendLayout()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.Guna2Panel2.SuspendLayout()
        Me.Guna2GroupBox3.SuspendLayout()
        Me.Guna2GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlMainMenu
        '
        Me.pnlMainMenu.BackColor = System.Drawing.Color.Silver
        Me.pnlMainMenu.BorderRadius = 20
        Me.pnlMainMenu.Controls.Add(Me.btnND2)
        Me.pnlMainMenu.Controls.Add(Me.btnND1)
        Me.pnlMainMenu.Controls.Add(Me.Guna2HtmlLabel1)
        Me.pnlMainMenu.Location = New System.Drawing.Point(4, 9)
        Me.pnlMainMenu.Name = "pnlMainMenu"
        Me.pnlMainMenu.ShadowDecoration.Parent = Me.pnlMainMenu
        Me.pnlMainMenu.Size = New System.Drawing.Size(1310, 619)
        Me.pnlMainMenu.TabIndex = 0
        '
        'btnND2
        '
        Me.btnND2.BorderRadius = 10
        Me.btnND2.CheckedState.Parent = Me.btnND2
        Me.btnND2.CustomImages.Parent = Me.btnND2
        Me.btnND2.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btnND2.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnND2.ForeColor = System.Drawing.Color.White
        Me.btnND2.HoverState.Parent = Me.btnND2
        Me.btnND2.Location = New System.Drawing.Point(680, 225)
        Me.btnND2.Name = "btnND2"
        Me.btnND2.ShadowDecoration.Parent = Me.btnND2
        Me.btnND2.Size = New System.Drawing.Size(180, 45)
        Me.btnND2.TabIndex = 2
        Me.btnND2.Text = "CALCULATE ND2"
        '
        'btnND1
        '
        Me.btnND1.BorderRadius = 10
        Me.btnND1.CheckedState.Parent = Me.btnND1
        Me.btnND1.CustomImages.Parent = Me.btnND1
        Me.btnND1.FillColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnND1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnND1.ForeColor = System.Drawing.Color.White
        Me.btnND1.HoverState.Parent = Me.btnND1
        Me.btnND1.Location = New System.Drawing.Point(314, 225)
        Me.btnND1.Name = "btnND1"
        Me.btnND1.ShadowDecoration.Parent = Me.btnND1
        Me.btnND1.Size = New System.Drawing.Size(180, 45)
        Me.btnND1.TabIndex = 1
        Me.btnND1.Text = "CALCULATE ND1"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.Navy
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(327, 89)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(576, 33)
        Me.Guna2HtmlLabel1.TabIndex = 0
        Me.Guna2HtmlLabel1.Text = "NATIONAL DIPLOMA CGPA CALCULATOR"
        Me.Guna2HtmlLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlND1Semesters
        '
        Me.pnlND1Semesters.BackColor = System.Drawing.Color.Silver
        Me.pnlND1Semesters.Controls.Add(Me.btnBackToMain)
        Me.pnlND1Semesters.Controls.Add(Me.btnSecondSemester)
        Me.pnlND1Semesters.Controls.Add(Me.btnFirstSemester)
        Me.pnlND1Semesters.Controls.Add(Me.Guna2HtmlLabel2)
        Me.pnlND1Semesters.Location = New System.Drawing.Point(2, 11)
        Me.pnlND1Semesters.Name = "pnlND1Semesters"
        Me.pnlND1Semesters.ShadowDecoration.Parent = Me.pnlND1Semesters
        Me.pnlND1Semesters.Size = New System.Drawing.Size(1319, 619)
        Me.pnlND1Semesters.TabIndex = 3
        Me.pnlND1Semesters.Visible = False
        '
        'btnBackToMain
        '
        Me.btnBackToMain.BorderRadius = 15
        Me.btnBackToMain.CheckedState.Parent = Me.btnBackToMain
        Me.btnBackToMain.CustomImages.Parent = Me.btnBackToMain
        Me.btnBackToMain.FillColor = System.Drawing.Color.Gray
        Me.btnBackToMain.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackToMain.ForeColor = System.Drawing.Color.White
        Me.btnBackToMain.HoverState.Parent = Me.btnBackToMain
        Me.btnBackToMain.Location = New System.Drawing.Point(536, 309)
        Me.btnBackToMain.Name = "btnBackToMain"
        Me.btnBackToMain.ShadowDecoration.Parent = Me.btnBackToMain
        Me.btnBackToMain.Size = New System.Drawing.Size(267, 45)
        Me.btnBackToMain.TabIndex = 3
        Me.btnBackToMain.Text = "BACK TO MAIN  MENU"
        '
        'btnSecondSemester
        '
        Me.btnSecondSemester.BorderRadius = 15
        Me.btnSecondSemester.CheckedState.Parent = Me.btnSecondSemester
        Me.btnSecondSemester.CustomImages.Parent = Me.btnSecondSemester
        Me.btnSecondSemester.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btnSecondSemester.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSecondSemester.ForeColor = System.Drawing.Color.White
        Me.btnSecondSemester.HoverState.Parent = Me.btnSecondSemester
        Me.btnSecondSemester.Location = New System.Drawing.Point(777, 184)
        Me.btnSecondSemester.Name = "btnSecondSemester"
        Me.btnSecondSemester.ShadowDecoration.Parent = Me.btnSecondSemester
        Me.btnSecondSemester.Size = New System.Drawing.Size(197, 45)
        Me.btnSecondSemester.TabIndex = 2
        Me.btnSecondSemester.Text = "SECOND SEMESTER"
        '
        'btnFirstSemester
        '
        Me.btnFirstSemester.BorderRadius = 15
        Me.btnFirstSemester.CheckedState.Parent = Me.btnFirstSemester
        Me.btnFirstSemester.CustomImages.Parent = Me.btnFirstSemester
        Me.btnFirstSemester.FillColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnFirstSemester.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFirstSemester.ForeColor = System.Drawing.Color.White
        Me.btnFirstSemester.HoverState.Parent = Me.btnFirstSemester
        Me.btnFirstSemester.Location = New System.Drawing.Point(347, 205)
        Me.btnFirstSemester.Name = "btnFirstSemester"
        Me.btnFirstSemester.ShadowDecoration.Parent = Me.btnFirstSemester
        Me.btnFirstSemester.Size = New System.Drawing.Size(186, 45)
        Me.btnFirstSemester.TabIndex = 1
        Me.btnFirstSemester.Text = "FIRST SEMESTER"
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(477, 88)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(335, 27)
        Me.Guna2HtmlLabel2.TabIndex = 0
        Me.Guna2HtmlLabel2.Text = "SELECT SEMESTER FOR ND 1"
        '
        'pnlND1_S1_Calculator
        '
        Me.pnlND1_S1_Calculator.BackColor = System.Drawing.Color.Silver
        Me.pnlND1_S1_Calculator.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.pnlND1_S1_Calculator.Controls.Add(Me.btnClear)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.btnExit)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel13)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel12)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel11)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel10)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.grade_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.gradePoint_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.totalScorePoint_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.GRPCOURSEUNIT)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.calculatebtn)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel9)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.gns111_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel8)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.gns101_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel7)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.com115_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.com114_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.com113_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.com112_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.com111_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel6)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel5)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel4)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel3)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.aa)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.mth111_txt)
        Me.pnlND1_S1_Calculator.Controls.Add(Me.btnBackToSemester)
        Me.pnlND1_S1_Calculator.Location = New System.Drawing.Point(3, 12)
        Me.pnlND1_S1_Calculator.Name = "pnlND1_S1_Calculator"
        Me.pnlND1_S1_Calculator.ShadowDecoration.Parent = Me.pnlND1_S1_Calculator
        Me.pnlND1_S1_Calculator.Size = New System.Drawing.Size(1320, 619)
        Me.pnlND1_S1_Calculator.TabIndex = 4
        Me.pnlND1_S1_Calculator.Visible = False
        '
        'btnClear
        '
        Me.btnClear.CheckedState.Parent = Me.btnClear
        Me.btnClear.CustomImages.Parent = Me.btnClear
        Me.btnClear.FillColor = System.Drawing.Color.DarkOrange
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.HoverState.Parent = Me.btnClear
        Me.btnClear.Location = New System.Drawing.Point(1214, 551)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.ShadowDecoration.Parent = Me.btnClear
        Me.btnClear.Size = New System.Drawing.Size(90, 45)
        Me.btnClear.TabIndex = 36
        Me.btnClear.Text = "CLEAR"
        '
        'btnExit
        '
        Me.btnExit.CheckedState.Parent = Me.btnExit
        Me.btnExit.CustomImages.Parent = Me.btnExit
        Me.btnExit.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnExit.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.HoverState.Parent = Me.btnExit
        Me.btnExit.Location = New System.Drawing.Point(1056, 551)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.ShadowDecoration.Parent = Me.btnExit
        Me.btnExit.Size = New System.Drawing.Size(90, 45)
        Me.btnExit.TabIndex = 35
        Me.btnExit.Text = "EXIT"
        '
        'Guna2HtmlLabel13
        '
        Me.Guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel13.ForeColor = System.Drawing.Color.Navy
        Me.Guna2HtmlLabel13.Location = New System.Drawing.Point(457, 34)
        Me.Guna2HtmlLabel13.Name = "Guna2HtmlLabel13"
        Me.Guna2HtmlLabel13.Size = New System.Drawing.Size(197, 22)
        Me.Guna2HtmlLabel13.TabIndex = 34
        Me.Guna2HtmlLabel13.Text = "ND1 FIRST SEMESTER"
        '
        'Guna2HtmlLabel12
        '
        Me.Guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel12.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel12.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel12.Location = New System.Drawing.Point(605, 493)
        Me.Guna2HtmlLabel12.Name = "Guna2HtmlLabel12"
        Me.Guna2HtmlLabel12.Size = New System.Drawing.Size(191, 20)
        Me.Guna2HtmlLabel12.TabIndex = 33
        Me.Guna2HtmlLabel12.Text = "TOTAL SCORE POINT:  <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel11
        '
        Me.Guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel11.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel11.Location = New System.Drawing.Point(323, 493)
        Me.Guna2HtmlLabel11.Name = "Guna2HtmlLabel11"
        Me.Guna2HtmlLabel11.Size = New System.Drawing.Size(133, 20)
        Me.Guna2HtmlLabel11.TabIndex = 32
        Me.Guna2HtmlLabel11.Text = "GRADE POINT: <fore color = ""red"">*</fore color/>"
        Me.Guna2HtmlLabel11.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Guna2HtmlLabel10
        '
        Me.Guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel10.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel10.Location = New System.Drawing.Point(50, 493)
        Me.Guna2HtmlLabel10.Name = "Guna2HtmlLabel10"
        Me.Guna2HtmlLabel10.Size = New System.Drawing.Size(78, 20)
        Me.Guna2HtmlLabel10.TabIndex = 31
        Me.Guna2HtmlLabel10.Text = "GRADE: <fore color = ""red"">*</fore color/>"
        '
        'grade_txt
        '
        Me.grade_txt.BackColor = System.Drawing.Color.White
        Me.grade_txt.BorderRadius = 10
        Me.grade_txt.BorderThickness = 0
        Me.grade_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.grade_txt.DefaultText = ""
        Me.grade_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.grade_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.grade_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.grade_txt.DisabledState.Parent = Me.grade_txt
        Me.grade_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.grade_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grade_txt.FocusedState.Parent = Me.grade_txt
        Me.grade_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grade_txt.ForeColor = System.Drawing.Color.Black
        Me.grade_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grade_txt.HoverState.Parent = Me.grade_txt
        Me.grade_txt.Location = New System.Drawing.Point(37, 538)
        Me.grade_txt.Name = "grade_txt"
        Me.grade_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.grade_txt.PlaceholderText = ""
        Me.grade_txt.SelectedText = ""
        Me.grade_txt.ShadowDecoration.Parent = Me.grade_txt
        Me.grade_txt.Size = New System.Drawing.Size(200, 36)
        Me.grade_txt.TabIndex = 30
        '
        'gradePoint_txt
        '
        Me.gradePoint_txt.BackColor = System.Drawing.Color.White
        Me.gradePoint_txt.BorderRadius = 10
        Me.gradePoint_txt.BorderThickness = 0
        Me.gradePoint_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gradePoint_txt.DefaultText = ""
        Me.gradePoint_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gradePoint_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gradePoint_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gradePoint_txt.DisabledState.Parent = Me.gradePoint_txt
        Me.gradePoint_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gradePoint_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gradePoint_txt.FocusedState.Parent = Me.gradePoint_txt
        Me.gradePoint_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gradePoint_txt.ForeColor = System.Drawing.Color.Black
        Me.gradePoint_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gradePoint_txt.HoverState.Parent = Me.gradePoint_txt
        Me.gradePoint_txt.Location = New System.Drawing.Point(323, 538)
        Me.gradePoint_txt.Name = "gradePoint_txt"
        Me.gradePoint_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gradePoint_txt.PlaceholderText = ""
        Me.gradePoint_txt.SelectedText = ""
        Me.gradePoint_txt.ShadowDecoration.Parent = Me.gradePoint_txt
        Me.gradePoint_txt.Size = New System.Drawing.Size(200, 36)
        Me.gradePoint_txt.TabIndex = 29
        '
        'totalScorePoint_txt
        '
        Me.totalScorePoint_txt.BackColor = System.Drawing.Color.White
        Me.totalScorePoint_txt.BorderRadius = 10
        Me.totalScorePoint_txt.BorderThickness = 0
        Me.totalScorePoint_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalScorePoint_txt.DefaultText = ""
        Me.totalScorePoint_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.totalScorePoint_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.totalScorePoint_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalScorePoint_txt.DisabledState.Parent = Me.totalScorePoint_txt
        Me.totalScorePoint_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalScorePoint_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalScorePoint_txt.FocusedState.Parent = Me.totalScorePoint_txt
        Me.totalScorePoint_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalScorePoint_txt.ForeColor = System.Drawing.Color.Black
        Me.totalScorePoint_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalScorePoint_txt.HoverState.Parent = Me.totalScorePoint_txt
        Me.totalScorePoint_txt.Location = New System.Drawing.Point(605, 538)
        Me.totalScorePoint_txt.Name = "totalScorePoint_txt"
        Me.totalScorePoint_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.totalScorePoint_txt.PlaceholderText = ""
        Me.totalScorePoint_txt.SelectedText = ""
        Me.totalScorePoint_txt.ShadowDecoration.Parent = Me.totalScorePoint_txt
        Me.totalScorePoint_txt.Size = New System.Drawing.Size(200, 36)
        Me.totalScorePoint_txt.TabIndex = 28
        '
        'GRPCOURSEUNIT
        '
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button18)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button17)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button16)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button15)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button12)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button11)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button10)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button9)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button8)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button7)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button6)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button5)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button1)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button2)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button13)
        Me.GRPCOURSEUNIT.Controls.Add(Me.Guna2Button14)
        Me.GRPCOURSEUNIT.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GRPCOURSEUNIT.ForeColor = System.Drawing.Color.Black
        Me.GRPCOURSEUNIT.Location = New System.Drawing.Point(1000, 34)
        Me.GRPCOURSEUNIT.Name = "GRPCOURSEUNIT"
        Me.GRPCOURSEUNIT.ShadowDecoration.Parent = Me.GRPCOURSEUNIT
        Me.GRPCOURSEUNIT.Size = New System.Drawing.Size(300, 484)
        Me.GRPCOURSEUNIT.TabIndex = 27
        Me.GRPCOURSEUNIT.Text = " COURSE UNIT"
        '
        'Guna2Button18
        '
        Me.Guna2Button18.CheckedState.Parent = Me.Guna2Button18
        Me.Guna2Button18.CustomImages.Parent = Me.Guna2Button18
        Me.Guna2Button18.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button18.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button18.ForeColor = System.Drawing.Color.White
        Me.Guna2Button18.HoverState.Parent = Me.Guna2Button18
        Me.Guna2Button18.Location = New System.Drawing.Point(214, 432)
        Me.Guna2Button18.Name = "Guna2Button18"
        Me.Guna2Button18.ShadowDecoration.Parent = Me.Guna2Button18
        Me.Guna2Button18.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button18.TabIndex = 15
        Me.Guna2Button18.Text = "2"
        '
        'Guna2Button17
        '
        Me.Guna2Button17.CheckedState.Parent = Me.Guna2Button17
        Me.Guna2Button17.CustomImages.Parent = Me.Guna2Button17
        Me.Guna2Button17.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button17.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button17.ForeColor = System.Drawing.Color.White
        Me.Guna2Button17.HoverState.Parent = Me.Guna2Button17
        Me.Guna2Button17.Location = New System.Drawing.Point(214, 379)
        Me.Guna2Button17.Name = "Guna2Button17"
        Me.Guna2Button17.ShadowDecoration.Parent = Me.Guna2Button17
        Me.Guna2Button17.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button17.TabIndex = 14
        Me.Guna2Button17.Text = "2"
        '
        'Guna2Button16
        '
        Me.Guna2Button16.CheckedState.Parent = Me.Guna2Button16
        Me.Guna2Button16.CustomImages.Parent = Me.Guna2Button16
        Me.Guna2Button16.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button16.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button16.ForeColor = System.Drawing.Color.White
        Me.Guna2Button16.HoverState.Parent = Me.Guna2Button16
        Me.Guna2Button16.Location = New System.Drawing.Point(12, 434)
        Me.Guna2Button16.Name = "Guna2Button16"
        Me.Guna2Button16.ShadowDecoration.Parent = Me.Guna2Button16
        Me.Guna2Button16.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button16.TabIndex = 13
        Me.Guna2Button16.Text = "MTH111"
        '
        'Guna2Button15
        '
        Me.Guna2Button15.CheckedState.Parent = Me.Guna2Button15
        Me.Guna2Button15.CustomImages.Parent = Me.Guna2Button15
        Me.Guna2Button15.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button15.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button15.ForeColor = System.Drawing.Color.White
        Me.Guna2Button15.HoverState.Parent = Me.Guna2Button15
        Me.Guna2Button15.Location = New System.Drawing.Point(12, 379)
        Me.Guna2Button15.Name = "Guna2Button15"
        Me.Guna2Button15.ShadowDecoration.Parent = Me.Guna2Button15
        Me.Guna2Button15.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button15.TabIndex = 12
        Me.Guna2Button15.Text = "GNS111"
        '
        'Guna2Button12
        '
        Me.Guna2Button12.CheckedState.Parent = Me.Guna2Button12
        Me.Guna2Button12.CustomImages.Parent = Me.Guna2Button12
        Me.Guna2Button12.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button12.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button12.ForeColor = System.Drawing.Color.White
        Me.Guna2Button12.HoverState.Parent = Me.Guna2Button12
        Me.Guna2Button12.Location = New System.Drawing.Point(214, 103)
        Me.Guna2Button12.Name = "Guna2Button12"
        Me.Guna2Button12.ShadowDecoration.Parent = Me.Guna2Button12
        Me.Guna2Button12.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button12.TabIndex = 11
        Me.Guna2Button12.Text = "3"
        '
        'Guna2Button11
        '
        Me.Guna2Button11.CheckedState.Parent = Me.Guna2Button11
        Me.Guna2Button11.CustomImages.Parent = Me.Guna2Button11
        Me.Guna2Button11.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button11.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button11.ForeColor = System.Drawing.Color.White
        Me.Guna2Button11.HoverState.Parent = Me.Guna2Button11
        Me.Guna2Button11.Location = New System.Drawing.Point(214, 154)
        Me.Guna2Button11.Name = "Guna2Button11"
        Me.Guna2Button11.ShadowDecoration.Parent = Me.Guna2Button11
        Me.Guna2Button11.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button11.TabIndex = 10
        Me.Guna2Button11.Text = "3"
        '
        'Guna2Button10
        '
        Me.Guna2Button10.CheckedState.Parent = Me.Guna2Button10
        Me.Guna2Button10.CustomImages.Parent = Me.Guna2Button10
        Me.Guna2Button10.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button10.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button10.ForeColor = System.Drawing.Color.White
        Me.Guna2Button10.HoverState.Parent = Me.Guna2Button10
        Me.Guna2Button10.Location = New System.Drawing.Point(214, 208)
        Me.Guna2Button10.Name = "Guna2Button10"
        Me.Guna2Button10.ShadowDecoration.Parent = Me.Guna2Button10
        Me.Guna2Button10.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button10.TabIndex = 9
        Me.Guna2Button10.Text = "2"
        '
        'Guna2Button9
        '
        Me.Guna2Button9.CheckedState.Parent = Me.Guna2Button9
        Me.Guna2Button9.CustomImages.Parent = Me.Guna2Button9
        Me.Guna2Button9.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button9.ForeColor = System.Drawing.Color.White
        Me.Guna2Button9.HoverState.Parent = Me.Guna2Button9
        Me.Guna2Button9.Location = New System.Drawing.Point(214, 263)
        Me.Guna2Button9.Name = "Guna2Button9"
        Me.Guna2Button9.ShadowDecoration.Parent = Me.Guna2Button9
        Me.Guna2Button9.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button9.TabIndex = 8
        Me.Guna2Button9.Text = "3"
        '
        'Guna2Button8
        '
        Me.Guna2Button8.CheckedState.Parent = Me.Guna2Button8
        Me.Guna2Button8.CustomImages.Parent = Me.Guna2Button8
        Me.Guna2Button8.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button8.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button8.ForeColor = System.Drawing.Color.White
        Me.Guna2Button8.HoverState.Parent = Me.Guna2Button8
        Me.Guna2Button8.Location = New System.Drawing.Point(214, 319)
        Me.Guna2Button8.Name = "Guna2Button8"
        Me.Guna2Button8.ShadowDecoration.Parent = Me.Guna2Button8
        Me.Guna2Button8.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button8.TabIndex = 7
        Me.Guna2Button8.Text = "2"
        '
        'Guna2Button7
        '
        Me.Guna2Button7.CheckedState.Parent = Me.Guna2Button7
        Me.Guna2Button7.CustomImages.Parent = Me.Guna2Button7
        Me.Guna2Button7.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button7.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button7.ForeColor = System.Drawing.Color.White
        Me.Guna2Button7.HoverState.Parent = Me.Guna2Button7
        Me.Guna2Button7.Location = New System.Drawing.Point(214, 52)
        Me.Guna2Button7.Name = "Guna2Button7"
        Me.Guna2Button7.ShadowDecoration.Parent = Me.Guna2Button7
        Me.Guna2Button7.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button7.TabIndex = 6
        Me.Guna2Button7.Text = "3"
        '
        'Guna2Button6
        '
        Me.Guna2Button6.CheckedState.Parent = Me.Guna2Button6
        Me.Guna2Button6.CustomImages.Parent = Me.Guna2Button6
        Me.Guna2Button6.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button6.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button6.ForeColor = System.Drawing.Color.White
        Me.Guna2Button6.HoverState.Parent = Me.Guna2Button6
        Me.Guna2Button6.Location = New System.Drawing.Point(12, 321)
        Me.Guna2Button6.Name = "Guna2Button6"
        Me.Guna2Button6.ShadowDecoration.Parent = Me.Guna2Button6
        Me.Guna2Button6.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button6.TabIndex = 5
        Me.Guna2Button6.Text = "GNS101"
        '
        'Guna2Button5
        '
        Me.Guna2Button5.CheckedState.Parent = Me.Guna2Button5
        Me.Guna2Button5.CustomImages.Parent = Me.Guna2Button5
        Me.Guna2Button5.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button5.ForeColor = System.Drawing.Color.White
        Me.Guna2Button5.HoverState.Parent = Me.Guna2Button5
        Me.Guna2Button5.Location = New System.Drawing.Point(12, 266)
        Me.Guna2Button5.Name = "Guna2Button5"
        Me.Guna2Button5.ShadowDecoration.Parent = Me.Guna2Button5
        Me.Guna2Button5.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button5.TabIndex = 4
        Me.Guna2Button5.Text = "COM115"
        '
        'Guna2Button1
        '
        Me.Guna2Button1.CheckedState.Parent = Me.Guna2Button1
        Me.Guna2Button1.CustomImages.Parent = Me.Guna2Button1
        Me.Guna2Button1.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button1.ForeColor = System.Drawing.Color.White
        Me.Guna2Button1.HoverState.Parent = Me.Guna2Button1
        Me.Guna2Button1.Location = New System.Drawing.Point(12, 102)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.ShadowDecoration.Parent = Me.Guna2Button1
        Me.Guna2Button1.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button1.TabIndex = 3
        Me.Guna2Button1.Text = "COM112"
        '
        'Guna2Button2
        '
        Me.Guna2Button2.CheckedState.Parent = Me.Guna2Button2
        Me.Guna2Button2.CustomImages.Parent = Me.Guna2Button2
        Me.Guna2Button2.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button2.ForeColor = System.Drawing.Color.White
        Me.Guna2Button2.HoverState.Parent = Me.Guna2Button2
        Me.Guna2Button2.Location = New System.Drawing.Point(12, 157)
        Me.Guna2Button2.Name = "Guna2Button2"
        Me.Guna2Button2.ShadowDecoration.Parent = Me.Guna2Button2
        Me.Guna2Button2.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button2.TabIndex = 2
        Me.Guna2Button2.Text = "COM113"
        '
        'Guna2Button13
        '
        Me.Guna2Button13.CheckedState.Parent = Me.Guna2Button13
        Me.Guna2Button13.CustomImages.Parent = Me.Guna2Button13
        Me.Guna2Button13.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button13.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button13.ForeColor = System.Drawing.Color.White
        Me.Guna2Button13.HoverState.Parent = Me.Guna2Button13
        Me.Guna2Button13.Location = New System.Drawing.Point(12, 212)
        Me.Guna2Button13.Name = "Guna2Button13"
        Me.Guna2Button13.ShadowDecoration.Parent = Me.Guna2Button13
        Me.Guna2Button13.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button13.TabIndex = 1
        Me.Guna2Button13.Text = "COM114"
        '
        'Guna2Button14
        '
        Me.Guna2Button14.CheckedState.Parent = Me.Guna2Button14
        Me.Guna2Button14.CustomImages.Parent = Me.Guna2Button14
        Me.Guna2Button14.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button14.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button14.ForeColor = System.Drawing.Color.White
        Me.Guna2Button14.HoverState.Parent = Me.Guna2Button14
        Me.Guna2Button14.Location = New System.Drawing.Point(12, 47)
        Me.Guna2Button14.Name = "Guna2Button14"
        Me.Guna2Button14.ShadowDecoration.Parent = Me.Guna2Button14
        Me.Guna2Button14.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button14.TabIndex = 0
        Me.Guna2Button14.Text = "COM111"
        '
        'calculatebtn
        '
        Me.calculatebtn.CheckedState.Parent = Me.calculatebtn
        Me.calculatebtn.CustomImages.Parent = Me.calculatebtn
        Me.calculatebtn.FillColor = System.Drawing.Color.Green
        Me.calculatebtn.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calculatebtn.ForeColor = System.Drawing.Color.White
        Me.calculatebtn.HoverState.Parent = Me.calculatebtn
        Me.calculatebtn.Location = New System.Drawing.Point(339, 442)
        Me.calculatebtn.Name = "calculatebtn"
        Me.calculatebtn.ShadowDecoration.Parent = Me.calculatebtn
        Me.calculatebtn.Size = New System.Drawing.Size(180, 45)
        Me.calculatebtn.TabIndex = 26
        Me.calculatebtn.Text = "CALCULATE"
        '
        'Guna2HtmlLabel9
        '
        Me.Guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel9.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel9.Location = New System.Drawing.Point(579, 392)
        Me.Guna2HtmlLabel9.Name = "Guna2HtmlLabel9"
        Me.Guna2HtmlLabel9.Size = New System.Drawing.Size(380, 18)
        Me.Guna2HtmlLabel9.TabIndex = 24
        Me.Guna2HtmlLabel9.Text = "ENTER SCORE FOR    LOGIC AND LINEAR ALGEBRA" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore " & _
            "color/>"
        '
        'gns111_txt
        '
        Me.gns111_txt.BackColor = System.Drawing.Color.White
        Me.gns111_txt.BorderRadius = 10
        Me.gns111_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.gns111_txt.BorderThickness = 0
        Me.gns111_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gns111_txt.DefaultText = ""
        Me.gns111_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gns111_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gns111_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns111_txt.DisabledState.Parent = Me.gns111_txt
        Me.gns111_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns111_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns111_txt.FocusedState.Parent = Me.gns111_txt
        Me.gns111_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gns111_txt.ForeColor = System.Drawing.Color.Black
        Me.gns111_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns111_txt.HoverState.Parent = Me.gns111_txt
        Me.gns111_txt.Location = New System.Drawing.Point(614, 325)
        Me.gns111_txt.Name = "gns111_txt"
        Me.gns111_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gns111_txt.PlaceholderText = ""
        Me.gns111_txt.SelectedText = ""
        Me.gns111_txt.ShadowDecoration.Parent = Me.gns111_txt
        Me.gns111_txt.Size = New System.Drawing.Size(200, 36)
        Me.gns111_txt.TabIndex = 23
        '
        'Guna2HtmlLabel8
        '
        Me.Guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel8.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel8.Location = New System.Drawing.Point(566, 281)
        Me.Guna2HtmlLabel8.Name = "Guna2HtmlLabel8"
        Me.Guna2HtmlLabel8.Size = New System.Drawing.Size(361, 18)
        Me.Guna2HtmlLabel8.TabIndex = 22
        Me.Guna2HtmlLabel8.Text = "ENTER SCORE FOR   CITIZENSHIP EDUCATION I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore colo" & _
            "r/>"
        '
        'gns101_txt
        '
        Me.gns101_txt.BackColor = System.Drawing.Color.White
        Me.gns101_txt.BorderRadius = 10
        Me.gns101_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.gns101_txt.BorderThickness = 0
        Me.gns101_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gns101_txt.DefaultText = ""
        Me.gns101_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gns101_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gns101_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns101_txt.DisabledState.Parent = Me.gns101_txt
        Me.gns101_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns101_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns101_txt.FocusedState.Parent = Me.gns101_txt
        Me.gns101_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gns101_txt.ForeColor = System.Drawing.Color.Black
        Me.gns101_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns101_txt.HoverState.Parent = Me.gns101_txt
        Me.gns101_txt.Location = New System.Drawing.Point(614, 217)
        Me.gns101_txt.Name = "gns101_txt"
        Me.gns101_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gns101_txt.PlaceholderText = ""
        Me.gns101_txt.SelectedText = ""
        Me.gns101_txt.ShadowDecoration.Parent = Me.gns101_txt
        Me.gns101_txt.Size = New System.Drawing.Size(200, 36)
        Me.gns101_txt.TabIndex = 21
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel7.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(579, 176)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(300, 18)
        Me.Guna2HtmlLabel7.TabIndex = 20
        Me.Guna2HtmlLabel7.Text = "ENTER SCORE FOR  USE OF ENGLISH I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>"
        '
        'com115_txt
        '
        Me.com115_txt.BackColor = System.Drawing.Color.White
        Me.com115_txt.BorderRadius = 10
        Me.com115_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com115_txt.BorderThickness = 0
        Me.com115_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com115_txt.DefaultText = ""
        Me.com115_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com115_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com115_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com115_txt.DisabledState.Parent = Me.com115_txt
        Me.com115_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com115_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com115_txt.FocusedState.Parent = Me.com115_txt
        Me.com115_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com115_txt.ForeColor = System.Drawing.Color.Black
        Me.com115_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com115_txt.HoverState.Parent = Me.com115_txt
        Me.com115_txt.Location = New System.Drawing.Point(614, 120)
        Me.com115_txt.Name = "com115_txt"
        Me.com115_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com115_txt.PlaceholderText = ""
        Me.com115_txt.SelectedText = ""
        Me.com115_txt.ShadowDecoration.Parent = Me.com115_txt
        Me.com115_txt.Size = New System.Drawing.Size(200, 36)
        Me.com115_txt.TabIndex = 19
        '
        'com114_txt
        '
        Me.com114_txt.BackColor = System.Drawing.Color.White
        Me.com114_txt.BorderRadius = 10
        Me.com114_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com114_txt.BorderThickness = 0
        Me.com114_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com114_txt.DefaultText = ""
        Me.com114_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com114_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com114_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com114_txt.DisabledState.Parent = Me.com114_txt
        Me.com114_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com114_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com114_txt.FocusedState.Parent = Me.com114_txt
        Me.com114_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com114_txt.ForeColor = System.Drawing.Color.Black
        Me.com114_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com114_txt.HoverState.Parent = Me.com114_txt
        Me.com114_txt.Location = New System.Drawing.Point(37, 430)
        Me.com114_txt.Name = "com114_txt"
        Me.com114_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com114_txt.PlaceholderText = ""
        Me.com114_txt.SelectedText = ""
        Me.com114_txt.ShadowDecoration.Parent = Me.com114_txt
        Me.com114_txt.Size = New System.Drawing.Size(200, 36)
        Me.com114_txt.TabIndex = 18
        '
        'com113_txt
        '
        Me.com113_txt.BackColor = System.Drawing.Color.White
        Me.com113_txt.BorderRadius = 10
        Me.com113_txt.BorderThickness = 0
        Me.com113_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com113_txt.DefaultText = ""
        Me.com113_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com113_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com113_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com113_txt.DisabledState.Parent = Me.com113_txt
        Me.com113_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com113_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com113_txt.FocusedState.Parent = Me.com113_txt
        Me.com113_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com113_txt.ForeColor = System.Drawing.Color.Black
        Me.com113_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com113_txt.HoverState.Parent = Me.com113_txt
        Me.com113_txt.Location = New System.Drawing.Point(37, 325)
        Me.com113_txt.Name = "com113_txt"
        Me.com113_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com113_txt.PlaceholderText = ""
        Me.com113_txt.SelectedText = ""
        Me.com113_txt.ShadowDecoration.Parent = Me.com113_txt
        Me.com113_txt.Size = New System.Drawing.Size(200, 36)
        Me.com113_txt.TabIndex = 17
        '
        'com112_txt
        '
        Me.com112_txt.BackColor = System.Drawing.Color.White
        Me.com112_txt.BorderRadius = 10
        Me.com112_txt.BorderThickness = 0
        Me.com112_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com112_txt.DefaultText = ""
        Me.com112_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com112_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com112_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com112_txt.DisabledState.Parent = Me.com112_txt
        Me.com112_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com112_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com112_txt.FocusedState.Parent = Me.com112_txt
        Me.com112_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com112_txt.ForeColor = System.Drawing.Color.Black
        Me.com112_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com112_txt.HoverState.Parent = Me.com112_txt
        Me.com112_txt.Location = New System.Drawing.Point(37, 230)
        Me.com112_txt.Name = "com112_txt"
        Me.com112_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com112_txt.PlaceholderText = ""
        Me.com112_txt.SelectedText = ""
        Me.com112_txt.ShadowDecoration.Parent = Me.com112_txt
        Me.com112_txt.Size = New System.Drawing.Size(200, 36)
        Me.com112_txt.TabIndex = 16
        '
        'com111_txt
        '
        Me.com111_txt.BackColor = System.Drawing.Color.White
        Me.com111_txt.BorderRadius = 10
        Me.com111_txt.BorderThickness = 0
        Me.com111_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com111_txt.DefaultText = ""
        Me.com111_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com111_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com111_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com111_txt.DisabledState.Parent = Me.com111_txt
        Me.com111_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com111_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com111_txt.FocusedState.Parent = Me.com111_txt
        Me.com111_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com111_txt.ForeColor = System.Drawing.Color.Black
        Me.com111_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com111_txt.HoverState.Parent = Me.com111_txt
        Me.com111_txt.Location = New System.Drawing.Point(37, 120)
        Me.com111_txt.Name = "com111_txt"
        Me.com111_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com111_txt.PlaceholderText = ""
        Me.com111_txt.SelectedText = ""
        Me.com111_txt.ShadowDecoration.Parent = Me.com111_txt
        Me.com111_txt.Size = New System.Drawing.Size(200, 36)
        Me.com111_txt.TabIndex = 15
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(529, 85)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(447, 18)
        Me.Guna2HtmlLabel6.TabIndex = 14
        Me.Guna2HtmlLabel6.Text = "ENTER SCORE FOR COMPUTER APPLICATION PACKAGES I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore co" & _
            "lor/>"
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(13, 392)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(393, 18)
        Me.Guna2HtmlLabel5.TabIndex = 13
        Me.Guna2HtmlLabel5.Text = "ENTER SCORE FOR STATISTICS FOR COMPUTING I " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/" & _
            ">"
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(25, 281)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(422, 18)
        Me.Guna2HtmlLabel4.TabIndex = 11
        Me.Guna2HtmlLabel4.Text = "ENTER SCORE FOR INTRODUCTION TO PROGRAMMING: <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(37, 176)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(475, 18)
        Me.Guna2HtmlLabel3.TabIndex = 9
        Me.Guna2HtmlLabel3.Text = "ENTER SCORE FOR INTRODUCTION TO DIGITAL ELECTRONICS: <fore color = ""red"">*</fore " & _
            "color/>"
        '
        'aa
        '
        Me.aa.BackColor = System.Drawing.Color.Transparent
        Me.aa.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.aa.ForeColor = System.Drawing.Color.Black
        Me.aa.Location = New System.Drawing.Point(25, 85)
        Me.aa.Name = "aa"
        Me.aa.Size = New System.Drawing.Size(398, 18)
        Me.aa.TabIndex = 2
        Me.aa.Text = "ENTER SCORE FOR INTRODUCTION TO COMPUTING: <fore color = ""red"">*</fore color/>"
        '
        'mth111_txt
        '
        Me.mth111_txt.BackColor = System.Drawing.Color.White
        Me.mth111_txt.BorderRadius = 10
        Me.mth111_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.mth111_txt.BorderThickness = 0
        Me.mth111_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.mth111_txt.DefaultText = ""
        Me.mth111_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.mth111_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.mth111_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.mth111_txt.DisabledState.Parent = Me.mth111_txt
        Me.mth111_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.mth111_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.mth111_txt.FocusedState.Parent = Me.mth111_txt
        Me.mth111_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mth111_txt.ForeColor = System.Drawing.Color.Black
        Me.mth111_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.mth111_txt.HoverState.Parent = Me.mth111_txt
        Me.mth111_txt.Location = New System.Drawing.Point(614, 416)
        Me.mth111_txt.Name = "mth111_txt"
        Me.mth111_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.mth111_txt.PlaceholderText = ""
        Me.mth111_txt.SelectedText = ""
        Me.mth111_txt.ShadowDecoration.Parent = Me.mth111_txt
        Me.mth111_txt.Size = New System.Drawing.Size(200, 36)
        Me.mth111_txt.TabIndex = 25
        '
        'btnBackToSemester
        '
        Me.btnBackToSemester.CheckedState.Parent = Me.btnBackToSemester
        Me.btnBackToSemester.CustomImages.Parent = Me.btnBackToSemester
        Me.btnBackToSemester.FillColor = System.Drawing.Color.Gray
        Me.btnBackToSemester.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackToSemester.ForeColor = System.Drawing.Color.White
        Me.btnBackToSemester.HoverState.Parent = Me.btnBackToSemester
        Me.btnBackToSemester.Location = New System.Drawing.Point(873, 551)
        Me.btnBackToSemester.Name = "btnBackToSemester"
        Me.btnBackToSemester.ShadowDecoration.Parent = Me.btnBackToSemester
        Me.btnBackToSemester.Size = New System.Drawing.Size(133, 45)
        Me.btnBackToSemester.TabIndex = 37
        Me.btnBackToSemester.Text = "BACK TO MAIN "
        '
        'Guna2Button20
        '
        Me.Guna2Button20.CheckedState.Parent = Me.Guna2Button20
        Me.Guna2Button20.CustomImages.Parent = Me.Guna2Button20
        Me.Guna2Button20.FillColor = System.Drawing.Color.DarkOrange
        Me.Guna2Button20.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button20.ForeColor = System.Drawing.Color.White
        Me.Guna2Button20.HoverState.Parent = Me.Guna2Button20
        Me.Guna2Button20.Location = New System.Drawing.Point(1195, 551)
        Me.Guna2Button20.Name = "Guna2Button20"
        Me.Guna2Button20.ShadowDecoration.Parent = Me.Guna2Button20
        Me.Guna2Button20.Size = New System.Drawing.Size(90, 45)
        Me.Guna2Button20.TabIndex = 36
        Me.Guna2Button20.Text = "CLEAR"
        '
        'pnlND1_S2_Calculator
        '
        Me.pnlND1_S2_Calculator.BackColor = System.Drawing.Color.Silver
        Me.pnlND1_S2_Calculator.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2GroupBox4)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.gns121_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel27)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.com125_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel26)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.btnBackToChoice_S2)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.btnClear_S2)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.btnExit_S2)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel14)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel15)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel16)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel17)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.grade_txt_S2)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.gradePoint_txt_S2)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.totalScorePoint_txt_S2)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.btnCalculate)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel18)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.gns228_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel19)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.eed126_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel20)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.com126_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.com124_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.com123_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.com122_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.com121_txt)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel21)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel22)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel23)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel24)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel25)
        Me.pnlND1_S2_Calculator.Controls.Add(Me.gns102_txt)
        Me.pnlND1_S2_Calculator.Location = New System.Drawing.Point(2, 14)
        Me.pnlND1_S2_Calculator.Name = "pnlND1_S2_Calculator"
        Me.pnlND1_S2_Calculator.ShadowDecoration.Parent = Me.pnlND1_S2_Calculator
        Me.pnlND1_S2_Calculator.Size = New System.Drawing.Size(1320, 619)
        Me.pnlND1_S2_Calculator.TabIndex = 38
        Me.pnlND1_S2_Calculator.Visible = False
        '
        'gns121_txt
        '
        Me.gns121_txt.BackColor = System.Drawing.Color.White
        Me.gns121_txt.BorderRadius = 10
        Me.gns121_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.gns121_txt.BorderThickness = 0
        Me.gns121_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gns121_txt.DefaultText = ""
        Me.gns121_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gns121_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gns121_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns121_txt.DisabledState.Parent = Me.gns121_txt
        Me.gns121_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns121_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns121_txt.FocusedState.Parent = Me.gns121_txt
        Me.gns121_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gns121_txt.ForeColor = System.Drawing.Color.Black
        Me.gns121_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns121_txt.HoverState.Parent = Me.gns121_txt
        Me.gns121_txt.Location = New System.Drawing.Point(579, 436)
        Me.gns121_txt.Name = "gns121_txt"
        Me.gns121_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gns121_txt.PlaceholderText = ""
        Me.gns121_txt.SelectedText = ""
        Me.gns121_txt.ShadowDecoration.Parent = Me.gns121_txt
        Me.gns121_txt.Size = New System.Drawing.Size(200, 36)
        Me.gns121_txt.TabIndex = 41
        '
        'Guna2HtmlLabel27
        '
        Me.Guna2HtmlLabel27.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel27.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel27.Location = New System.Drawing.Point(597, 412)
        Me.Guna2HtmlLabel27.Name = "Guna2HtmlLabel27"
        Me.Guna2HtmlLabel27.Size = New System.Drawing.Size(365, 18)
        Me.Guna2HtmlLabel27.TabIndex = 40
        Me.Guna2HtmlLabel27.Text = "ENTER SCORE FOR    CITIZENSHIP EDUCATION II" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</for" & _
            "e color/>"
        '
        'com125_txt
        '
        Me.com125_txt.BackColor = System.Drawing.Color.White
        Me.com125_txt.BorderRadius = 10
        Me.com125_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com125_txt.BorderThickness = 0
        Me.com125_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com125_txt.DefaultText = ""
        Me.com125_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com125_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com125_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com125_txt.DisabledState.Parent = Me.com125_txt
        Me.com125_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com125_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com125_txt.FocusedState.Parent = Me.com125_txt
        Me.com125_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com125_txt.ForeColor = System.Drawing.Color.Black
        Me.com125_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com125_txt.HoverState.Parent = Me.com125_txt
        Me.com125_txt.Location = New System.Drawing.Point(34, 450)
        Me.com125_txt.Name = "com125_txt"
        Me.com125_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com125_txt.PlaceholderText = ""
        Me.com125_txt.SelectedText = ""
        Me.com125_txt.ShadowDecoration.Parent = Me.com125_txt
        Me.com125_txt.Size = New System.Drawing.Size(200, 36)
        Me.com125_txt.TabIndex = 39
        '
        'Guna2HtmlLabel26
        '
        Me.Guna2HtmlLabel26.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel26.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel26.Location = New System.Drawing.Point(12, 412)
        Me.Guna2HtmlLabel26.Name = "Guna2HtmlLabel26"
        Me.Guna2HtmlLabel26.Size = New System.Drawing.Size(558, 18)
        Me.Guna2HtmlLabel26.TabIndex = 38
        Me.Guna2HtmlLabel26.Text = "ENTER SCORE FOR INTRODUCTION TO SYSTEMS ANALYSIS AND DESIGN" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""r" & _
            "ed"">*</fore color/>"
        '
        'btnBackToChoice_S2
        '
        Me.btnBackToChoice_S2.CheckedState.Parent = Me.btnBackToChoice_S2
        Me.btnBackToChoice_S2.CustomImages.Parent = Me.btnBackToChoice_S2
        Me.btnBackToChoice_S2.FillColor = System.Drawing.Color.Gray
        Me.btnBackToChoice_S2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackToChoice_S2.ForeColor = System.Drawing.Color.White
        Me.btnBackToChoice_S2.HoverState.Parent = Me.btnBackToChoice_S2
        Me.btnBackToChoice_S2.Location = New System.Drawing.Point(873, 567)
        Me.btnBackToChoice_S2.Name = "btnBackToChoice_S2"
        Me.btnBackToChoice_S2.ShadowDecoration.Parent = Me.btnBackToChoice_S2
        Me.btnBackToChoice_S2.Size = New System.Drawing.Size(133, 45)
        Me.btnBackToChoice_S2.TabIndex = 37
        Me.btnBackToChoice_S2.Text = "BACK TO MAIN "
        '
        'btnClear_S2
        '
        Me.btnClear_S2.CheckedState.Parent = Me.btnClear_S2
        Me.btnClear_S2.CustomImages.Parent = Me.btnClear_S2
        Me.btnClear_S2.FillColor = System.Drawing.Color.DarkOrange
        Me.btnClear_S2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear_S2.ForeColor = System.Drawing.Color.White
        Me.btnClear_S2.HoverState.Parent = Me.btnClear_S2
        Me.btnClear_S2.Location = New System.Drawing.Point(1214, 567)
        Me.btnClear_S2.Name = "btnClear_S2"
        Me.btnClear_S2.ShadowDecoration.Parent = Me.btnClear_S2
        Me.btnClear_S2.Size = New System.Drawing.Size(90, 45)
        Me.btnClear_S2.TabIndex = 36
        Me.btnClear_S2.Text = "CLEAR"
        '
        'btnExit_S2
        '
        Me.btnExit_S2.CheckedState.Parent = Me.btnExit_S2
        Me.btnExit_S2.CustomImages.Parent = Me.btnExit_S2
        Me.btnExit_S2.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnExit_S2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit_S2.ForeColor = System.Drawing.Color.White
        Me.btnExit_S2.HoverState.Parent = Me.btnExit_S2
        Me.btnExit_S2.Location = New System.Drawing.Point(1056, 567)
        Me.btnExit_S2.Name = "btnExit_S2"
        Me.btnExit_S2.ShadowDecoration.Parent = Me.btnExit_S2
        Me.btnExit_S2.Size = New System.Drawing.Size(90, 45)
        Me.btnExit_S2.TabIndex = 35
        Me.btnExit_S2.Text = "EXIT"
        '
        'Guna2HtmlLabel14
        '
        Me.Guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel14.ForeColor = System.Drawing.Color.Navy
        Me.Guna2HtmlLabel14.Location = New System.Drawing.Point(457, 20)
        Me.Guna2HtmlLabel14.Name = "Guna2HtmlLabel14"
        Me.Guna2HtmlLabel14.Size = New System.Drawing.Size(219, 22)
        Me.Guna2HtmlLabel14.TabIndex = 34
        Me.Guna2HtmlLabel14.Text = "ND1 SECOND SEMESTER"
        '
        'Guna2HtmlLabel15
        '
        Me.Guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel15.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel15.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel15.Location = New System.Drawing.Point(605, 538)
        Me.Guna2HtmlLabel15.Name = "Guna2HtmlLabel15"
        Me.Guna2HtmlLabel15.Size = New System.Drawing.Size(191, 20)
        Me.Guna2HtmlLabel15.TabIndex = 33
        Me.Guna2HtmlLabel15.Text = "TOTAL SCORE POINT:  <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel16
        '
        Me.Guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel16.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel16.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel16.Location = New System.Drawing.Point(323, 538)
        Me.Guna2HtmlLabel16.Name = "Guna2HtmlLabel16"
        Me.Guna2HtmlLabel16.Size = New System.Drawing.Size(133, 20)
        Me.Guna2HtmlLabel16.TabIndex = 32
        Me.Guna2HtmlLabel16.Text = "GRADE POINT: <fore color = ""red"">*</fore color/>"
        Me.Guna2HtmlLabel16.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Guna2HtmlLabel17
        '
        Me.Guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel17.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel17.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel17.Location = New System.Drawing.Point(50, 540)
        Me.Guna2HtmlLabel17.Name = "Guna2HtmlLabel17"
        Me.Guna2HtmlLabel17.Size = New System.Drawing.Size(78, 20)
        Me.Guna2HtmlLabel17.TabIndex = 31
        Me.Guna2HtmlLabel17.Text = "GRADE: <fore color = ""red"">*</fore color/>"
        '
        'grade_txt_S2
        '
        Me.grade_txt_S2.BackColor = System.Drawing.Color.White
        Me.grade_txt_S2.BorderRadius = 10
        Me.grade_txt_S2.BorderThickness = 0
        Me.grade_txt_S2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.grade_txt_S2.DefaultText = ""
        Me.grade_txt_S2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.grade_txt_S2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.grade_txt_S2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.grade_txt_S2.DisabledState.Parent = Me.grade_txt_S2
        Me.grade_txt_S2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.grade_txt_S2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grade_txt_S2.FocusedState.Parent = Me.grade_txt_S2
        Me.grade_txt_S2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grade_txt_S2.ForeColor = System.Drawing.Color.Black
        Me.grade_txt_S2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grade_txt_S2.HoverState.Parent = Me.grade_txt_S2
        Me.grade_txt_S2.Location = New System.Drawing.Point(37, 570)
        Me.grade_txt_S2.Name = "grade_txt_S2"
        Me.grade_txt_S2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.grade_txt_S2.PlaceholderText = ""
        Me.grade_txt_S2.SelectedText = ""
        Me.grade_txt_S2.ShadowDecoration.Parent = Me.grade_txt_S2
        Me.grade_txt_S2.Size = New System.Drawing.Size(200, 36)
        Me.grade_txt_S2.TabIndex = 30
        '
        'gradePoint_txt_S2
        '
        Me.gradePoint_txt_S2.BackColor = System.Drawing.Color.White
        Me.gradePoint_txt_S2.BorderRadius = 10
        Me.gradePoint_txt_S2.BorderThickness = 0
        Me.gradePoint_txt_S2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gradePoint_txt_S2.DefaultText = ""
        Me.gradePoint_txt_S2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gradePoint_txt_S2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gradePoint_txt_S2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gradePoint_txt_S2.DisabledState.Parent = Me.gradePoint_txt_S2
        Me.gradePoint_txt_S2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gradePoint_txt_S2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gradePoint_txt_S2.FocusedState.Parent = Me.gradePoint_txt_S2
        Me.gradePoint_txt_S2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gradePoint_txt_S2.ForeColor = System.Drawing.Color.Black
        Me.gradePoint_txt_S2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gradePoint_txt_S2.HoverState.Parent = Me.gradePoint_txt_S2
        Me.gradePoint_txt_S2.Location = New System.Drawing.Point(323, 567)
        Me.gradePoint_txt_S2.Name = "gradePoint_txt_S2"
        Me.gradePoint_txt_S2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gradePoint_txt_S2.PlaceholderText = ""
        Me.gradePoint_txt_S2.SelectedText = ""
        Me.gradePoint_txt_S2.ShadowDecoration.Parent = Me.gradePoint_txt_S2
        Me.gradePoint_txt_S2.Size = New System.Drawing.Size(200, 36)
        Me.gradePoint_txt_S2.TabIndex = 29
        '
        'totalScorePoint_txt_S2
        '
        Me.totalScorePoint_txt_S2.BackColor = System.Drawing.Color.White
        Me.totalScorePoint_txt_S2.BorderRadius = 10
        Me.totalScorePoint_txt_S2.BorderThickness = 0
        Me.totalScorePoint_txt_S2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalScorePoint_txt_S2.DefaultText = ""
        Me.totalScorePoint_txt_S2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.totalScorePoint_txt_S2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.totalScorePoint_txt_S2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalScorePoint_txt_S2.DisabledState.Parent = Me.totalScorePoint_txt_S2
        Me.totalScorePoint_txt_S2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalScorePoint_txt_S2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalScorePoint_txt_S2.FocusedState.Parent = Me.totalScorePoint_txt_S2
        Me.totalScorePoint_txt_S2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalScorePoint_txt_S2.ForeColor = System.Drawing.Color.Black
        Me.totalScorePoint_txt_S2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalScorePoint_txt_S2.HoverState.Parent = Me.totalScorePoint_txt_S2
        Me.totalScorePoint_txt_S2.Location = New System.Drawing.Point(605, 564)
        Me.totalScorePoint_txt_S2.Name = "totalScorePoint_txt_S2"
        Me.totalScorePoint_txt_S2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.totalScorePoint_txt_S2.PlaceholderText = ""
        Me.totalScorePoint_txt_S2.SelectedText = ""
        Me.totalScorePoint_txt_S2.ShadowDecoration.Parent = Me.totalScorePoint_txt_S2
        Me.totalScorePoint_txt_S2.Size = New System.Drawing.Size(200, 36)
        Me.totalScorePoint_txt_S2.TabIndex = 28
        '
        'btnCalculate
        '
        Me.btnCalculate.CheckedState.Parent = Me.btnCalculate
        Me.btnCalculate.CustomImages.Parent = Me.btnCalculate
        Me.btnCalculate.FillColor = System.Drawing.Color.Green
        Me.btnCalculate.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.ForeColor = System.Drawing.Color.White
        Me.btnCalculate.HoverState.Parent = Me.btnCalculate
        Me.btnCalculate.Location = New System.Drawing.Point(339, 484)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.ShadowDecoration.Parent = Me.btnCalculate
        Me.btnCalculate.Size = New System.Drawing.Size(180, 45)
        Me.btnCalculate.TabIndex = 26
        Me.btnCalculate.Text = "CALCULATE"
        '
        'Guna2HtmlLabel18
        '
        Me.Guna2HtmlLabel18.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel18.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel18.Location = New System.Drawing.Point(574, 315)
        Me.Guna2HtmlLabel18.Name = "Guna2HtmlLabel18"
        Me.Guna2HtmlLabel18.Size = New System.Drawing.Size(383, 18)
        Me.Guna2HtmlLabel18.TabIndex = 24
        Me.Guna2HtmlLabel18.Text = "ENTER SCORE FOR COMMUNICATION IN ENGLISH" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore c" & _
            "olor/>"
        '
        'gns228_txt
        '
        Me.gns228_txt.BackColor = System.Drawing.Color.White
        Me.gns228_txt.BorderRadius = 10
        Me.gns228_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.gns228_txt.BorderThickness = 0
        Me.gns228_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gns228_txt.DefaultText = ""
        Me.gns228_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gns228_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gns228_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns228_txt.DisabledState.Parent = Me.gns228_txt
        Me.gns228_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns228_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns228_txt.FocusedState.Parent = Me.gns228_txt
        Me.gns228_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gns228_txt.ForeColor = System.Drawing.Color.Black
        Me.gns228_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns228_txt.HoverState.Parent = Me.gns228_txt
        Me.gns228_txt.Location = New System.Drawing.Point(579, 258)
        Me.gns228_txt.Name = "gns228_txt"
        Me.gns228_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gns228_txt.PlaceholderText = ""
        Me.gns228_txt.SelectedText = ""
        Me.gns228_txt.ShadowDecoration.Parent = Me.gns228_txt
        Me.gns228_txt.Size = New System.Drawing.Size(200, 36)
        Me.gns228_txt.TabIndex = 23
        '
        'Guna2HtmlLabel19
        '
        Me.Guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel19.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel19.Location = New System.Drawing.Point(541, 229)
        Me.Guna2HtmlLabel19.Name = "Guna2HtmlLabel19"
        Me.Guna2HtmlLabel19.Size = New System.Drawing.Size(448, 18)
        Me.Guna2HtmlLabel19.TabIndex = 22
        Me.Guna2HtmlLabel19.Text = "ENTER SCORE FOR   PRACTICAL OF ENTREPRENEURSHIP I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*<" & _
            "/fore color/>"
        '
        'eed126_txt
        '
        Me.eed126_txt.BackColor = System.Drawing.Color.White
        Me.eed126_txt.BorderRadius = 10
        Me.eed126_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.eed126_txt.BorderThickness = 0
        Me.eed126_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.eed126_txt.DefaultText = ""
        Me.eed126_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.eed126_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.eed126_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.eed126_txt.DisabledState.Parent = Me.eed126_txt
        Me.eed126_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.eed126_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.eed126_txt.FocusedState.Parent = Me.eed126_txt
        Me.eed126_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eed126_txt.ForeColor = System.Drawing.Color.Black
        Me.eed126_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.eed126_txt.HoverState.Parent = Me.eed126_txt
        Me.eed126_txt.Location = New System.Drawing.Point(579, 171)
        Me.eed126_txt.Name = "eed126_txt"
        Me.eed126_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.eed126_txt.PlaceholderText = ""
        Me.eed126_txt.SelectedText = ""
        Me.eed126_txt.ShadowDecoration.Parent = Me.eed126_txt
        Me.eed126_txt.Size = New System.Drawing.Size(200, 36)
        Me.eed126_txt.TabIndex = 21
        '
        'Guna2HtmlLabel20
        '
        Me.Guna2HtmlLabel20.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel20.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel20.Location = New System.Drawing.Point(568, 145)
        Me.Guna2HtmlLabel20.Name = "Guna2HtmlLabel20"
        Me.Guna2HtmlLabel20.Size = New System.Drawing.Size(390, 18)
        Me.Guna2HtmlLabel20.TabIndex = 20
        Me.Guna2HtmlLabel20.Text = "ENTER SCORE FOR  RESEARCH METHODS GNS228" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color" & _
            "/>"
        '
        'com126_txt
        '
        Me.com126_txt.BackColor = System.Drawing.Color.White
        Me.com126_txt.BorderRadius = 10
        Me.com126_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com126_txt.BorderThickness = 0
        Me.com126_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com126_txt.DefaultText = ""
        Me.com126_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com126_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com126_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com126_txt.DisabledState.Parent = Me.com126_txt
        Me.com126_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com126_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com126_txt.FocusedState.Parent = Me.com126_txt
        Me.com126_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com126_txt.ForeColor = System.Drawing.Color.Black
        Me.com126_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com126_txt.HoverState.Parent = Me.com126_txt
        Me.com126_txt.Location = New System.Drawing.Point(579, 88)
        Me.com126_txt.Name = "com126_txt"
        Me.com126_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com126_txt.PlaceholderText = ""
        Me.com126_txt.SelectedText = ""
        Me.com126_txt.ShadowDecoration.Parent = Me.com126_txt
        Me.com126_txt.Size = New System.Drawing.Size(200, 36)
        Me.com126_txt.TabIndex = 19
        '
        'com124_txt
        '
        Me.com124_txt.BackColor = System.Drawing.Color.White
        Me.com124_txt.BorderRadius = 10
        Me.com124_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com124_txt.BorderThickness = 0
        Me.com124_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com124_txt.DefaultText = ""
        Me.com124_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com124_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com124_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com124_txt.DisabledState.Parent = Me.com124_txt
        Me.com124_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com124_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com124_txt.FocusedState.Parent = Me.com124_txt
        Me.com124_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com124_txt.ForeColor = System.Drawing.Color.Black
        Me.com124_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com124_txt.HoverState.Parent = Me.com124_txt
        Me.com124_txt.Location = New System.Drawing.Point(37, 348)
        Me.com124_txt.Name = "com124_txt"
        Me.com124_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com124_txt.PlaceholderText = ""
        Me.com124_txt.SelectedText = ""
        Me.com124_txt.ShadowDecoration.Parent = Me.com124_txt
        Me.com124_txt.Size = New System.Drawing.Size(200, 36)
        Me.com124_txt.TabIndex = 18
        '
        'com123_txt
        '
        Me.com123_txt.BackColor = System.Drawing.Color.White
        Me.com123_txt.BorderRadius = 10
        Me.com123_txt.BorderThickness = 0
        Me.com123_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com123_txt.DefaultText = ""
        Me.com123_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com123_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com123_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com123_txt.DisabledState.Parent = Me.com123_txt
        Me.com123_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com123_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com123_txt.FocusedState.Parent = Me.com123_txt
        Me.com123_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com123_txt.ForeColor = System.Drawing.Color.Black
        Me.com123_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com123_txt.HoverState.Parent = Me.com123_txt
        Me.com123_txt.Location = New System.Drawing.Point(37, 263)
        Me.com123_txt.Name = "com123_txt"
        Me.com123_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com123_txt.PlaceholderText = ""
        Me.com123_txt.SelectedText = ""
        Me.com123_txt.ShadowDecoration.Parent = Me.com123_txt
        Me.com123_txt.Size = New System.Drawing.Size(200, 36)
        Me.com123_txt.TabIndex = 17
        '
        'com122_txt
        '
        Me.com122_txt.BackColor = System.Drawing.Color.White
        Me.com122_txt.BorderRadius = 10
        Me.com122_txt.BorderThickness = 0
        Me.com122_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com122_txt.DefaultText = ""
        Me.com122_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com122_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com122_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com122_txt.DisabledState.Parent = Me.com122_txt
        Me.com122_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com122_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com122_txt.FocusedState.Parent = Me.com122_txt
        Me.com122_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com122_txt.ForeColor = System.Drawing.Color.Black
        Me.com122_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com122_txt.HoverState.Parent = Me.com122_txt
        Me.com122_txt.Location = New System.Drawing.Point(37, 171)
        Me.com122_txt.Name = "com122_txt"
        Me.com122_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com122_txt.PlaceholderText = ""
        Me.com122_txt.SelectedText = ""
        Me.com122_txt.ShadowDecoration.Parent = Me.com122_txt
        Me.com122_txt.Size = New System.Drawing.Size(200, 36)
        Me.com122_txt.TabIndex = 16
        '
        'com121_txt
        '
        Me.com121_txt.BackColor = System.Drawing.Color.White
        Me.com121_txt.BorderRadius = 10
        Me.com121_txt.BorderThickness = 0
        Me.com121_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com121_txt.DefaultText = ""
        Me.com121_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com121_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com121_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com121_txt.DisabledState.Parent = Me.com121_txt
        Me.com121_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com121_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com121_txt.FocusedState.Parent = Me.com121_txt
        Me.com121_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com121_txt.ForeColor = System.Drawing.Color.Black
        Me.com121_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com121_txt.HoverState.Parent = Me.com121_txt
        Me.com121_txt.Location = New System.Drawing.Point(37, 88)
        Me.com121_txt.Name = "com121_txt"
        Me.com121_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com121_txt.PlaceholderText = ""
        Me.com121_txt.SelectedText = ""
        Me.com121_txt.ShadowDecoration.Parent = Me.com121_txt
        Me.com121_txt.Size = New System.Drawing.Size(200, 36)
        Me.com121_txt.TabIndex = 15
        '
        'Guna2HtmlLabel21
        '
        Me.Guna2HtmlLabel21.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel21.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel21.Location = New System.Drawing.Point(562, 64)
        Me.Guna2HtmlLabel21.Name = "Guna2HtmlLabel21"
        Me.Guna2HtmlLabel21.Size = New System.Drawing.Size(415, 18)
        Me.Guna2HtmlLabel21.TabIndex = 14
        Me.Guna2HtmlLabel21.Text = "ENTER SCORE FOR PC UPGRADE AND MAINTENANCE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color" & _
            "/>"
        '
        'Guna2HtmlLabel22
        '
        Me.Guna2HtmlLabel22.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel22.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel22.Location = New System.Drawing.Point(17, 315)
        Me.Guna2HtmlLabel22.Name = "Guna2HtmlLabel22"
        Me.Guna2HtmlLabel22.Size = New System.Drawing.Size(445, 18)
        Me.Guna2HtmlLabel22.TabIndex = 13
        Me.Guna2HtmlLabel22.Text = "ENTER SCORE FOR  DATA STRUCTURE AND ALGORITHMS " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore" & _
            " color/>"
        '
        'Guna2HtmlLabel23
        '
        Me.Guna2HtmlLabel23.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel23.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel23.Location = New System.Drawing.Point(25, 229)
        Me.Guna2HtmlLabel23.Name = "Guna2HtmlLabel23"
        Me.Guna2HtmlLabel23.Size = New System.Drawing.Size(383, 18)
        Me.Guna2HtmlLabel23.TabIndex = 11
        Me.Guna2HtmlLabel23.Text = "ENTER SCORE FOR PROGRAMMING USING JAVA I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel24
        '
        Me.Guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel24.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel24.Location = New System.Drawing.Point(30, 145)
        Me.Guna2HtmlLabel24.Name = "Guna2HtmlLabel24"
        Me.Guna2HtmlLabel24.Size = New System.Drawing.Size(378, 18)
        Me.Guna2HtmlLabel24.TabIndex = 9
        Me.Guna2HtmlLabel24.Text = "ENTER SCORE FOR INTODUCTION TO INTERNET" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " : <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel25
        '
        Me.Guna2HtmlLabel25.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel25.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel25.Location = New System.Drawing.Point(25, 64)
        Me.Guna2HtmlLabel25.Name = "Guna2HtmlLabel25"
        Me.Guna2HtmlLabel25.Size = New System.Drawing.Size(433, 18)
        Me.Guna2HtmlLabel25.TabIndex = 2
        Me.Guna2HtmlLabel25.Text = "ENTER SCORE FOR PROGRAMMING USING C LANGUAGE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color" & _
            "/>"
        '
        'gns102_txt
        '
        Me.gns102_txt.BackColor = System.Drawing.Color.White
        Me.gns102_txt.BorderRadius = 10
        Me.gns102_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.gns102_txt.BorderThickness = 0
        Me.gns102_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gns102_txt.DefaultText = ""
        Me.gns102_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gns102_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gns102_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns102_txt.DisabledState.Parent = Me.gns102_txt
        Me.gns102_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns102_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns102_txt.FocusedState.Parent = Me.gns102_txt
        Me.gns102_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gns102_txt.ForeColor = System.Drawing.Color.Black
        Me.gns102_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns102_txt.HoverState.Parent = Me.gns102_txt
        Me.gns102_txt.Location = New System.Drawing.Point(579, 352)
        Me.gns102_txt.Name = "gns102_txt"
        Me.gns102_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gns102_txt.PlaceholderText = ""
        Me.gns102_txt.SelectedText = ""
        Me.gns102_txt.ShadowDecoration.Parent = Me.gns102_txt
        Me.gns102_txt.Size = New System.Drawing.Size(200, 36)
        Me.gns102_txt.TabIndex = 25
        '
        'Guna2HtmlLabel29
        '
        Me.Guna2HtmlLabel29.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel29.Location = New System.Drawing.Point(442, 85)
        Me.Guna2HtmlLabel29.Name = "Guna2HtmlLabel29"
        Me.Guna2HtmlLabel29.Size = New System.Drawing.Size(260, 22)
        Me.Guna2HtmlLabel29.TabIndex = 0
        Me.Guna2HtmlLabel29.Text = "SELECT SEMESTER FOR ND 1"
        '
        'pnlND2Semesters
        '
        Me.pnlND2Semesters.BackColor = System.Drawing.Color.Silver
        Me.pnlND2Semesters.Controls.Add(Me.btnBackToMain_ND2)
        Me.pnlND2Semesters.Controls.Add(Me.btnND2SecondSemester)
        Me.pnlND2Semesters.Controls.Add(Me.btnND2FirstSemester)
        Me.pnlND2Semesters.Controls.Add(Me.Guna2HtmlLabel28)
        Me.pnlND2Semesters.Location = New System.Drawing.Point(3, 12)
        Me.pnlND2Semesters.Name = "pnlND2Semesters"
        Me.pnlND2Semesters.ShadowDecoration.Parent = Me.pnlND2Semesters
        Me.pnlND2Semesters.Size = New System.Drawing.Size(1319, 619)
        Me.pnlND2Semesters.TabIndex = 42
        Me.pnlND2Semesters.Visible = False
        '
        'btnBackToMain_ND2
        '
        Me.btnBackToMain_ND2.BorderRadius = 15
        Me.btnBackToMain_ND2.CheckedState.Parent = Me.btnBackToMain_ND2
        Me.btnBackToMain_ND2.CustomImages.Parent = Me.btnBackToMain_ND2
        Me.btnBackToMain_ND2.FillColor = System.Drawing.Color.Gray
        Me.btnBackToMain_ND2.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackToMain_ND2.ForeColor = System.Drawing.Color.White
        Me.btnBackToMain_ND2.HoverState.Parent = Me.btnBackToMain_ND2
        Me.btnBackToMain_ND2.Location = New System.Drawing.Point(493, 303)
        Me.btnBackToMain_ND2.Name = "btnBackToMain_ND2"
        Me.btnBackToMain_ND2.ShadowDecoration.Parent = Me.btnBackToMain_ND2
        Me.btnBackToMain_ND2.Size = New System.Drawing.Size(257, 45)
        Me.btnBackToMain_ND2.TabIndex = 3
        Me.btnBackToMain_ND2.Text = "BACK TO MAIN  MENU"
        '
        'btnND2SecondSemester
        '
        Me.btnND2SecondSemester.BorderRadius = 15
        Me.btnND2SecondSemester.CheckedState.Parent = Me.btnND2SecondSemester
        Me.btnND2SecondSemester.CustomImages.Parent = Me.btnND2SecondSemester
        Me.btnND2SecondSemester.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btnND2SecondSemester.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnND2SecondSemester.ForeColor = System.Drawing.Color.White
        Me.btnND2SecondSemester.HoverState.Parent = Me.btnND2SecondSemester
        Me.btnND2SecondSemester.Location = New System.Drawing.Point(696, 190)
        Me.btnND2SecondSemester.Name = "btnND2SecondSemester"
        Me.btnND2SecondSemester.ShadowDecoration.Parent = Me.btnND2SecondSemester
        Me.btnND2SecondSemester.Size = New System.Drawing.Size(207, 45)
        Me.btnND2SecondSemester.TabIndex = 2
        Me.btnND2SecondSemester.Text = "SECOND SEMESTER"
        '
        'btnND2FirstSemester
        '
        Me.btnND2FirstSemester.BorderRadius = 15
        Me.btnND2FirstSemester.CheckedState.Parent = Me.btnND2FirstSemester
        Me.btnND2FirstSemester.CustomImages.Parent = Me.btnND2FirstSemester
        Me.btnND2FirstSemester.FillColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnND2FirstSemester.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnND2FirstSemester.ForeColor = System.Drawing.Color.White
        Me.btnND2FirstSemester.HoverState.Parent = Me.btnND2FirstSemester
        Me.btnND2FirstSemester.Location = New System.Drawing.Point(289, 197)
        Me.btnND2FirstSemester.Name = "btnND2FirstSemester"
        Me.btnND2FirstSemester.ShadowDecoration.Parent = Me.btnND2FirstSemester
        Me.btnND2FirstSemester.Size = New System.Drawing.Size(180, 45)
        Me.btnND2FirstSemester.TabIndex = 1
        Me.btnND2FirstSemester.Text = "FIRST SEMESTER"
        '
        'Guna2HtmlLabel28
        '
        Me.Guna2HtmlLabel28.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel28.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel28.Location = New System.Drawing.Point(442, 85)
        Me.Guna2HtmlLabel28.Name = "Guna2HtmlLabel28"
        Me.Guna2HtmlLabel28.Size = New System.Drawing.Size(335, 27)
        Me.Guna2HtmlLabel28.TabIndex = 0
        Me.Guna2HtmlLabel28.Text = "SELECT SEMESTER FOR ND 2"
        '
        'pnlND2_S2_Calculator
        '
        Me.pnlND2_S2_Calculator.BackColor = System.Drawing.Color.Silver
        Me.pnlND2_S2_Calculator.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.pnlND2_S2_Calculator.Controls.Add(Me.btnClear_ND2S2)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.btnExit_ND2S2)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel30)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel31)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel32)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel33)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.grade_txt_NDS2)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.gradePoint_txt_ND2S2)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.totalScorePoint_txt_ND2S2)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2GroupBox2)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.btnCalculateND2S2)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel34)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.com229_txt)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel35)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.com226_txt)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel36)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.com225_txt)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.com224_txt)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.com223_txt)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.com222_txt)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.com221_txt)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel37)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel38)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel39)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel40)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.Guna2HtmlLabel41)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.gns202_txt)
        Me.pnlND2_S2_Calculator.Controls.Add(Me.btnBack_ND2S2)
        Me.pnlND2_S2_Calculator.Location = New System.Drawing.Point(0, 11)
        Me.pnlND2_S2_Calculator.Name = "pnlND2_S2_Calculator"
        Me.pnlND2_S2_Calculator.ShadowDecoration.Parent = Me.pnlND2_S2_Calculator
        Me.pnlND2_S2_Calculator.Size = New System.Drawing.Size(1320, 619)
        Me.pnlND2_S2_Calculator.TabIndex = 5
        Me.pnlND2_S2_Calculator.Visible = False
        '
        'btnClear_ND2S2
        '
        Me.btnClear_ND2S2.CheckedState.Parent = Me.btnClear_ND2S2
        Me.btnClear_ND2S2.CustomImages.Parent = Me.btnClear_ND2S2
        Me.btnClear_ND2S2.FillColor = System.Drawing.Color.DarkOrange
        Me.btnClear_ND2S2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear_ND2S2.ForeColor = System.Drawing.Color.White
        Me.btnClear_ND2S2.HoverState.Parent = Me.btnClear_ND2S2
        Me.btnClear_ND2S2.Location = New System.Drawing.Point(1214, 551)
        Me.btnClear_ND2S2.Name = "btnClear_ND2S2"
        Me.btnClear_ND2S2.ShadowDecoration.Parent = Me.btnClear_ND2S2
        Me.btnClear_ND2S2.Size = New System.Drawing.Size(90, 45)
        Me.btnClear_ND2S2.TabIndex = 36
        Me.btnClear_ND2S2.Text = "CLEAR"
        '
        'btnExit_ND2S2
        '
        Me.btnExit_ND2S2.CheckedState.Parent = Me.btnExit_ND2S2
        Me.btnExit_ND2S2.CustomImages.Parent = Me.btnExit_ND2S2
        Me.btnExit_ND2S2.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnExit_ND2S2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit_ND2S2.ForeColor = System.Drawing.Color.White
        Me.btnExit_ND2S2.HoverState.Parent = Me.btnExit_ND2S2
        Me.btnExit_ND2S2.Location = New System.Drawing.Point(1056, 551)
        Me.btnExit_ND2S2.Name = "btnExit_ND2S2"
        Me.btnExit_ND2S2.ShadowDecoration.Parent = Me.btnExit_ND2S2
        Me.btnExit_ND2S2.Size = New System.Drawing.Size(90, 45)
        Me.btnExit_ND2S2.TabIndex = 35
        Me.btnExit_ND2S2.Text = "EXIT"
        '
        'Guna2HtmlLabel30
        '
        Me.Guna2HtmlLabel30.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel30.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel30.ForeColor = System.Drawing.Color.Navy
        Me.Guna2HtmlLabel30.Location = New System.Drawing.Point(457, 34)
        Me.Guna2HtmlLabel30.Name = "Guna2HtmlLabel30"
        Me.Guna2HtmlLabel30.Size = New System.Drawing.Size(219, 22)
        Me.Guna2HtmlLabel30.TabIndex = 34
        Me.Guna2HtmlLabel30.Text = "ND2 SECOND SEMESTER"
        '
        'Guna2HtmlLabel31
        '
        Me.Guna2HtmlLabel31.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel31.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel31.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel31.Location = New System.Drawing.Point(605, 524)
        Me.Guna2HtmlLabel31.Name = "Guna2HtmlLabel31"
        Me.Guna2HtmlLabel31.Size = New System.Drawing.Size(191, 20)
        Me.Guna2HtmlLabel31.TabIndex = 33
        Me.Guna2HtmlLabel31.Text = "TOTAL SCORE POINT:  <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel32
        '
        Me.Guna2HtmlLabel32.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel32.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel32.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel32.Location = New System.Drawing.Point(331, 527)
        Me.Guna2HtmlLabel32.Name = "Guna2HtmlLabel32"
        Me.Guna2HtmlLabel32.Size = New System.Drawing.Size(133, 20)
        Me.Guna2HtmlLabel32.TabIndex = 32
        Me.Guna2HtmlLabel32.Text = "GRADE POINT: <fore color = ""red"">*</fore color/>"
        Me.Guna2HtmlLabel32.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Guna2HtmlLabel33
        '
        Me.Guna2HtmlLabel33.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel33.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel33.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel33.Location = New System.Drawing.Point(37, 527)
        Me.Guna2HtmlLabel33.Name = "Guna2HtmlLabel33"
        Me.Guna2HtmlLabel33.Size = New System.Drawing.Size(78, 20)
        Me.Guna2HtmlLabel33.TabIndex = 31
        Me.Guna2HtmlLabel33.Text = "GRADE: <fore color = ""red"">*</fore color/>"
        '
        'grade_txt_NDS2
        '
        Me.grade_txt_NDS2.BackColor = System.Drawing.Color.White
        Me.grade_txt_NDS2.BorderRadius = 10
        Me.grade_txt_NDS2.BorderThickness = 0
        Me.grade_txt_NDS2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.grade_txt_NDS2.DefaultText = ""
        Me.grade_txt_NDS2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.grade_txt_NDS2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.grade_txt_NDS2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.grade_txt_NDS2.DisabledState.Parent = Me.grade_txt_NDS2
        Me.grade_txt_NDS2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.grade_txt_NDS2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grade_txt_NDS2.FocusedState.Parent = Me.grade_txt_NDS2
        Me.grade_txt_NDS2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grade_txt_NDS2.ForeColor = System.Drawing.Color.Black
        Me.grade_txt_NDS2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grade_txt_NDS2.HoverState.Parent = Me.grade_txt_NDS2
        Me.grade_txt_NDS2.Location = New System.Drawing.Point(37, 560)
        Me.grade_txt_NDS2.Name = "grade_txt_NDS2"
        Me.grade_txt_NDS2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.grade_txt_NDS2.PlaceholderText = ""
        Me.grade_txt_NDS2.SelectedText = ""
        Me.grade_txt_NDS2.ShadowDecoration.Parent = Me.grade_txt_NDS2
        Me.grade_txt_NDS2.Size = New System.Drawing.Size(200, 36)
        Me.grade_txt_NDS2.TabIndex = 30
        '
        'gradePoint_txt_ND2S2
        '
        Me.gradePoint_txt_ND2S2.BackColor = System.Drawing.Color.White
        Me.gradePoint_txt_ND2S2.BorderRadius = 10
        Me.gradePoint_txt_ND2S2.BorderThickness = 0
        Me.gradePoint_txt_ND2S2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gradePoint_txt_ND2S2.DefaultText = ""
        Me.gradePoint_txt_ND2S2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gradePoint_txt_ND2S2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gradePoint_txt_ND2S2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gradePoint_txt_ND2S2.DisabledState.Parent = Me.gradePoint_txt_ND2S2
        Me.gradePoint_txt_ND2S2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gradePoint_txt_ND2S2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gradePoint_txt_ND2S2.FocusedState.Parent = Me.gradePoint_txt_ND2S2
        Me.gradePoint_txt_ND2S2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gradePoint_txt_ND2S2.ForeColor = System.Drawing.Color.Black
        Me.gradePoint_txt_ND2S2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gradePoint_txt_ND2S2.HoverState.Parent = Me.gradePoint_txt_ND2S2
        Me.gradePoint_txt_ND2S2.Location = New System.Drawing.Point(323, 560)
        Me.gradePoint_txt_ND2S2.Name = "gradePoint_txt_ND2S2"
        Me.gradePoint_txt_ND2S2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gradePoint_txt_ND2S2.PlaceholderText = ""
        Me.gradePoint_txt_ND2S2.SelectedText = ""
        Me.gradePoint_txt_ND2S2.ShadowDecoration.Parent = Me.gradePoint_txt_ND2S2
        Me.gradePoint_txt_ND2S2.Size = New System.Drawing.Size(200, 36)
        Me.gradePoint_txt_ND2S2.TabIndex = 29
        '
        'totalScorePoint_txt_ND2S2
        '
        Me.totalScorePoint_txt_ND2S2.BackColor = System.Drawing.Color.White
        Me.totalScorePoint_txt_ND2S2.BorderRadius = 10
        Me.totalScorePoint_txt_ND2S2.BorderThickness = 0
        Me.totalScorePoint_txt_ND2S2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalScorePoint_txt_ND2S2.DefaultText = ""
        Me.totalScorePoint_txt_ND2S2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.totalScorePoint_txt_ND2S2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.totalScorePoint_txt_ND2S2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalScorePoint_txt_ND2S2.DisabledState.Parent = Me.totalScorePoint_txt_ND2S2
        Me.totalScorePoint_txt_ND2S2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalScorePoint_txt_ND2S2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalScorePoint_txt_ND2S2.FocusedState.Parent = Me.totalScorePoint_txt_ND2S2
        Me.totalScorePoint_txt_ND2S2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalScorePoint_txt_ND2S2.ForeColor = System.Drawing.Color.Black
        Me.totalScorePoint_txt_ND2S2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalScorePoint_txt_ND2S2.HoverState.Parent = Me.totalScorePoint_txt_ND2S2
        Me.totalScorePoint_txt_ND2S2.Location = New System.Drawing.Point(605, 560)
        Me.totalScorePoint_txt_ND2S2.Name = "totalScorePoint_txt_ND2S2"
        Me.totalScorePoint_txt_ND2S2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.totalScorePoint_txt_ND2S2.PlaceholderText = ""
        Me.totalScorePoint_txt_ND2S2.SelectedText = ""
        Me.totalScorePoint_txt_ND2S2.ShadowDecoration.Parent = Me.totalScorePoint_txt_ND2S2
        Me.totalScorePoint_txt_ND2S2.Size = New System.Drawing.Size(200, 36)
        Me.totalScorePoint_txt_ND2S2.TabIndex = 28
        '
        'Guna2GroupBox2
        '
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button43)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button44)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button45)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button46)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button47)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button48)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button50)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button51)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button52)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button53)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button54)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button55)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button56)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button57)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button58)
        Me.Guna2GroupBox2.Controls.Add(Me.Guna2Button49)
        Me.Guna2GroupBox2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox2.Location = New System.Drawing.Point(1000, 34)
        Me.Guna2GroupBox2.Name = "Guna2GroupBox2"
        Me.Guna2GroupBox2.ShadowDecoration.Parent = Me.Guna2GroupBox2
        Me.Guna2GroupBox2.Size = New System.Drawing.Size(300, 484)
        Me.Guna2GroupBox2.TabIndex = 27
        Me.Guna2GroupBox2.Text = " COURSE UNIT"
        '
        'Guna2Button43
        '
        Me.Guna2Button43.CheckedState.Parent = Me.Guna2Button43
        Me.Guna2Button43.CustomImages.Parent = Me.Guna2Button43
        Me.Guna2Button43.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button43.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button43.ForeColor = System.Drawing.Color.White
        Me.Guna2Button43.HoverState.Parent = Me.Guna2Button43
        Me.Guna2Button43.Location = New System.Drawing.Point(214, 432)
        Me.Guna2Button43.Name = "Guna2Button43"
        Me.Guna2Button43.ShadowDecoration.Parent = Me.Guna2Button43
        Me.Guna2Button43.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button43.TabIndex = 15
        Me.Guna2Button43.Text = "2"
        '
        'Guna2Button44
        '
        Me.Guna2Button44.CheckedState.Parent = Me.Guna2Button44
        Me.Guna2Button44.CustomImages.Parent = Me.Guna2Button44
        Me.Guna2Button44.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button44.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button44.ForeColor = System.Drawing.Color.White
        Me.Guna2Button44.HoverState.Parent = Me.Guna2Button44
        Me.Guna2Button44.Location = New System.Drawing.Point(214, 379)
        Me.Guna2Button44.Name = "Guna2Button44"
        Me.Guna2Button44.ShadowDecoration.Parent = Me.Guna2Button44
        Me.Guna2Button44.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button44.TabIndex = 14
        Me.Guna2Button44.Text = "4"
        '
        'Guna2Button45
        '
        Me.Guna2Button45.CheckedState.Parent = Me.Guna2Button45
        Me.Guna2Button45.CustomImages.Parent = Me.Guna2Button45
        Me.Guna2Button45.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button45.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button45.ForeColor = System.Drawing.Color.White
        Me.Guna2Button45.HoverState.Parent = Me.Guna2Button45
        Me.Guna2Button45.Location = New System.Drawing.Point(12, 434)
        Me.Guna2Button45.Name = "Guna2Button45"
        Me.Guna2Button45.ShadowDecoration.Parent = Me.Guna2Button45
        Me.Guna2Button45.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button45.TabIndex = 13
        Me.Guna2Button45.Text = "GNS202"
        '
        'Guna2Button46
        '
        Me.Guna2Button46.CheckedState.Parent = Me.Guna2Button46
        Me.Guna2Button46.CustomImages.Parent = Me.Guna2Button46
        Me.Guna2Button46.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button46.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button46.ForeColor = System.Drawing.Color.White
        Me.Guna2Button46.HoverState.Parent = Me.Guna2Button46
        Me.Guna2Button46.Location = New System.Drawing.Point(12, 379)
        Me.Guna2Button46.Name = "Guna2Button46"
        Me.Guna2Button46.ShadowDecoration.Parent = Me.Guna2Button46
        Me.Guna2Button46.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button46.TabIndex = 12
        Me.Guna2Button46.Text = "COM229"
        '
        'Guna2Button47
        '
        Me.Guna2Button47.CheckedState.Parent = Me.Guna2Button47
        Me.Guna2Button47.CustomImages.Parent = Me.Guna2Button47
        Me.Guna2Button47.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button47.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button47.ForeColor = System.Drawing.Color.White
        Me.Guna2Button47.HoverState.Parent = Me.Guna2Button47
        Me.Guna2Button47.Location = New System.Drawing.Point(214, 103)
        Me.Guna2Button47.Name = "Guna2Button47"
        Me.Guna2Button47.ShadowDecoration.Parent = Me.Guna2Button47
        Me.Guna2Button47.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button47.TabIndex = 11
        Me.Guna2Button47.Text = "2"
        '
        'Guna2Button48
        '
        Me.Guna2Button48.CheckedState.Parent = Me.Guna2Button48
        Me.Guna2Button48.CustomImages.Parent = Me.Guna2Button48
        Me.Guna2Button48.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button48.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button48.ForeColor = System.Drawing.Color.White
        Me.Guna2Button48.HoverState.Parent = Me.Guna2Button48
        Me.Guna2Button48.Location = New System.Drawing.Point(214, 154)
        Me.Guna2Button48.Name = "Guna2Button48"
        Me.Guna2Button48.ShadowDecoration.Parent = Me.Guna2Button48
        Me.Guna2Button48.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button48.TabIndex = 10
        Me.Guna2Button48.Text = "2"
        '
        'Guna2Button50
        '
        Me.Guna2Button50.CheckedState.Parent = Me.Guna2Button50
        Me.Guna2Button50.CustomImages.Parent = Me.Guna2Button50
        Me.Guna2Button50.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button50.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button50.ForeColor = System.Drawing.Color.White
        Me.Guna2Button50.HoverState.Parent = Me.Guna2Button50
        Me.Guna2Button50.Location = New System.Drawing.Point(214, 263)
        Me.Guna2Button50.Name = "Guna2Button50"
        Me.Guna2Button50.ShadowDecoration.Parent = Me.Guna2Button50
        Me.Guna2Button50.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button50.TabIndex = 8
        Me.Guna2Button50.Text = "3"
        '
        'Guna2Button51
        '
        Me.Guna2Button51.CheckedState.Parent = Me.Guna2Button51
        Me.Guna2Button51.CustomImages.Parent = Me.Guna2Button51
        Me.Guna2Button51.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button51.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button51.ForeColor = System.Drawing.Color.White
        Me.Guna2Button51.HoverState.Parent = Me.Guna2Button51
        Me.Guna2Button51.Location = New System.Drawing.Point(214, 319)
        Me.Guna2Button51.Name = "Guna2Button51"
        Me.Guna2Button51.ShadowDecoration.Parent = Me.Guna2Button51
        Me.Guna2Button51.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button51.TabIndex = 7
        Me.Guna2Button51.Text = "2"
        '
        'Guna2Button52
        '
        Me.Guna2Button52.CheckedState.Parent = Me.Guna2Button52
        Me.Guna2Button52.CustomImages.Parent = Me.Guna2Button52
        Me.Guna2Button52.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button52.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button52.ForeColor = System.Drawing.Color.White
        Me.Guna2Button52.HoverState.Parent = Me.Guna2Button52
        Me.Guna2Button52.Location = New System.Drawing.Point(214, 52)
        Me.Guna2Button52.Name = "Guna2Button52"
        Me.Guna2Button52.ShadowDecoration.Parent = Me.Guna2Button52
        Me.Guna2Button52.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button52.TabIndex = 6
        Me.Guna2Button52.Text = "3"
        '
        'Guna2Button53
        '
        Me.Guna2Button53.CheckedState.Parent = Me.Guna2Button53
        Me.Guna2Button53.CustomImages.Parent = Me.Guna2Button53
        Me.Guna2Button53.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button53.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button53.ForeColor = System.Drawing.Color.White
        Me.Guna2Button53.HoverState.Parent = Me.Guna2Button53
        Me.Guna2Button53.Location = New System.Drawing.Point(12, 321)
        Me.Guna2Button53.Name = "Guna2Button53"
        Me.Guna2Button53.ShadowDecoration.Parent = Me.Guna2Button53
        Me.Guna2Button53.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button53.TabIndex = 5
        Me.Guna2Button53.Text = "COM226"
        '
        'Guna2Button54
        '
        Me.Guna2Button54.CheckedState.Parent = Me.Guna2Button54
        Me.Guna2Button54.CustomImages.Parent = Me.Guna2Button54
        Me.Guna2Button54.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button54.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button54.ForeColor = System.Drawing.Color.White
        Me.Guna2Button54.HoverState.Parent = Me.Guna2Button54
        Me.Guna2Button54.Location = New System.Drawing.Point(12, 266)
        Me.Guna2Button54.Name = "Guna2Button54"
        Me.Guna2Button54.ShadowDecoration.Parent = Me.Guna2Button54
        Me.Guna2Button54.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button54.TabIndex = 4
        Me.Guna2Button54.Text = "COM225"
        '
        'Guna2Button55
        '
        Me.Guna2Button55.CheckedState.Parent = Me.Guna2Button55
        Me.Guna2Button55.CustomImages.Parent = Me.Guna2Button55
        Me.Guna2Button55.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button55.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button55.ForeColor = System.Drawing.Color.White
        Me.Guna2Button55.HoverState.Parent = Me.Guna2Button55
        Me.Guna2Button55.Location = New System.Drawing.Point(12, 102)
        Me.Guna2Button55.Name = "Guna2Button55"
        Me.Guna2Button55.ShadowDecoration.Parent = Me.Guna2Button55
        Me.Guna2Button55.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button55.TabIndex = 3
        Me.Guna2Button55.Text = "COM222"
        '
        'Guna2Button56
        '
        Me.Guna2Button56.CheckedState.Parent = Me.Guna2Button56
        Me.Guna2Button56.CustomImages.Parent = Me.Guna2Button56
        Me.Guna2Button56.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button56.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button56.ForeColor = System.Drawing.Color.White
        Me.Guna2Button56.HoverState.Parent = Me.Guna2Button56
        Me.Guna2Button56.Location = New System.Drawing.Point(12, 157)
        Me.Guna2Button56.Name = "Guna2Button56"
        Me.Guna2Button56.ShadowDecoration.Parent = Me.Guna2Button56
        Me.Guna2Button56.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button56.TabIndex = 2
        Me.Guna2Button56.Text = "COM223"
        '
        'Guna2Button57
        '
        Me.Guna2Button57.CheckedState.Parent = Me.Guna2Button57
        Me.Guna2Button57.CustomImages.Parent = Me.Guna2Button57
        Me.Guna2Button57.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button57.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button57.ForeColor = System.Drawing.Color.White
        Me.Guna2Button57.HoverState.Parent = Me.Guna2Button57
        Me.Guna2Button57.Location = New System.Drawing.Point(12, 212)
        Me.Guna2Button57.Name = "Guna2Button57"
        Me.Guna2Button57.ShadowDecoration.Parent = Me.Guna2Button57
        Me.Guna2Button57.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button57.TabIndex = 1
        Me.Guna2Button57.Text = "COM224"
        '
        'Guna2Button58
        '
        Me.Guna2Button58.CheckedState.Parent = Me.Guna2Button58
        Me.Guna2Button58.CustomImages.Parent = Me.Guna2Button58
        Me.Guna2Button58.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button58.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button58.ForeColor = System.Drawing.Color.White
        Me.Guna2Button58.HoverState.Parent = Me.Guna2Button58
        Me.Guna2Button58.Location = New System.Drawing.Point(12, 47)
        Me.Guna2Button58.Name = "Guna2Button58"
        Me.Guna2Button58.ShadowDecoration.Parent = Me.Guna2Button58
        Me.Guna2Button58.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button58.TabIndex = 0
        Me.Guna2Button58.Text = "COM221"
        '
        'Guna2Button49
        '
        Me.Guna2Button49.CheckedState.Parent = Me.Guna2Button49
        Me.Guna2Button49.CustomImages.Parent = Me.Guna2Button49
        Me.Guna2Button49.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button49.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button49.ForeColor = System.Drawing.Color.White
        Me.Guna2Button49.HoverState.Parent = Me.Guna2Button49
        Me.Guna2Button49.Location = New System.Drawing.Point(214, 208)
        Me.Guna2Button49.Name = "Guna2Button49"
        Me.Guna2Button49.ShadowDecoration.Parent = Me.Guna2Button49
        Me.Guna2Button49.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button49.TabIndex = 9
        Me.Guna2Button49.Text = "2"
        '
        'btnCalculateND2S2
        '
        Me.btnCalculateND2S2.CheckedState.Parent = Me.btnCalculateND2S2
        Me.btnCalculateND2S2.CustomImages.Parent = Me.btnCalculateND2S2
        Me.btnCalculateND2S2.FillColor = System.Drawing.Color.Green
        Me.btnCalculateND2S2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateND2S2.ForeColor = System.Drawing.Color.White
        Me.btnCalculateND2S2.HoverState.Parent = Me.btnCalculateND2S2
        Me.btnCalculateND2S2.Location = New System.Drawing.Point(303, 466)
        Me.btnCalculateND2S2.Name = "btnCalculateND2S2"
        Me.btnCalculateND2S2.ShadowDecoration.Parent = Me.btnCalculateND2S2
        Me.btnCalculateND2S2.Size = New System.Drawing.Size(180, 45)
        Me.btnCalculateND2S2.TabIndex = 26
        Me.btnCalculateND2S2.Text = "CALCULATE"
        '
        'Guna2HtmlLabel34
        '
        Me.Guna2HtmlLabel34.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel34.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel34.Location = New System.Drawing.Point(532, 392)
        Me.Guna2HtmlLabel34.Name = "Guna2HtmlLabel34"
        Me.Guna2HtmlLabel34.Size = New System.Drawing.Size(395, 18)
        Me.Guna2HtmlLabel34.TabIndex = 24
        Me.Guna2HtmlLabel34.Text = "ENTER SCORE FOR  COMMUNICATION IN ENGLISH II" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fo" & _
            "re color/>"
        '
        'com229_txt
        '
        Me.com229_txt.BackColor = System.Drawing.Color.White
        Me.com229_txt.BorderRadius = 10
        Me.com229_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com229_txt.BorderThickness = 0
        Me.com229_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com229_txt.DefaultText = ""
        Me.com229_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com229_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com229_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com229_txt.DisabledState.Parent = Me.com229_txt
        Me.com229_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com229_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com229_txt.FocusedState.Parent = Me.com229_txt
        Me.com229_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com229_txt.ForeColor = System.Drawing.Color.Black
        Me.com229_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com229_txt.HoverState.Parent = Me.com229_txt
        Me.com229_txt.Location = New System.Drawing.Point(553, 325)
        Me.com229_txt.Name = "com229_txt"
        Me.com229_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com229_txt.PlaceholderText = ""
        Me.com229_txt.SelectedText = ""
        Me.com229_txt.ShadowDecoration.Parent = Me.com229_txt
        Me.com229_txt.Size = New System.Drawing.Size(200, 36)
        Me.com229_txt.TabIndex = 23
        '
        'Guna2HtmlLabel35
        '
        Me.Guna2HtmlLabel35.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel35.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel35.Location = New System.Drawing.Point(529, 281)
        Me.Guna2HtmlLabel35.Name = "Guna2HtmlLabel35"
        Me.Guna2HtmlLabel35.Size = New System.Drawing.Size(238, 18)
        Me.Guna2HtmlLabel35.TabIndex = 22
        Me.Guna2HtmlLabel35.Text = "ENTER SCORE FOR   PROJECT" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>"
        '
        'com226_txt
        '
        Me.com226_txt.BackColor = System.Drawing.Color.White
        Me.com226_txt.BorderRadius = 10
        Me.com226_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com226_txt.BorderThickness = 0
        Me.com226_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com226_txt.DefaultText = ""
        Me.com226_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com226_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com226_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com226_txt.DisabledState.Parent = Me.com226_txt
        Me.com226_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com226_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com226_txt.FocusedState.Parent = Me.com226_txt
        Me.com226_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com226_txt.ForeColor = System.Drawing.Color.Black
        Me.com226_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com226_txt.HoverState.Parent = Me.com226_txt
        Me.com226_txt.Location = New System.Drawing.Point(553, 222)
        Me.com226_txt.Name = "com226_txt"
        Me.com226_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com226_txt.PlaceholderText = ""
        Me.com226_txt.SelectedText = ""
        Me.com226_txt.ShadowDecoration.Parent = Me.com226_txt
        Me.com226_txt.Size = New System.Drawing.Size(200, 36)
        Me.com226_txt.TabIndex = 21
        '
        'Guna2HtmlLabel36
        '
        Me.Guna2HtmlLabel36.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel36.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel36.Location = New System.Drawing.Point(524, 174)
        Me.Guna2HtmlLabel36.Name = "Guna2HtmlLabel36"
        Me.Guna2HtmlLabel36.Size = New System.Drawing.Size(464, 18)
        Me.Guna2HtmlLabel36.TabIndex = 20
        Me.Guna2HtmlLabel36.Text = "ENTER SCORE FOR  FILE ORGANISATION AND MANAGEMENT" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</f" & _
            "ore color/>"
        '
        'com225_txt
        '
        Me.com225_txt.BackColor = System.Drawing.Color.White
        Me.com225_txt.BorderRadius = 10
        Me.com225_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com225_txt.BorderThickness = 0
        Me.com225_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com225_txt.DefaultText = ""
        Me.com225_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com225_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com225_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com225_txt.DisabledState.Parent = Me.com225_txt
        Me.com225_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com225_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com225_txt.FocusedState.Parent = Me.com225_txt
        Me.com225_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com225_txt.ForeColor = System.Drawing.Color.Black
        Me.com225_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com225_txt.HoverState.Parent = Me.com225_txt
        Me.com225_txt.Location = New System.Drawing.Point(553, 123)
        Me.com225_txt.Name = "com225_txt"
        Me.com225_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com225_txt.PlaceholderText = ""
        Me.com225_txt.SelectedText = ""
        Me.com225_txt.ShadowDecoration.Parent = Me.com225_txt
        Me.com225_txt.Size = New System.Drawing.Size(200, 36)
        Me.com225_txt.TabIndex = 19
        '
        'com224_txt
        '
        Me.com224_txt.BackColor = System.Drawing.Color.White
        Me.com224_txt.BorderRadius = 10
        Me.com224_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com224_txt.BorderThickness = 0
        Me.com224_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com224_txt.DefaultText = ""
        Me.com224_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com224_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com224_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com224_txt.DisabledState.Parent = Me.com224_txt
        Me.com224_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com224_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com224_txt.FocusedState.Parent = Me.com224_txt
        Me.com224_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com224_txt.ForeColor = System.Drawing.Color.Black
        Me.com224_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com224_txt.HoverState.Parent = Me.com224_txt
        Me.com224_txt.Location = New System.Drawing.Point(37, 430)
        Me.com224_txt.Name = "com224_txt"
        Me.com224_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com224_txt.PlaceholderText = ""
        Me.com224_txt.SelectedText = ""
        Me.com224_txt.ShadowDecoration.Parent = Me.com224_txt
        Me.com224_txt.Size = New System.Drawing.Size(200, 36)
        Me.com224_txt.TabIndex = 18
        '
        'com223_txt
        '
        Me.com223_txt.BackColor = System.Drawing.Color.White
        Me.com223_txt.BorderRadius = 10
        Me.com223_txt.BorderThickness = 0
        Me.com223_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com223_txt.DefaultText = ""
        Me.com223_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com223_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com223_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com223_txt.DisabledState.Parent = Me.com223_txt
        Me.com223_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com223_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com223_txt.FocusedState.Parent = Me.com223_txt
        Me.com223_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com223_txt.ForeColor = System.Drawing.Color.Black
        Me.com223_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com223_txt.HoverState.Parent = Me.com223_txt
        Me.com223_txt.Location = New System.Drawing.Point(37, 325)
        Me.com223_txt.Name = "com223_txt"
        Me.com223_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com223_txt.PlaceholderText = ""
        Me.com223_txt.SelectedText = ""
        Me.com223_txt.ShadowDecoration.Parent = Me.com223_txt
        Me.com223_txt.Size = New System.Drawing.Size(200, 36)
        Me.com223_txt.TabIndex = 17
        '
        'com222_txt
        '
        Me.com222_txt.BackColor = System.Drawing.Color.White
        Me.com222_txt.BorderRadius = 10
        Me.com222_txt.BorderThickness = 0
        Me.com222_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com222_txt.DefaultText = ""
        Me.com222_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com222_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com222_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com222_txt.DisabledState.Parent = Me.com222_txt
        Me.com222_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com222_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com222_txt.FocusedState.Parent = Me.com222_txt
        Me.com222_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com222_txt.ForeColor = System.Drawing.Color.Black
        Me.com222_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com222_txt.HoverState.Parent = Me.com222_txt
        Me.com222_txt.Location = New System.Drawing.Point(37, 230)
        Me.com222_txt.Name = "com222_txt"
        Me.com222_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com222_txt.PlaceholderText = ""
        Me.com222_txt.SelectedText = ""
        Me.com222_txt.ShadowDecoration.Parent = Me.com222_txt
        Me.com222_txt.Size = New System.Drawing.Size(200, 36)
        Me.com222_txt.TabIndex = 16
        '
        'com221_txt
        '
        Me.com221_txt.BackColor = System.Drawing.Color.White
        Me.com221_txt.BorderRadius = 10
        Me.com221_txt.BorderThickness = 0
        Me.com221_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com221_txt.DefaultText = ""
        Me.com221_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com221_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com221_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com221_txt.DisabledState.Parent = Me.com221_txt
        Me.com221_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com221_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com221_txt.FocusedState.Parent = Me.com221_txt
        Me.com221_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com221_txt.ForeColor = System.Drawing.Color.Black
        Me.com221_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com221_txt.HoverState.Parent = Me.com221_txt
        Me.com221_txt.Location = New System.Drawing.Point(37, 120)
        Me.com221_txt.Name = "com221_txt"
        Me.com221_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com221_txt.PlaceholderText = ""
        Me.com221_txt.SelectedText = ""
        Me.com221_txt.ShadowDecoration.Parent = Me.com221_txt
        Me.com221_txt.Size = New System.Drawing.Size(200, 36)
        Me.com221_txt.TabIndex = 15
        '
        'Guna2HtmlLabel37
        '
        Me.Guna2HtmlLabel37.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel37.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel37.Location = New System.Drawing.Point(529, 85)
        Me.Guna2HtmlLabel37.Name = "Guna2HtmlLabel37"
        Me.Guna2HtmlLabel37.Size = New System.Drawing.Size(309, 18)
        Me.Guna2HtmlLabel37.TabIndex = 14
        Me.Guna2HtmlLabel37.Text = "ENTER SCORE FOR WEB TECHNOLOGY" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel38
        '
        Me.Guna2HtmlLabel38.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel38.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel38.Location = New System.Drawing.Point(13, 392)
        Me.Guna2HtmlLabel38.Name = "Guna2HtmlLabel38"
        Me.Guna2HtmlLabel38.Size = New System.Drawing.Size(449, 18)
        Me.Guna2HtmlLabel38.TabIndex = 13
        Me.Guna2HtmlLabel38.Text = "ENTER SCORE FOR MANAGEMENT INFORMATION SYSTEM" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore co" & _
            "lor/>"
        '
        'Guna2HtmlLabel39
        '
        Me.Guna2HtmlLabel39.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel39.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel39.Location = New System.Drawing.Point(25, 281)
        Me.Guna2HtmlLabel39.Name = "Guna2HtmlLabel39"
        Me.Guna2HtmlLabel39.Size = New System.Drawing.Size(417, 18)
        Me.Guna2HtmlLabel39.TabIndex = 11
        Me.Guna2HtmlLabel39.Text = "ENTER SCORE FOR BASIC HARDWARE MAINTENANCE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>" & _
            ""
        '
        'Guna2HtmlLabel40
        '
        Me.Guna2HtmlLabel40.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel40.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel40.Location = New System.Drawing.Point(16, 177)
        Me.Guna2HtmlLabel40.Name = "Guna2HtmlLabel40"
        Me.Guna2HtmlLabel40.Size = New System.Drawing.Size(456, 18)
        Me.Guna2HtmlLabel40.TabIndex = 9
        Me.Guna2HtmlLabel40.Text = "ENTER SCORE FOR SEMINAR ON COMPUTER AND SOCIETY" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore co" & _
            "lor/>"
        '
        'Guna2HtmlLabel41
        '
        Me.Guna2HtmlLabel41.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel41.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel41.Location = New System.Drawing.Point(25, 85)
        Me.Guna2HtmlLabel41.Name = "Guna2HtmlLabel41"
        Me.Guna2HtmlLabel41.Size = New System.Drawing.Size(407, 18)
        Me.Guna2HtmlLabel41.TabIndex = 2
        Me.Guna2HtmlLabel41.Text = "ENTER SCORE FOR BASIC COMPUTER NETWORKING" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>"
        '
        'gns202_txt
        '
        Me.gns202_txt.BackColor = System.Drawing.Color.White
        Me.gns202_txt.BorderRadius = 10
        Me.gns202_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.gns202_txt.BorderThickness = 0
        Me.gns202_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gns202_txt.DefaultText = ""
        Me.gns202_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gns202_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gns202_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns202_txt.DisabledState.Parent = Me.gns202_txt
        Me.gns202_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns202_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns202_txt.FocusedState.Parent = Me.gns202_txt
        Me.gns202_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gns202_txt.ForeColor = System.Drawing.Color.Black
        Me.gns202_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns202_txt.HoverState.Parent = Me.gns202_txt
        Me.gns202_txt.Location = New System.Drawing.Point(553, 430)
        Me.gns202_txt.Name = "gns202_txt"
        Me.gns202_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gns202_txt.PlaceholderText = ""
        Me.gns202_txt.SelectedText = ""
        Me.gns202_txt.ShadowDecoration.Parent = Me.gns202_txt
        Me.gns202_txt.Size = New System.Drawing.Size(200, 36)
        Me.gns202_txt.TabIndex = 25
        '
        'btnBack_ND2S2
        '
        Me.btnBack_ND2S2.CheckedState.Parent = Me.btnBack_ND2S2
        Me.btnBack_ND2S2.CustomImages.Parent = Me.btnBack_ND2S2
        Me.btnBack_ND2S2.FillColor = System.Drawing.Color.Gray
        Me.btnBack_ND2S2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_ND2S2.ForeColor = System.Drawing.Color.White
        Me.btnBack_ND2S2.HoverState.Parent = Me.btnBack_ND2S2
        Me.btnBack_ND2S2.Location = New System.Drawing.Point(873, 551)
        Me.btnBack_ND2S2.Name = "btnBack_ND2S2"
        Me.btnBack_ND2S2.ShadowDecoration.Parent = Me.btnBack_ND2S2
        Me.btnBack_ND2S2.Size = New System.Drawing.Size(133, 45)
        Me.btnBack_ND2S2.TabIndex = 37
        Me.btnBack_ND2S2.Text = "BACK TO MAIN "
        '
        'pnlND2_S1_Calculator
        '
        Me.pnlND2_S1_Calculator.BackColor = System.Drawing.Color.Silver
        Me.pnlND2_S1_Calculator.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.pnlND2_S1_Calculator.Controls.Add(Me.com215_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel54)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.btnClear_ND2S1)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.btnExit_ND2S1)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel42)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel43)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel44)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel45)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.grade_txt_ND2S1)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.gradePoint_txt_ND2S1)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.totalScorePoint_txt_ND2S1)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2GroupBox1)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.btnCalculateND2S1)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel46)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.gns201_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel47)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.eed216_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel48)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.com216_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.com214_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.com213_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.com212_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.com211_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel49)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel50)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel51)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel52)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.Guna2HtmlLabel53)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.sws210_txt)
        Me.pnlND2_S1_Calculator.Controls.Add(Me.btnBack_ND2S1)
        Me.pnlND2_S1_Calculator.Location = New System.Drawing.Point(2, 15)
        Me.pnlND2_S1_Calculator.Name = "pnlND2_S1_Calculator"
        Me.pnlND2_S1_Calculator.ShadowDecoration.Parent = Me.pnlND2_S1_Calculator
        Me.pnlND2_S1_Calculator.Size = New System.Drawing.Size(1320, 619)
        Me.pnlND2_S1_Calculator.TabIndex = 5
        Me.pnlND2_S1_Calculator.Visible = False
        '
        'com215_txt
        '
        Me.com215_txt.BackColor = System.Drawing.Color.White
        Me.com215_txt.BorderRadius = 10
        Me.com215_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com215_txt.BorderThickness = 0
        Me.com215_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com215_txt.DefaultText = ""
        Me.com215_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com215_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com215_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com215_txt.DisabledState.Parent = Me.com215_txt
        Me.com215_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com215_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com215_txt.FocusedState.Parent = Me.com215_txt
        Me.com215_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com215_txt.ForeColor = System.Drawing.Color.Black
        Me.com215_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com215_txt.HoverState.Parent = Me.com215_txt
        Me.com215_txt.Location = New System.Drawing.Point(38, 475)
        Me.com215_txt.Name = "com215_txt"
        Me.com215_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com215_txt.PlaceholderText = ""
        Me.com215_txt.SelectedText = ""
        Me.com215_txt.ShadowDecoration.Parent = Me.com215_txt
        Me.com215_txt.Size = New System.Drawing.Size(200, 36)
        Me.com215_txt.TabIndex = 39
        '
        'Guna2HtmlLabel54
        '
        Me.Guna2HtmlLabel54.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel54.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel54.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel54.Location = New System.Drawing.Point(14, 437)
        Me.Guna2HtmlLabel54.Name = "Guna2HtmlLabel54"
        Me.Guna2HtmlLabel54.Size = New System.Drawing.Size(349, 18)
        Me.Guna2HtmlLabel54.TabIndex = 38
        Me.Guna2HtmlLabel54.Text = "ENTER SCORE FOR COMPUTER PACKAGES II" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>"
        '
        'btnClear_ND2S1
        '
        Me.btnClear_ND2S1.CheckedState.Parent = Me.btnClear_ND2S1
        Me.btnClear_ND2S1.CustomImages.Parent = Me.btnClear_ND2S1
        Me.btnClear_ND2S1.FillColor = System.Drawing.Color.DarkOrange
        Me.btnClear_ND2S1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear_ND2S1.ForeColor = System.Drawing.Color.White
        Me.btnClear_ND2S1.HoverState.Parent = Me.btnClear_ND2S1
        Me.btnClear_ND2S1.Location = New System.Drawing.Point(1214, 551)
        Me.btnClear_ND2S1.Name = "btnClear_ND2S1"
        Me.btnClear_ND2S1.ShadowDecoration.Parent = Me.btnClear_ND2S1
        Me.btnClear_ND2S1.Size = New System.Drawing.Size(90, 45)
        Me.btnClear_ND2S1.TabIndex = 36
        Me.btnClear_ND2S1.Text = "CLEAR"
        '
        'btnExit_ND2S1
        '
        Me.btnExit_ND2S1.CheckedState.Parent = Me.btnExit_ND2S1
        Me.btnExit_ND2S1.CustomImages.Parent = Me.btnExit_ND2S1
        Me.btnExit_ND2S1.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnExit_ND2S1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit_ND2S1.ForeColor = System.Drawing.Color.White
        Me.btnExit_ND2S1.HoverState.Parent = Me.btnExit_ND2S1
        Me.btnExit_ND2S1.Location = New System.Drawing.Point(1054, 551)
        Me.btnExit_ND2S1.Name = "btnExit_ND2S1"
        Me.btnExit_ND2S1.ShadowDecoration.Parent = Me.btnExit_ND2S1
        Me.btnExit_ND2S1.Size = New System.Drawing.Size(90, 45)
        Me.btnExit_ND2S1.TabIndex = 35
        Me.btnExit_ND2S1.Text = "EXIT"
        '
        'Guna2HtmlLabel42
        '
        Me.Guna2HtmlLabel42.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel42.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel42.ForeColor = System.Drawing.Color.Navy
        Me.Guna2HtmlLabel42.Location = New System.Drawing.Point(457, 34)
        Me.Guna2HtmlLabel42.Name = "Guna2HtmlLabel42"
        Me.Guna2HtmlLabel42.Size = New System.Drawing.Size(202, 22)
        Me.Guna2HtmlLabel42.TabIndex = 34
        Me.Guna2HtmlLabel42.Text = "ND 2 FIRST SEMESTER"
        '
        'Guna2HtmlLabel43
        '
        Me.Guna2HtmlLabel43.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel43.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel43.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel43.Location = New System.Drawing.Point(603, 539)
        Me.Guna2HtmlLabel43.Name = "Guna2HtmlLabel43"
        Me.Guna2HtmlLabel43.Size = New System.Drawing.Size(191, 20)
        Me.Guna2HtmlLabel43.TabIndex = 33
        Me.Guna2HtmlLabel43.Text = "TOTAL SCORE POINT:  <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel44
        '
        Me.Guna2HtmlLabel44.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel44.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel44.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel44.Location = New System.Drawing.Point(337, 537)
        Me.Guna2HtmlLabel44.Name = "Guna2HtmlLabel44"
        Me.Guna2HtmlLabel44.Size = New System.Drawing.Size(133, 20)
        Me.Guna2HtmlLabel44.TabIndex = 32
        Me.Guna2HtmlLabel44.Text = "GRADE POINT: <fore color = ""red"">*</fore color/>"
        Me.Guna2HtmlLabel44.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Guna2HtmlLabel45
        '
        Me.Guna2HtmlLabel45.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel45.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel45.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel45.Location = New System.Drawing.Point(38, 535)
        Me.Guna2HtmlLabel45.Name = "Guna2HtmlLabel45"
        Me.Guna2HtmlLabel45.Size = New System.Drawing.Size(78, 20)
        Me.Guna2HtmlLabel45.TabIndex = 31
        Me.Guna2HtmlLabel45.Text = "GRADE: <fore color = ""red"">*</fore color/>"
        '
        'grade_txt_ND2S1
        '
        Me.grade_txt_ND2S1.BackColor = System.Drawing.Color.White
        Me.grade_txt_ND2S1.BorderRadius = 10
        Me.grade_txt_ND2S1.BorderThickness = 0
        Me.grade_txt_ND2S1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.grade_txt_ND2S1.DefaultText = ""
        Me.grade_txt_ND2S1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.grade_txt_ND2S1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.grade_txt_ND2S1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.grade_txt_ND2S1.DisabledState.Parent = Me.grade_txt_ND2S1
        Me.grade_txt_ND2S1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.grade_txt_ND2S1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grade_txt_ND2S1.FocusedState.Parent = Me.grade_txt_ND2S1
        Me.grade_txt_ND2S1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grade_txt_ND2S1.ForeColor = System.Drawing.Color.Black
        Me.grade_txt_ND2S1.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.grade_txt_ND2S1.HoverState.Parent = Me.grade_txt_ND2S1
        Me.grade_txt_ND2S1.Location = New System.Drawing.Point(32, 565)
        Me.grade_txt_ND2S1.Name = "grade_txt_ND2S1"
        Me.grade_txt_ND2S1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.grade_txt_ND2S1.PlaceholderText = ""
        Me.grade_txt_ND2S1.SelectedText = ""
        Me.grade_txt_ND2S1.ShadowDecoration.Parent = Me.grade_txt_ND2S1
        Me.grade_txt_ND2S1.Size = New System.Drawing.Size(200, 36)
        Me.grade_txt_ND2S1.TabIndex = 30
        '
        'gradePoint_txt_ND2S1
        '
        Me.gradePoint_txt_ND2S1.BackColor = System.Drawing.Color.White
        Me.gradePoint_txt_ND2S1.BorderRadius = 10
        Me.gradePoint_txt_ND2S1.BorderThickness = 0
        Me.gradePoint_txt_ND2S1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gradePoint_txt_ND2S1.DefaultText = ""
        Me.gradePoint_txt_ND2S1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gradePoint_txt_ND2S1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gradePoint_txt_ND2S1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gradePoint_txt_ND2S1.DisabledState.Parent = Me.gradePoint_txt_ND2S1
        Me.gradePoint_txt_ND2S1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gradePoint_txt_ND2S1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gradePoint_txt_ND2S1.FocusedState.Parent = Me.gradePoint_txt_ND2S1
        Me.gradePoint_txt_ND2S1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gradePoint_txt_ND2S1.ForeColor = System.Drawing.Color.Black
        Me.gradePoint_txt_ND2S1.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gradePoint_txt_ND2S1.HoverState.Parent = Me.gradePoint_txt_ND2S1
        Me.gradePoint_txt_ND2S1.Location = New System.Drawing.Point(321, 565)
        Me.gradePoint_txt_ND2S1.Name = "gradePoint_txt_ND2S1"
        Me.gradePoint_txt_ND2S1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gradePoint_txt_ND2S1.PlaceholderText = ""
        Me.gradePoint_txt_ND2S1.SelectedText = ""
        Me.gradePoint_txt_ND2S1.ShadowDecoration.Parent = Me.gradePoint_txt_ND2S1
        Me.gradePoint_txt_ND2S1.Size = New System.Drawing.Size(200, 36)
        Me.gradePoint_txt_ND2S1.TabIndex = 29
        '
        'totalScorePoint_txt_ND2S1
        '
        Me.totalScorePoint_txt_ND2S1.BackColor = System.Drawing.Color.White
        Me.totalScorePoint_txt_ND2S1.BorderRadius = 10
        Me.totalScorePoint_txt_ND2S1.BorderThickness = 0
        Me.totalScorePoint_txt_ND2S1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalScorePoint_txt_ND2S1.DefaultText = ""
        Me.totalScorePoint_txt_ND2S1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.totalScorePoint_txt_ND2S1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.totalScorePoint_txt_ND2S1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalScorePoint_txt_ND2S1.DisabledState.Parent = Me.totalScorePoint_txt_ND2S1
        Me.totalScorePoint_txt_ND2S1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalScorePoint_txt_ND2S1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalScorePoint_txt_ND2S1.FocusedState.Parent = Me.totalScorePoint_txt_ND2S1
        Me.totalScorePoint_txt_ND2S1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalScorePoint_txt_ND2S1.ForeColor = System.Drawing.Color.Black
        Me.totalScorePoint_txt_ND2S1.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalScorePoint_txt_ND2S1.HoverState.Parent = Me.totalScorePoint_txt_ND2S1
        Me.totalScorePoint_txt_ND2S1.Location = New System.Drawing.Point(605, 567)
        Me.totalScorePoint_txt_ND2S1.Name = "totalScorePoint_txt_ND2S1"
        Me.totalScorePoint_txt_ND2S1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.totalScorePoint_txt_ND2S1.PlaceholderText = ""
        Me.totalScorePoint_txt_ND2S1.SelectedText = ""
        Me.totalScorePoint_txt_ND2S1.ShadowDecoration.Parent = Me.totalScorePoint_txt_ND2S1
        Me.totalScorePoint_txt_ND2S1.Size = New System.Drawing.Size(200, 36)
        Me.totalScorePoint_txt_ND2S1.TabIndex = 28
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button62)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button61)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button23)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button24)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button25)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button26)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button27)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button28)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button29)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button30)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button31)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button32)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button33)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button34)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button35)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button36)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button38)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2Button39)
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(1001, 34)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(294, 484)
        Me.Guna2GroupBox1.TabIndex = 27
        Me.Guna2GroupBox1.Text = " COURSE UNIT"
        '
        'Guna2Button62
        '
        Me.Guna2Button62.CheckedState.Parent = Me.Guna2Button62
        Me.Guna2Button62.CustomImages.Parent = Me.Guna2Button62
        Me.Guna2Button62.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button62.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button62.ForeColor = System.Drawing.Color.White
        Me.Guna2Button62.HoverState.Parent = Me.Guna2Button62
        Me.Guna2Button62.Location = New System.Drawing.Point(212, 436)
        Me.Guna2Button62.Name = "Guna2Button62"
        Me.Guna2Button62.ShadowDecoration.Parent = Me.Guna2Button62
        Me.Guna2Button62.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button62.TabIndex = 17
        Me.Guna2Button62.Text = "4"
        '
        'Guna2Button61
        '
        Me.Guna2Button61.CheckedState.Parent = Me.Guna2Button61
        Me.Guna2Button61.CustomImages.Parent = Me.Guna2Button61
        Me.Guna2Button61.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button61.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button61.ForeColor = System.Drawing.Color.White
        Me.Guna2Button61.HoverState.Parent = Me.Guna2Button61
        Me.Guna2Button61.Location = New System.Drawing.Point(13, 437)
        Me.Guna2Button61.Name = "Guna2Button61"
        Me.Guna2Button61.ShadowDecoration.Parent = Me.Guna2Button61
        Me.Guna2Button61.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button61.TabIndex = 16
        Me.Guna2Button61.Text = "SWS210"
        '
        'Guna2Button23
        '
        Me.Guna2Button23.CheckedState.Parent = Me.Guna2Button23
        Me.Guna2Button23.CustomImages.Parent = Me.Guna2Button23
        Me.Guna2Button23.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button23.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button23.ForeColor = System.Drawing.Color.White
        Me.Guna2Button23.HoverState.Parent = Me.Guna2Button23
        Me.Guna2Button23.Location = New System.Drawing.Point(212, 389)
        Me.Guna2Button23.Name = "Guna2Button23"
        Me.Guna2Button23.ShadowDecoration.Parent = Me.Guna2Button23
        Me.Guna2Button23.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button23.TabIndex = 15
        Me.Guna2Button23.Text = "2"
        '
        'Guna2Button24
        '
        Me.Guna2Button24.CheckedState.Parent = Me.Guna2Button24
        Me.Guna2Button24.CustomImages.Parent = Me.Guna2Button24
        Me.Guna2Button24.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button24.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button24.ForeColor = System.Drawing.Color.White
        Me.Guna2Button24.HoverState.Parent = Me.Guna2Button24
        Me.Guna2Button24.Location = New System.Drawing.Point(212, 343)
        Me.Guna2Button24.Name = "Guna2Button24"
        Me.Guna2Button24.ShadowDecoration.Parent = Me.Guna2Button24
        Me.Guna2Button24.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button24.TabIndex = 14
        Me.Guna2Button24.Text = "2"
        '
        'Guna2Button25
        '
        Me.Guna2Button25.CheckedState.Parent = Me.Guna2Button25
        Me.Guna2Button25.CustomImages.Parent = Me.Guna2Button25
        Me.Guna2Button25.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button25.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button25.ForeColor = System.Drawing.Color.White
        Me.Guna2Button25.HoverState.Parent = Me.Guna2Button25
        Me.Guna2Button25.Location = New System.Drawing.Point(13, 389)
        Me.Guna2Button25.Name = "Guna2Button25"
        Me.Guna2Button25.ShadowDecoration.Parent = Me.Guna2Button25
        Me.Guna2Button25.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button25.TabIndex = 13
        Me.Guna2Button25.Text = "GNS201"
        '
        'Guna2Button26
        '
        Me.Guna2Button26.CheckedState.Parent = Me.Guna2Button26
        Me.Guna2Button26.CustomImages.Parent = Me.Guna2Button26
        Me.Guna2Button26.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button26.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button26.ForeColor = System.Drawing.Color.White
        Me.Guna2Button26.HoverState.Parent = Me.Guna2Button26
        Me.Guna2Button26.Location = New System.Drawing.Point(13, 340)
        Me.Guna2Button26.Name = "Guna2Button26"
        Me.Guna2Button26.ShadowDecoration.Parent = Me.Guna2Button26
        Me.Guna2Button26.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button26.TabIndex = 12
        Me.Guna2Button26.Text = "EED216"
        '
        'Guna2Button27
        '
        Me.Guna2Button27.CheckedState.Parent = Me.Guna2Button27
        Me.Guna2Button27.CustomImages.Parent = Me.Guna2Button27
        Me.Guna2Button27.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button27.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button27.ForeColor = System.Drawing.Color.White
        Me.Guna2Button27.HoverState.Parent = Me.Guna2Button27
        Me.Guna2Button27.Location = New System.Drawing.Point(211, 95)
        Me.Guna2Button27.Name = "Guna2Button27"
        Me.Guna2Button27.ShadowDecoration.Parent = Me.Guna2Button27
        Me.Guna2Button27.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button27.TabIndex = 11
        Me.Guna2Button27.Text = "2"
        '
        'Guna2Button28
        '
        Me.Guna2Button28.CheckedState.Parent = Me.Guna2Button28
        Me.Guna2Button28.CustomImages.Parent = Me.Guna2Button28
        Me.Guna2Button28.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button28.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button28.ForeColor = System.Drawing.Color.White
        Me.Guna2Button28.HoverState.Parent = Me.Guna2Button28
        Me.Guna2Button28.Location = New System.Drawing.Point(212, 144)
        Me.Guna2Button28.Name = "Guna2Button28"
        Me.Guna2Button28.ShadowDecoration.Parent = Me.Guna2Button28
        Me.Guna2Button28.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button28.TabIndex = 10
        Me.Guna2Button28.Text = "3"
        '
        'Guna2Button29
        '
        Me.Guna2Button29.CheckedState.Parent = Me.Guna2Button29
        Me.Guna2Button29.CustomImages.Parent = Me.Guna2Button29
        Me.Guna2Button29.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button29.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button29.ForeColor = System.Drawing.Color.White
        Me.Guna2Button29.HoverState.Parent = Me.Guna2Button29
        Me.Guna2Button29.Location = New System.Drawing.Point(212, 193)
        Me.Guna2Button29.Name = "Guna2Button29"
        Me.Guna2Button29.ShadowDecoration.Parent = Me.Guna2Button29
        Me.Guna2Button29.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button29.TabIndex = 9
        Me.Guna2Button29.Text = "3"
        '
        'Guna2Button30
        '
        Me.Guna2Button30.CheckedState.Parent = Me.Guna2Button30
        Me.Guna2Button30.CustomImages.Parent = Me.Guna2Button30
        Me.Guna2Button30.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button30.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button30.ForeColor = System.Drawing.Color.White
        Me.Guna2Button30.HoverState.Parent = Me.Guna2Button30
        Me.Guna2Button30.Location = New System.Drawing.Point(212, 243)
        Me.Guna2Button30.Name = "Guna2Button30"
        Me.Guna2Button30.ShadowDecoration.Parent = Me.Guna2Button30
        Me.Guna2Button30.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button30.TabIndex = 8
        Me.Guna2Button30.Text = "3"
        '
        'Guna2Button31
        '
        Me.Guna2Button31.CheckedState.Parent = Me.Guna2Button31
        Me.Guna2Button31.CustomImages.Parent = Me.Guna2Button31
        Me.Guna2Button31.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button31.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button31.ForeColor = System.Drawing.Color.White
        Me.Guna2Button31.HoverState.Parent = Me.Guna2Button31
        Me.Guna2Button31.Location = New System.Drawing.Point(212, 292)
        Me.Guna2Button31.Name = "Guna2Button31"
        Me.Guna2Button31.ShadowDecoration.Parent = Me.Guna2Button31
        Me.Guna2Button31.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button31.TabIndex = 7
        Me.Guna2Button31.Text = "2"
        '
        'Guna2Button32
        '
        Me.Guna2Button32.CheckedState.Parent = Me.Guna2Button32
        Me.Guna2Button32.CustomImages.Parent = Me.Guna2Button32
        Me.Guna2Button32.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button32.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button32.ForeColor = System.Drawing.Color.White
        Me.Guna2Button32.HoverState.Parent = Me.Guna2Button32
        Me.Guna2Button32.Location = New System.Drawing.Point(212, 45)
        Me.Guna2Button32.Name = "Guna2Button32"
        Me.Guna2Button32.ShadowDecoration.Parent = Me.Guna2Button32
        Me.Guna2Button32.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button32.TabIndex = 6
        Me.Guna2Button32.Text = "3"
        '
        'Guna2Button33
        '
        Me.Guna2Button33.CheckedState.Parent = Me.Guna2Button33
        Me.Guna2Button33.CustomImages.Parent = Me.Guna2Button33
        Me.Guna2Button33.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button33.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button33.ForeColor = System.Drawing.Color.White
        Me.Guna2Button33.HoverState.Parent = Me.Guna2Button33
        Me.Guna2Button33.Location = New System.Drawing.Point(13, 291)
        Me.Guna2Button33.Name = "Guna2Button33"
        Me.Guna2Button33.ShadowDecoration.Parent = Me.Guna2Button33
        Me.Guna2Button33.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button33.TabIndex = 5
        Me.Guna2Button33.Text = "COM216"
        '
        'Guna2Button34
        '
        Me.Guna2Button34.CheckedState.Parent = Me.Guna2Button34
        Me.Guna2Button34.CustomImages.Parent = Me.Guna2Button34
        Me.Guna2Button34.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button34.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button34.ForeColor = System.Drawing.Color.White
        Me.Guna2Button34.HoverState.Parent = Me.Guna2Button34
        Me.Guna2Button34.Location = New System.Drawing.Point(12, 241)
        Me.Guna2Button34.Name = "Guna2Button34"
        Me.Guna2Button34.ShadowDecoration.Parent = Me.Guna2Button34
        Me.Guna2Button34.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button34.TabIndex = 4
        Me.Guna2Button34.Text = "COM215"
        '
        'Guna2Button35
        '
        Me.Guna2Button35.CheckedState.Parent = Me.Guna2Button35
        Me.Guna2Button35.CustomImages.Parent = Me.Guna2Button35
        Me.Guna2Button35.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button35.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button35.ForeColor = System.Drawing.Color.White
        Me.Guna2Button35.HoverState.Parent = Me.Guna2Button35
        Me.Guna2Button35.Location = New System.Drawing.Point(12, 95)
        Me.Guna2Button35.Name = "Guna2Button35"
        Me.Guna2Button35.ShadowDecoration.Parent = Me.Guna2Button35
        Me.Guna2Button35.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button35.TabIndex = 3
        Me.Guna2Button35.Text = "COM212"
        '
        'Guna2Button36
        '
        Me.Guna2Button36.CheckedState.Parent = Me.Guna2Button36
        Me.Guna2Button36.CustomImages.Parent = Me.Guna2Button36
        Me.Guna2Button36.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button36.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button36.ForeColor = System.Drawing.Color.White
        Me.Guna2Button36.HoverState.Parent = Me.Guna2Button36
        Me.Guna2Button36.Location = New System.Drawing.Point(12, 143)
        Me.Guna2Button36.Name = "Guna2Button36"
        Me.Guna2Button36.ShadowDecoration.Parent = Me.Guna2Button36
        Me.Guna2Button36.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button36.TabIndex = 2
        Me.Guna2Button36.Text = "COM213"
        '
        'Guna2Button38
        '
        Me.Guna2Button38.CheckedState.Parent = Me.Guna2Button38
        Me.Guna2Button38.CustomImages.Parent = Me.Guna2Button38
        Me.Guna2Button38.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button38.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button38.ForeColor = System.Drawing.Color.White
        Me.Guna2Button38.HoverState.Parent = Me.Guna2Button38
        Me.Guna2Button38.Location = New System.Drawing.Point(12, 192)
        Me.Guna2Button38.Name = "Guna2Button38"
        Me.Guna2Button38.ShadowDecoration.Parent = Me.Guna2Button38
        Me.Guna2Button38.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button38.TabIndex = 1
        Me.Guna2Button38.Text = "COM214"
        '
        'Guna2Button39
        '
        Me.Guna2Button39.CheckedState.Parent = Me.Guna2Button39
        Me.Guna2Button39.CustomImages.Parent = Me.Guna2Button39
        Me.Guna2Button39.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button39.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button39.ForeColor = System.Drawing.Color.White
        Me.Guna2Button39.HoverState.Parent = Me.Guna2Button39
        Me.Guna2Button39.Location = New System.Drawing.Point(12, 47)
        Me.Guna2Button39.Name = "Guna2Button39"
        Me.Guna2Button39.ShadowDecoration.Parent = Me.Guna2Button39
        Me.Guna2Button39.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button39.TabIndex = 0
        Me.Guna2Button39.Text = "COM211"
        '
        'btnCalculateND2S1
        '
        Me.btnCalculateND2S1.CheckedState.Parent = Me.btnCalculateND2S1
        Me.btnCalculateND2S1.CustomImages.Parent = Me.btnCalculateND2S1
        Me.btnCalculateND2S1.FillColor = System.Drawing.Color.Green
        Me.btnCalculateND2S1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateND2S1.ForeColor = System.Drawing.Color.White
        Me.btnCalculateND2S1.HoverState.Parent = Me.btnCalculateND2S1
        Me.btnCalculateND2S1.Location = New System.Drawing.Point(411, 481)
        Me.btnCalculateND2S1.Name = "btnCalculateND2S1"
        Me.btnCalculateND2S1.ShadowDecoration.Parent = Me.btnCalculateND2S1
        Me.btnCalculateND2S1.Size = New System.Drawing.Size(180, 45)
        Me.btnCalculateND2S1.TabIndex = 26
        Me.btnCalculateND2S1.Text = "CALCULATE"
        '
        'Guna2HtmlLabel46
        '
        Me.Guna2HtmlLabel46.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel46.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel46.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel46.Location = New System.Drawing.Point(482, 395)
        Me.Guna2HtmlLabel46.Name = "Guna2HtmlLabel46"
        Me.Guna2HtmlLabel46.Size = New System.Drawing.Size(507, 18)
        Me.Guna2HtmlLabel46.TabIndex = 24
        Me.Guna2HtmlLabel46.Text = "ENTER SCORE FOR  SUPERVISED INDUSTRIAL WORK EXPERIENCE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = """ & _
            "red"">*</fore color/>"
        '
        'gns201_txt
        '
        Me.gns201_txt.BackColor = System.Drawing.Color.White
        Me.gns201_txt.BorderRadius = 10
        Me.gns201_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.gns201_txt.BorderThickness = 0
        Me.gns201_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gns201_txt.DefaultText = ""
        Me.gns201_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gns201_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gns201_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns201_txt.DisabledState.Parent = Me.gns201_txt
        Me.gns201_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gns201_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns201_txt.FocusedState.Parent = Me.gns201_txt
        Me.gns201_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gns201_txt.ForeColor = System.Drawing.Color.Black
        Me.gns201_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gns201_txt.HoverState.Parent = Me.gns201_txt
        Me.gns201_txt.Location = New System.Drawing.Point(606, 337)
        Me.gns201_txt.Name = "gns201_txt"
        Me.gns201_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gns201_txt.PlaceholderText = ""
        Me.gns201_txt.SelectedText = ""
        Me.gns201_txt.ShadowDecoration.Parent = Me.gns201_txt
        Me.gns201_txt.Size = New System.Drawing.Size(200, 36)
        Me.gns201_txt.TabIndex = 23
        '
        'Guna2HtmlLabel47
        '
        Me.Guna2HtmlLabel47.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel47.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel47.Location = New System.Drawing.Point(566, 292)
        Me.Guna2HtmlLabel47.Name = "Guna2HtmlLabel47"
        Me.Guna2HtmlLabel47.Size = New System.Drawing.Size(304, 18)
        Me.Guna2HtmlLabel47.TabIndex = 22
        Me.Guna2HtmlLabel47.Text = "ENTER SCORE FOR    USE OF ENGLISH II" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>" & _
            ""
        '
        'eed216_txt
        '
        Me.eed216_txt.BackColor = System.Drawing.Color.White
        Me.eed216_txt.BorderRadius = 10
        Me.eed216_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.eed216_txt.BorderThickness = 0
        Me.eed216_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.eed216_txt.DefaultText = ""
        Me.eed216_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.eed216_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.eed216_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.eed216_txt.DisabledState.Parent = Me.eed216_txt
        Me.eed216_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.eed216_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.eed216_txt.FocusedState.Parent = Me.eed216_txt
        Me.eed216_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eed216_txt.ForeColor = System.Drawing.Color.Black
        Me.eed216_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.eed216_txt.HoverState.Parent = Me.eed216_txt
        Me.eed216_txt.Location = New System.Drawing.Point(606, 235)
        Me.eed216_txt.Name = "eed216_txt"
        Me.eed216_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.eed216_txt.PlaceholderText = ""
        Me.eed216_txt.SelectedText = ""
        Me.eed216_txt.ShadowDecoration.Parent = Me.eed216_txt
        Me.eed216_txt.Size = New System.Drawing.Size(200, 36)
        Me.eed216_txt.TabIndex = 21
        '
        'Guna2HtmlLabel48
        '
        Me.Guna2HtmlLabel48.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel48.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel48.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel48.Location = New System.Drawing.Point(564, 196)
        Me.Guna2HtmlLabel48.Name = "Guna2HtmlLabel48"
        Me.Guna2HtmlLabel48.Size = New System.Drawing.Size(422, 18)
        Me.Guna2HtmlLabel48.TabIndex = 20
        Me.Guna2HtmlLabel48.Text = "ENTER SCORE FOR  PRATICE OF ENTREPRENEURSHIP " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore " & _
            "color/>"
        '
        'com216_txt
        '
        Me.com216_txt.BackColor = System.Drawing.Color.White
        Me.com216_txt.BorderRadius = 10
        Me.com216_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com216_txt.BorderThickness = 0
        Me.com216_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com216_txt.DefaultText = ""
        Me.com216_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com216_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com216_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com216_txt.DisabledState.Parent = Me.com216_txt
        Me.com216_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com216_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com216_txt.FocusedState.Parent = Me.com216_txt
        Me.com216_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com216_txt.ForeColor = System.Drawing.Color.Black
        Me.com216_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com216_txt.HoverState.Parent = Me.com216_txt
        Me.com216_txt.Location = New System.Drawing.Point(606, 127)
        Me.com216_txt.Name = "com216_txt"
        Me.com216_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com216_txt.PlaceholderText = ""
        Me.com216_txt.SelectedText = ""
        Me.com216_txt.ShadowDecoration.Parent = Me.com216_txt
        Me.com216_txt.Size = New System.Drawing.Size(200, 36)
        Me.com216_txt.TabIndex = 19
        '
        'com214_txt
        '
        Me.com214_txt.BackColor = System.Drawing.Color.White
        Me.com214_txt.BorderRadius = 10
        Me.com214_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.com214_txt.BorderThickness = 0
        Me.com214_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com214_txt.DefaultText = ""
        Me.com214_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com214_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com214_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com214_txt.DisabledState.Parent = Me.com214_txt
        Me.com214_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com214_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com214_txt.FocusedState.Parent = Me.com214_txt
        Me.com214_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com214_txt.ForeColor = System.Drawing.Color.Black
        Me.com214_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com214_txt.HoverState.Parent = Me.com214_txt
        Me.com214_txt.Location = New System.Drawing.Point(37, 381)
        Me.com214_txt.Name = "com214_txt"
        Me.com214_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com214_txt.PlaceholderText = ""
        Me.com214_txt.SelectedText = ""
        Me.com214_txt.ShadowDecoration.Parent = Me.com214_txt
        Me.com214_txt.Size = New System.Drawing.Size(200, 36)
        Me.com214_txt.TabIndex = 18
        '
        'com213_txt
        '
        Me.com213_txt.BackColor = System.Drawing.Color.White
        Me.com213_txt.BorderRadius = 10
        Me.com213_txt.BorderThickness = 0
        Me.com213_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com213_txt.DefaultText = ""
        Me.com213_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com213_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com213_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com213_txt.DisabledState.Parent = Me.com213_txt
        Me.com213_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com213_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com213_txt.FocusedState.Parent = Me.com213_txt
        Me.com213_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com213_txt.ForeColor = System.Drawing.Color.Black
        Me.com213_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com213_txt.HoverState.Parent = Me.com213_txt
        Me.com213_txt.Location = New System.Drawing.Point(38, 293)
        Me.com213_txt.Name = "com213_txt"
        Me.com213_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com213_txt.PlaceholderText = ""
        Me.com213_txt.SelectedText = ""
        Me.com213_txt.ShadowDecoration.Parent = Me.com213_txt
        Me.com213_txt.Size = New System.Drawing.Size(200, 36)
        Me.com213_txt.TabIndex = 17
        '
        'com212_txt
        '
        Me.com212_txt.BackColor = System.Drawing.Color.White
        Me.com212_txt.BorderRadius = 10
        Me.com212_txt.BorderThickness = 0
        Me.com212_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com212_txt.DefaultText = ""
        Me.com212_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com212_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com212_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com212_txt.DisabledState.Parent = Me.com212_txt
        Me.com212_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com212_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com212_txt.FocusedState.Parent = Me.com212_txt
        Me.com212_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com212_txt.ForeColor = System.Drawing.Color.Black
        Me.com212_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com212_txt.HoverState.Parent = Me.com212_txt
        Me.com212_txt.Location = New System.Drawing.Point(38, 209)
        Me.com212_txt.Name = "com212_txt"
        Me.com212_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com212_txt.PlaceholderText = ""
        Me.com212_txt.SelectedText = ""
        Me.com212_txt.ShadowDecoration.Parent = Me.com212_txt
        Me.com212_txt.Size = New System.Drawing.Size(200, 36)
        Me.com212_txt.TabIndex = 16
        '
        'com211_txt
        '
        Me.com211_txt.BackColor = System.Drawing.Color.White
        Me.com211_txt.BorderRadius = 10
        Me.com211_txt.BorderThickness = 0
        Me.com211_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.com211_txt.DefaultText = ""
        Me.com211_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.com211_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.com211_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com211_txt.DisabledState.Parent = Me.com211_txt
        Me.com211_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.com211_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com211_txt.FocusedState.Parent = Me.com211_txt
        Me.com211_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.com211_txt.ForeColor = System.Drawing.Color.Black
        Me.com211_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.com211_txt.HoverState.Parent = Me.com211_txt
        Me.com211_txt.Location = New System.Drawing.Point(37, 120)
        Me.com211_txt.Name = "com211_txt"
        Me.com211_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.com211_txt.PlaceholderText = ""
        Me.com211_txt.SelectedText = ""
        Me.com211_txt.ShadowDecoration.Parent = Me.com211_txt
        Me.com211_txt.Size = New System.Drawing.Size(200, 36)
        Me.com211_txt.TabIndex = 15
        '
        'Guna2HtmlLabel49
        '
        Me.Guna2HtmlLabel49.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel49.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel49.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel49.Location = New System.Drawing.Point(544, 88)
        Me.Guna2HtmlLabel49.Name = "Guna2HtmlLabel49"
        Me.Guna2HtmlLabel49.Size = New System.Drawing.Size(397, 18)
        Me.Guna2HtmlLabel49.TabIndex = 14
        Me.Guna2HtmlLabel49.Text = "ENTER SCORE FOR STATISTICS FOR COMPUTING II" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore colo" & _
            "r/>"
        '
        'Guna2HtmlLabel50
        '
        Me.Guna2HtmlLabel50.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel50.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel50.Location = New System.Drawing.Point(20, 347)
        Me.Guna2HtmlLabel50.Name = "Guna2HtmlLabel50"
        Me.Guna2HtmlLabel50.Size = New System.Drawing.Size(483, 18)
        Me.Guna2HtmlLabel50.TabIndex = 13
        Me.Guna2HtmlLabel50.Text = "ENTER SCORE FOR COMPUTER SYSTEMS TROUBLESHOOTING" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore" & _
            " color/>"
        '
        'Guna2HtmlLabel51
        '
        Me.Guna2HtmlLabel51.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel51.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel51.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel51.Location = New System.Drawing.Point(25, 263)
        Me.Guna2HtmlLabel51.Name = "Guna2HtmlLabel51"
        Me.Guna2HtmlLabel51.Size = New System.Drawing.Size(439, 18)
        Me.Guna2HtmlLabel51.TabIndex = 11
        Me.Guna2HtmlLabel51.Text = "ENTER SCORE FOR UNIFIED MODELLING LANGUAGE UML" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore col" & _
            "or/>"
        '
        'Guna2HtmlLabel52
        '
        Me.Guna2HtmlLabel52.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel52.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel52.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel52.Location = New System.Drawing.Point(37, 176)
        Me.Guna2HtmlLabel52.Name = "Guna2HtmlLabel52"
        Me.Guna2HtmlLabel52.Size = New System.Drawing.Size(491, 18)
        Me.Guna2HtmlLabel52.TabIndex = 9
        Me.Guna2HtmlLabel52.Text = "ENTER SCORE FOR INTODUCTION TO SYSTEMS PROGRAMMING" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore" & _
            " color/>"
        '
        'Guna2HtmlLabel53
        '
        Me.Guna2HtmlLabel53.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel53.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel53.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel53.Location = New System.Drawing.Point(25, 85)
        Me.Guna2HtmlLabel53.Name = "Guna2HtmlLabel53"
        Me.Guna2HtmlLabel53.Size = New System.Drawing.Size(473, 18)
        Me.Guna2HtmlLabel53.TabIndex = 2
        Me.Guna2HtmlLabel53.Text = "ENTER SCORE FOR PROGRAMMING LANGUAGE USING JAVA II" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore" & _
            " color/>"
        '
        'sws210_txt
        '
        Me.sws210_txt.BackColor = System.Drawing.Color.White
        Me.sws210_txt.BorderRadius = 10
        Me.sws210_txt.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.sws210_txt.BorderThickness = 0
        Me.sws210_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.sws210_txt.DefaultText = ""
        Me.sws210_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.sws210_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.sws210_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.sws210_txt.DisabledState.Parent = Me.sws210_txt
        Me.sws210_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.sws210_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.sws210_txt.FocusedState.Parent = Me.sws210_txt
        Me.sws210_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sws210_txt.ForeColor = System.Drawing.Color.Black
        Me.sws210_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.sws210_txt.HoverState.Parent = Me.sws210_txt
        Me.sws210_txt.Location = New System.Drawing.Point(606, 429)
        Me.sws210_txt.Name = "sws210_txt"
        Me.sws210_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.sws210_txt.PlaceholderText = ""
        Me.sws210_txt.SelectedText = ""
        Me.sws210_txt.ShadowDecoration.Parent = Me.sws210_txt
        Me.sws210_txt.Size = New System.Drawing.Size(200, 36)
        Me.sws210_txt.TabIndex = 25
        '
        'btnBack_ND2S1
        '
        Me.btnBack_ND2S1.CheckedState.Parent = Me.btnBack_ND2S1
        Me.btnBack_ND2S1.CustomImages.Parent = Me.btnBack_ND2S1
        Me.btnBack_ND2S1.FillColor = System.Drawing.Color.Gray
        Me.btnBack_ND2S1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack_ND2S1.ForeColor = System.Drawing.Color.White
        Me.btnBack_ND2S1.HoverState.Parent = Me.btnBack_ND2S1
        Me.btnBack_ND2S1.Location = New System.Drawing.Point(873, 551)
        Me.btnBack_ND2S1.Name = "btnBack_ND2S1"
        Me.btnBack_ND2S1.ShadowDecoration.Parent = Me.btnBack_ND2S1
        Me.btnBack_ND2S1.Size = New System.Drawing.Size(133, 45)
        Me.btnBack_ND2S1.TabIndex = 37
        Me.btnBack_ND2S1.Text = "BACK TO MAIN "
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.Silver
        Me.Guna2Panel2.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button3)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button19)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel55)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel56)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel57)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel58)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox12)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox13)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox14)
        Me.Guna2Panel2.Controls.Add(Me.Guna2GroupBox3)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button75)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel59)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox15)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel60)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox16)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel61)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox17)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox18)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox19)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox20)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox21)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel62)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel63)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel64)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel65)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel66)
        Me.Guna2Panel2.Controls.Add(Me.Guna2TextBox22)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Button76)
        Me.Guna2Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(1320, 619)
        Me.Guna2Panel2.TabIndex = 6
        Me.Guna2Panel2.Visible = False
        '
        'Guna2Button3
        '
        Me.Guna2Button3.CheckedState.Parent = Me.Guna2Button3
        Me.Guna2Button3.CustomImages.Parent = Me.Guna2Button3
        Me.Guna2Button3.FillColor = System.Drawing.Color.DarkOrange
        Me.Guna2Button3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button3.ForeColor = System.Drawing.Color.White
        Me.Guna2Button3.HoverState.Parent = Me.Guna2Button3
        Me.Guna2Button3.Location = New System.Drawing.Point(1214, 551)
        Me.Guna2Button3.Name = "Guna2Button3"
        Me.Guna2Button3.ShadowDecoration.Parent = Me.Guna2Button3
        Me.Guna2Button3.Size = New System.Drawing.Size(90, 45)
        Me.Guna2Button3.TabIndex = 36
        Me.Guna2Button3.Text = "CLEAR"
        '
        'Guna2Button19
        '
        Me.Guna2Button19.CheckedState.Parent = Me.Guna2Button19
        Me.Guna2Button19.CustomImages.Parent = Me.Guna2Button19
        Me.Guna2Button19.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2Button19.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button19.ForeColor = System.Drawing.Color.White
        Me.Guna2Button19.HoverState.Parent = Me.Guna2Button19
        Me.Guna2Button19.Location = New System.Drawing.Point(1056, 551)
        Me.Guna2Button19.Name = "Guna2Button19"
        Me.Guna2Button19.ShadowDecoration.Parent = Me.Guna2Button19
        Me.Guna2Button19.Size = New System.Drawing.Size(90, 45)
        Me.Guna2Button19.TabIndex = 35
        Me.Guna2Button19.Text = "EXIT"
        '
        'Guna2HtmlLabel55
        '
        Me.Guna2HtmlLabel55.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel55.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel55.ForeColor = System.Drawing.Color.Navy
        Me.Guna2HtmlLabel55.Location = New System.Drawing.Point(457, 34)
        Me.Guna2HtmlLabel55.Name = "Guna2HtmlLabel55"
        Me.Guna2HtmlLabel55.Size = New System.Drawing.Size(197, 22)
        Me.Guna2HtmlLabel55.TabIndex = 34
        Me.Guna2HtmlLabel55.Text = "ND1 FIRST SEMESTER"
        '
        'Guna2HtmlLabel56
        '
        Me.Guna2HtmlLabel56.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel56.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel56.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel56.Location = New System.Drawing.Point(605, 493)
        Me.Guna2HtmlLabel56.Name = "Guna2HtmlLabel56"
        Me.Guna2HtmlLabel56.Size = New System.Drawing.Size(191, 20)
        Me.Guna2HtmlLabel56.TabIndex = 33
        Me.Guna2HtmlLabel56.Text = "TOTAL SCORE POINT:  <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel57
        '
        Me.Guna2HtmlLabel57.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel57.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel57.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel57.Location = New System.Drawing.Point(323, 493)
        Me.Guna2HtmlLabel57.Name = "Guna2HtmlLabel57"
        Me.Guna2HtmlLabel57.Size = New System.Drawing.Size(133, 20)
        Me.Guna2HtmlLabel57.TabIndex = 32
        Me.Guna2HtmlLabel57.Text = "GRADE POINT: <fore color = ""red"">*</fore color/>"
        Me.Guna2HtmlLabel57.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Guna2HtmlLabel58
        '
        Me.Guna2HtmlLabel58.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel58.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel58.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel58.Location = New System.Drawing.Point(50, 493)
        Me.Guna2HtmlLabel58.Name = "Guna2HtmlLabel58"
        Me.Guna2HtmlLabel58.Size = New System.Drawing.Size(78, 20)
        Me.Guna2HtmlLabel58.TabIndex = 31
        Me.Guna2HtmlLabel58.Text = "GRADE: <fore color = ""red"">*</fore color/>"
        '
        'Guna2TextBox12
        '
        Me.Guna2TextBox12.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox12.BorderRadius = 10
        Me.Guna2TextBox12.BorderThickness = 0
        Me.Guna2TextBox12.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox12.DefaultText = ""
        Me.Guna2TextBox12.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox12.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox12.DisabledState.Parent = Me.Guna2TextBox12
        Me.Guna2TextBox12.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox12.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox12.FocusedState.Parent = Me.Guna2TextBox12
        Me.Guna2TextBox12.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox12.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox12.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox12.HoverState.Parent = Me.Guna2TextBox12
        Me.Guna2TextBox12.Location = New System.Drawing.Point(37, 538)
        Me.Guna2TextBox12.Name = "Guna2TextBox12"
        Me.Guna2TextBox12.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox12.PlaceholderText = ""
        Me.Guna2TextBox12.SelectedText = ""
        Me.Guna2TextBox12.ShadowDecoration.Parent = Me.Guna2TextBox12
        Me.Guna2TextBox12.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox12.TabIndex = 30
        '
        'Guna2TextBox13
        '
        Me.Guna2TextBox13.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox13.BorderRadius = 10
        Me.Guna2TextBox13.BorderThickness = 0
        Me.Guna2TextBox13.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox13.DefaultText = ""
        Me.Guna2TextBox13.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox13.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox13.DisabledState.Parent = Me.Guna2TextBox13
        Me.Guna2TextBox13.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox13.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox13.FocusedState.Parent = Me.Guna2TextBox13
        Me.Guna2TextBox13.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox13.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox13.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox13.HoverState.Parent = Me.Guna2TextBox13
        Me.Guna2TextBox13.Location = New System.Drawing.Point(323, 538)
        Me.Guna2TextBox13.Name = "Guna2TextBox13"
        Me.Guna2TextBox13.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox13.PlaceholderText = ""
        Me.Guna2TextBox13.SelectedText = ""
        Me.Guna2TextBox13.ShadowDecoration.Parent = Me.Guna2TextBox13
        Me.Guna2TextBox13.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox13.TabIndex = 29
        '
        'Guna2TextBox14
        '
        Me.Guna2TextBox14.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox14.BorderRadius = 10
        Me.Guna2TextBox14.BorderThickness = 0
        Me.Guna2TextBox14.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox14.DefaultText = ""
        Me.Guna2TextBox14.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox14.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox14.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox14.DisabledState.Parent = Me.Guna2TextBox14
        Me.Guna2TextBox14.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox14.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox14.FocusedState.Parent = Me.Guna2TextBox14
        Me.Guna2TextBox14.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox14.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox14.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox14.HoverState.Parent = Me.Guna2TextBox14
        Me.Guna2TextBox14.Location = New System.Drawing.Point(605, 538)
        Me.Guna2TextBox14.Name = "Guna2TextBox14"
        Me.Guna2TextBox14.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox14.PlaceholderText = ""
        Me.Guna2TextBox14.SelectedText = ""
        Me.Guna2TextBox14.ShadowDecoration.Parent = Me.Guna2TextBox14
        Me.Guna2TextBox14.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox14.TabIndex = 28
        '
        'Guna2GroupBox3
        '
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button21)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button22)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button40)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button41)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button63)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button64)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button65)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button66)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button67)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button68)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button69)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button70)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button71)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button72)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button73)
        Me.Guna2GroupBox3.Controls.Add(Me.Guna2Button74)
        Me.Guna2GroupBox3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox3.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox3.Location = New System.Drawing.Point(1000, 34)
        Me.Guna2GroupBox3.Name = "Guna2GroupBox3"
        Me.Guna2GroupBox3.ShadowDecoration.Parent = Me.Guna2GroupBox3
        Me.Guna2GroupBox3.Size = New System.Drawing.Size(300, 484)
        Me.Guna2GroupBox3.TabIndex = 27
        Me.Guna2GroupBox3.Text = " COURSE UNIT"
        '
        'Guna2Button21
        '
        Me.Guna2Button21.CheckedState.Parent = Me.Guna2Button21
        Me.Guna2Button21.CustomImages.Parent = Me.Guna2Button21
        Me.Guna2Button21.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button21.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button21.ForeColor = System.Drawing.Color.White
        Me.Guna2Button21.HoverState.Parent = Me.Guna2Button21
        Me.Guna2Button21.Location = New System.Drawing.Point(214, 432)
        Me.Guna2Button21.Name = "Guna2Button21"
        Me.Guna2Button21.ShadowDecoration.Parent = Me.Guna2Button21
        Me.Guna2Button21.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button21.TabIndex = 15
        Me.Guna2Button21.Text = "2"
        '
        'Guna2Button22
        '
        Me.Guna2Button22.CheckedState.Parent = Me.Guna2Button22
        Me.Guna2Button22.CustomImages.Parent = Me.Guna2Button22
        Me.Guna2Button22.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button22.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button22.ForeColor = System.Drawing.Color.White
        Me.Guna2Button22.HoverState.Parent = Me.Guna2Button22
        Me.Guna2Button22.Location = New System.Drawing.Point(214, 379)
        Me.Guna2Button22.Name = "Guna2Button22"
        Me.Guna2Button22.ShadowDecoration.Parent = Me.Guna2Button22
        Me.Guna2Button22.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button22.TabIndex = 14
        Me.Guna2Button22.Text = "2"
        '
        'Guna2Button40
        '
        Me.Guna2Button40.CheckedState.Parent = Me.Guna2Button40
        Me.Guna2Button40.CustomImages.Parent = Me.Guna2Button40
        Me.Guna2Button40.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button40.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button40.ForeColor = System.Drawing.Color.White
        Me.Guna2Button40.HoverState.Parent = Me.Guna2Button40
        Me.Guna2Button40.Location = New System.Drawing.Point(12, 434)
        Me.Guna2Button40.Name = "Guna2Button40"
        Me.Guna2Button40.ShadowDecoration.Parent = Me.Guna2Button40
        Me.Guna2Button40.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button40.TabIndex = 13
        Me.Guna2Button40.Text = "MTH111"
        '
        'Guna2Button41
        '
        Me.Guna2Button41.CheckedState.Parent = Me.Guna2Button41
        Me.Guna2Button41.CustomImages.Parent = Me.Guna2Button41
        Me.Guna2Button41.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button41.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button41.ForeColor = System.Drawing.Color.White
        Me.Guna2Button41.HoverState.Parent = Me.Guna2Button41
        Me.Guna2Button41.Location = New System.Drawing.Point(12, 379)
        Me.Guna2Button41.Name = "Guna2Button41"
        Me.Guna2Button41.ShadowDecoration.Parent = Me.Guna2Button41
        Me.Guna2Button41.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button41.TabIndex = 12
        Me.Guna2Button41.Text = "GNS111"
        '
        'Guna2Button63
        '
        Me.Guna2Button63.CheckedState.Parent = Me.Guna2Button63
        Me.Guna2Button63.CustomImages.Parent = Me.Guna2Button63
        Me.Guna2Button63.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button63.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button63.ForeColor = System.Drawing.Color.White
        Me.Guna2Button63.HoverState.Parent = Me.Guna2Button63
        Me.Guna2Button63.Location = New System.Drawing.Point(214, 103)
        Me.Guna2Button63.Name = "Guna2Button63"
        Me.Guna2Button63.ShadowDecoration.Parent = Me.Guna2Button63
        Me.Guna2Button63.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button63.TabIndex = 11
        Me.Guna2Button63.Text = "3"
        '
        'Guna2Button64
        '
        Me.Guna2Button64.CheckedState.Parent = Me.Guna2Button64
        Me.Guna2Button64.CustomImages.Parent = Me.Guna2Button64
        Me.Guna2Button64.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button64.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button64.ForeColor = System.Drawing.Color.White
        Me.Guna2Button64.HoverState.Parent = Me.Guna2Button64
        Me.Guna2Button64.Location = New System.Drawing.Point(214, 154)
        Me.Guna2Button64.Name = "Guna2Button64"
        Me.Guna2Button64.ShadowDecoration.Parent = Me.Guna2Button64
        Me.Guna2Button64.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button64.TabIndex = 10
        Me.Guna2Button64.Text = "3"
        '
        'Guna2Button65
        '
        Me.Guna2Button65.CheckedState.Parent = Me.Guna2Button65
        Me.Guna2Button65.CustomImages.Parent = Me.Guna2Button65
        Me.Guna2Button65.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button65.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button65.ForeColor = System.Drawing.Color.White
        Me.Guna2Button65.HoverState.Parent = Me.Guna2Button65
        Me.Guna2Button65.Location = New System.Drawing.Point(214, 263)
        Me.Guna2Button65.Name = "Guna2Button65"
        Me.Guna2Button65.ShadowDecoration.Parent = Me.Guna2Button65
        Me.Guna2Button65.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button65.TabIndex = 8
        Me.Guna2Button65.Text = "3"
        '
        'Guna2Button66
        '
        Me.Guna2Button66.CheckedState.Parent = Me.Guna2Button66
        Me.Guna2Button66.CustomImages.Parent = Me.Guna2Button66
        Me.Guna2Button66.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button66.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button66.ForeColor = System.Drawing.Color.White
        Me.Guna2Button66.HoverState.Parent = Me.Guna2Button66
        Me.Guna2Button66.Location = New System.Drawing.Point(214, 319)
        Me.Guna2Button66.Name = "Guna2Button66"
        Me.Guna2Button66.ShadowDecoration.Parent = Me.Guna2Button66
        Me.Guna2Button66.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button66.TabIndex = 7
        Me.Guna2Button66.Text = "2"
        '
        'Guna2Button67
        '
        Me.Guna2Button67.CheckedState.Parent = Me.Guna2Button67
        Me.Guna2Button67.CustomImages.Parent = Me.Guna2Button67
        Me.Guna2Button67.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button67.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button67.ForeColor = System.Drawing.Color.White
        Me.Guna2Button67.HoverState.Parent = Me.Guna2Button67
        Me.Guna2Button67.Location = New System.Drawing.Point(214, 52)
        Me.Guna2Button67.Name = "Guna2Button67"
        Me.Guna2Button67.ShadowDecoration.Parent = Me.Guna2Button67
        Me.Guna2Button67.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button67.TabIndex = 6
        Me.Guna2Button67.Text = "3"
        '
        'Guna2Button68
        '
        Me.Guna2Button68.CheckedState.Parent = Me.Guna2Button68
        Me.Guna2Button68.CustomImages.Parent = Me.Guna2Button68
        Me.Guna2Button68.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button68.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button68.ForeColor = System.Drawing.Color.White
        Me.Guna2Button68.HoverState.Parent = Me.Guna2Button68
        Me.Guna2Button68.Location = New System.Drawing.Point(12, 321)
        Me.Guna2Button68.Name = "Guna2Button68"
        Me.Guna2Button68.ShadowDecoration.Parent = Me.Guna2Button68
        Me.Guna2Button68.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button68.TabIndex = 5
        Me.Guna2Button68.Text = "GNS101"
        '
        'Guna2Button69
        '
        Me.Guna2Button69.CheckedState.Parent = Me.Guna2Button69
        Me.Guna2Button69.CustomImages.Parent = Me.Guna2Button69
        Me.Guna2Button69.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button69.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button69.ForeColor = System.Drawing.Color.White
        Me.Guna2Button69.HoverState.Parent = Me.Guna2Button69
        Me.Guna2Button69.Location = New System.Drawing.Point(12, 266)
        Me.Guna2Button69.Name = "Guna2Button69"
        Me.Guna2Button69.ShadowDecoration.Parent = Me.Guna2Button69
        Me.Guna2Button69.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button69.TabIndex = 4
        Me.Guna2Button69.Text = "COM115"
        '
        'Guna2Button70
        '
        Me.Guna2Button70.CheckedState.Parent = Me.Guna2Button70
        Me.Guna2Button70.CustomImages.Parent = Me.Guna2Button70
        Me.Guna2Button70.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button70.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button70.ForeColor = System.Drawing.Color.White
        Me.Guna2Button70.HoverState.Parent = Me.Guna2Button70
        Me.Guna2Button70.Location = New System.Drawing.Point(12, 102)
        Me.Guna2Button70.Name = "Guna2Button70"
        Me.Guna2Button70.ShadowDecoration.Parent = Me.Guna2Button70
        Me.Guna2Button70.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button70.TabIndex = 3
        Me.Guna2Button70.Text = "COM112"
        '
        'Guna2Button71
        '
        Me.Guna2Button71.CheckedState.Parent = Me.Guna2Button71
        Me.Guna2Button71.CustomImages.Parent = Me.Guna2Button71
        Me.Guna2Button71.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button71.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button71.ForeColor = System.Drawing.Color.White
        Me.Guna2Button71.HoverState.Parent = Me.Guna2Button71
        Me.Guna2Button71.Location = New System.Drawing.Point(12, 157)
        Me.Guna2Button71.Name = "Guna2Button71"
        Me.Guna2Button71.ShadowDecoration.Parent = Me.Guna2Button71
        Me.Guna2Button71.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button71.TabIndex = 2
        Me.Guna2Button71.Text = "COM113"
        '
        'Guna2Button72
        '
        Me.Guna2Button72.CheckedState.Parent = Me.Guna2Button72
        Me.Guna2Button72.CustomImages.Parent = Me.Guna2Button72
        Me.Guna2Button72.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button72.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button72.ForeColor = System.Drawing.Color.White
        Me.Guna2Button72.HoverState.Parent = Me.Guna2Button72
        Me.Guna2Button72.Location = New System.Drawing.Point(12, 212)
        Me.Guna2Button72.Name = "Guna2Button72"
        Me.Guna2Button72.ShadowDecoration.Parent = Me.Guna2Button72
        Me.Guna2Button72.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button72.TabIndex = 1
        Me.Guna2Button72.Text = "COM114"
        '
        'Guna2Button73
        '
        Me.Guna2Button73.CheckedState.Parent = Me.Guna2Button73
        Me.Guna2Button73.CustomImages.Parent = Me.Guna2Button73
        Me.Guna2Button73.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button73.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button73.ForeColor = System.Drawing.Color.White
        Me.Guna2Button73.HoverState.Parent = Me.Guna2Button73
        Me.Guna2Button73.Location = New System.Drawing.Point(12, 47)
        Me.Guna2Button73.Name = "Guna2Button73"
        Me.Guna2Button73.ShadowDecoration.Parent = Me.Guna2Button73
        Me.Guna2Button73.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button73.TabIndex = 0
        Me.Guna2Button73.Text = "COM111"
        '
        'Guna2Button74
        '
        Me.Guna2Button74.CheckedState.Parent = Me.Guna2Button74
        Me.Guna2Button74.CustomImages.Parent = Me.Guna2Button74
        Me.Guna2Button74.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button74.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button74.ForeColor = System.Drawing.Color.White
        Me.Guna2Button74.HoverState.Parent = Me.Guna2Button74
        Me.Guna2Button74.Location = New System.Drawing.Point(214, 208)
        Me.Guna2Button74.Name = "Guna2Button74"
        Me.Guna2Button74.ShadowDecoration.Parent = Me.Guna2Button74
        Me.Guna2Button74.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button74.TabIndex = 9
        Me.Guna2Button74.Text = "2"
        '
        'Guna2Button75
        '
        Me.Guna2Button75.CheckedState.Parent = Me.Guna2Button75
        Me.Guna2Button75.CustomImages.Parent = Me.Guna2Button75
        Me.Guna2Button75.FillColor = System.Drawing.Color.Green
        Me.Guna2Button75.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button75.ForeColor = System.Drawing.Color.White
        Me.Guna2Button75.HoverState.Parent = Me.Guna2Button75
        Me.Guna2Button75.Location = New System.Drawing.Point(339, 442)
        Me.Guna2Button75.Name = "Guna2Button75"
        Me.Guna2Button75.ShadowDecoration.Parent = Me.Guna2Button75
        Me.Guna2Button75.Size = New System.Drawing.Size(180, 45)
        Me.Guna2Button75.TabIndex = 26
        Me.Guna2Button75.Text = "CALCULATE"
        '
        'Guna2HtmlLabel59
        '
        Me.Guna2HtmlLabel59.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel59.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel59.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel59.Location = New System.Drawing.Point(579, 392)
        Me.Guna2HtmlLabel59.Name = "Guna2HtmlLabel59"
        Me.Guna2HtmlLabel59.Size = New System.Drawing.Size(380, 18)
        Me.Guna2HtmlLabel59.TabIndex = 24
        Me.Guna2HtmlLabel59.Text = "ENTER SCORE FOR    LOGIC AND LINEAR ALGEBRA" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore " & _
            "color/>"
        '
        'Guna2TextBox15
        '
        Me.Guna2TextBox15.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox15.BorderRadius = 10
        Me.Guna2TextBox15.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.Guna2TextBox15.BorderThickness = 0
        Me.Guna2TextBox15.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox15.DefaultText = ""
        Me.Guna2TextBox15.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox15.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox15.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox15.DisabledState.Parent = Me.Guna2TextBox15
        Me.Guna2TextBox15.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox15.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox15.FocusedState.Parent = Me.Guna2TextBox15
        Me.Guna2TextBox15.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox15.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox15.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox15.HoverState.Parent = Me.Guna2TextBox15
        Me.Guna2TextBox15.Location = New System.Drawing.Point(614, 325)
        Me.Guna2TextBox15.Name = "Guna2TextBox15"
        Me.Guna2TextBox15.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox15.PlaceholderText = ""
        Me.Guna2TextBox15.SelectedText = ""
        Me.Guna2TextBox15.ShadowDecoration.Parent = Me.Guna2TextBox15
        Me.Guna2TextBox15.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox15.TabIndex = 23
        '
        'Guna2HtmlLabel60
        '
        Me.Guna2HtmlLabel60.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel60.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel60.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel60.Location = New System.Drawing.Point(566, 281)
        Me.Guna2HtmlLabel60.Name = "Guna2HtmlLabel60"
        Me.Guna2HtmlLabel60.Size = New System.Drawing.Size(361, 18)
        Me.Guna2HtmlLabel60.TabIndex = 22
        Me.Guna2HtmlLabel60.Text = "ENTER SCORE FOR   CITIZENSHIP EDUCATION I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore colo" & _
            "r/>"
        '
        'Guna2TextBox16
        '
        Me.Guna2TextBox16.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox16.BorderRadius = 10
        Me.Guna2TextBox16.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.Guna2TextBox16.BorderThickness = 0
        Me.Guna2TextBox16.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox16.DefaultText = ""
        Me.Guna2TextBox16.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox16.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox16.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox16.DisabledState.Parent = Me.Guna2TextBox16
        Me.Guna2TextBox16.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox16.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox16.FocusedState.Parent = Me.Guna2TextBox16
        Me.Guna2TextBox16.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox16.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox16.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox16.HoverState.Parent = Me.Guna2TextBox16
        Me.Guna2TextBox16.Location = New System.Drawing.Point(614, 217)
        Me.Guna2TextBox16.Name = "Guna2TextBox16"
        Me.Guna2TextBox16.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox16.PlaceholderText = ""
        Me.Guna2TextBox16.SelectedText = ""
        Me.Guna2TextBox16.ShadowDecoration.Parent = Me.Guna2TextBox16
        Me.Guna2TextBox16.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox16.TabIndex = 21
        '
        'Guna2HtmlLabel61
        '
        Me.Guna2HtmlLabel61.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel61.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel61.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel61.Location = New System.Drawing.Point(579, 176)
        Me.Guna2HtmlLabel61.Name = "Guna2HtmlLabel61"
        Me.Guna2HtmlLabel61.Size = New System.Drawing.Size(300, 18)
        Me.Guna2HtmlLabel61.TabIndex = 20
        Me.Guna2HtmlLabel61.Text = "ENTER SCORE FOR  USE OF ENGLISH I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/>"
        '
        'Guna2TextBox17
        '
        Me.Guna2TextBox17.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox17.BorderRadius = 10
        Me.Guna2TextBox17.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.Guna2TextBox17.BorderThickness = 0
        Me.Guna2TextBox17.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox17.DefaultText = ""
        Me.Guna2TextBox17.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox17.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox17.DisabledState.Parent = Me.Guna2TextBox17
        Me.Guna2TextBox17.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox17.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox17.FocusedState.Parent = Me.Guna2TextBox17
        Me.Guna2TextBox17.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox17.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox17.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox17.HoverState.Parent = Me.Guna2TextBox17
        Me.Guna2TextBox17.Location = New System.Drawing.Point(614, 120)
        Me.Guna2TextBox17.Name = "Guna2TextBox17"
        Me.Guna2TextBox17.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox17.PlaceholderText = ""
        Me.Guna2TextBox17.SelectedText = ""
        Me.Guna2TextBox17.ShadowDecoration.Parent = Me.Guna2TextBox17
        Me.Guna2TextBox17.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox17.TabIndex = 19
        '
        'Guna2TextBox18
        '
        Me.Guna2TextBox18.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox18.BorderRadius = 10
        Me.Guna2TextBox18.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.Guna2TextBox18.BorderThickness = 0
        Me.Guna2TextBox18.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox18.DefaultText = ""
        Me.Guna2TextBox18.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox18.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox18.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox18.DisabledState.Parent = Me.Guna2TextBox18
        Me.Guna2TextBox18.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox18.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox18.FocusedState.Parent = Me.Guna2TextBox18
        Me.Guna2TextBox18.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox18.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox18.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox18.HoverState.Parent = Me.Guna2TextBox18
        Me.Guna2TextBox18.Location = New System.Drawing.Point(37, 430)
        Me.Guna2TextBox18.Name = "Guna2TextBox18"
        Me.Guna2TextBox18.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox18.PlaceholderText = ""
        Me.Guna2TextBox18.SelectedText = ""
        Me.Guna2TextBox18.ShadowDecoration.Parent = Me.Guna2TextBox18
        Me.Guna2TextBox18.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox18.TabIndex = 18
        '
        'Guna2TextBox19
        '
        Me.Guna2TextBox19.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox19.BorderRadius = 10
        Me.Guna2TextBox19.BorderThickness = 0
        Me.Guna2TextBox19.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox19.DefaultText = ""
        Me.Guna2TextBox19.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox19.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox19.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox19.DisabledState.Parent = Me.Guna2TextBox19
        Me.Guna2TextBox19.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox19.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox19.FocusedState.Parent = Me.Guna2TextBox19
        Me.Guna2TextBox19.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox19.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox19.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox19.HoverState.Parent = Me.Guna2TextBox19
        Me.Guna2TextBox19.Location = New System.Drawing.Point(37, 325)
        Me.Guna2TextBox19.Name = "Guna2TextBox19"
        Me.Guna2TextBox19.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox19.PlaceholderText = ""
        Me.Guna2TextBox19.SelectedText = ""
        Me.Guna2TextBox19.ShadowDecoration.Parent = Me.Guna2TextBox19
        Me.Guna2TextBox19.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox19.TabIndex = 17
        '
        'Guna2TextBox20
        '
        Me.Guna2TextBox20.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox20.BorderRadius = 10
        Me.Guna2TextBox20.BorderThickness = 0
        Me.Guna2TextBox20.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox20.DefaultText = ""
        Me.Guna2TextBox20.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox20.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox20.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox20.DisabledState.Parent = Me.Guna2TextBox20
        Me.Guna2TextBox20.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox20.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox20.FocusedState.Parent = Me.Guna2TextBox20
        Me.Guna2TextBox20.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox20.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox20.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox20.HoverState.Parent = Me.Guna2TextBox20
        Me.Guna2TextBox20.Location = New System.Drawing.Point(37, 230)
        Me.Guna2TextBox20.Name = "Guna2TextBox20"
        Me.Guna2TextBox20.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox20.PlaceholderText = ""
        Me.Guna2TextBox20.SelectedText = ""
        Me.Guna2TextBox20.ShadowDecoration.Parent = Me.Guna2TextBox20
        Me.Guna2TextBox20.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox20.TabIndex = 16
        '
        'Guna2TextBox21
        '
        Me.Guna2TextBox21.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox21.BorderRadius = 10
        Me.Guna2TextBox21.BorderThickness = 0
        Me.Guna2TextBox21.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox21.DefaultText = ""
        Me.Guna2TextBox21.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox21.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox21.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox21.DisabledState.Parent = Me.Guna2TextBox21
        Me.Guna2TextBox21.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox21.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox21.FocusedState.Parent = Me.Guna2TextBox21
        Me.Guna2TextBox21.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox21.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox21.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox21.HoverState.Parent = Me.Guna2TextBox21
        Me.Guna2TextBox21.Location = New System.Drawing.Point(37, 120)
        Me.Guna2TextBox21.Name = "Guna2TextBox21"
        Me.Guna2TextBox21.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox21.PlaceholderText = ""
        Me.Guna2TextBox21.SelectedText = ""
        Me.Guna2TextBox21.ShadowDecoration.Parent = Me.Guna2TextBox21
        Me.Guna2TextBox21.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox21.TabIndex = 15
        '
        'Guna2HtmlLabel62
        '
        Me.Guna2HtmlLabel62.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel62.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel62.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel62.Location = New System.Drawing.Point(529, 85)
        Me.Guna2HtmlLabel62.Name = "Guna2HtmlLabel62"
        Me.Guna2HtmlLabel62.Size = New System.Drawing.Size(447, 18)
        Me.Guna2HtmlLabel62.TabIndex = 14
        Me.Guna2HtmlLabel62.Text = "ENTER SCORE FOR COMPUTER APPLICATION PACKAGES I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore co" & _
            "lor/>"
        '
        'Guna2HtmlLabel63
        '
        Me.Guna2HtmlLabel63.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel63.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel63.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel63.Location = New System.Drawing.Point(13, 392)
        Me.Guna2HtmlLabel63.Name = "Guna2HtmlLabel63"
        Me.Guna2HtmlLabel63.Size = New System.Drawing.Size(393, 18)
        Me.Guna2HtmlLabel63.TabIndex = 13
        Me.Guna2HtmlLabel63.Text = "ENTER SCORE FOR STATISTICS FOR COMPUTING I " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ": <fore color = ""red"">*</fore color/" & _
            ">"
        '
        'Guna2HtmlLabel64
        '
        Me.Guna2HtmlLabel64.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel64.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel64.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel64.Location = New System.Drawing.Point(25, 281)
        Me.Guna2HtmlLabel64.Name = "Guna2HtmlLabel64"
        Me.Guna2HtmlLabel64.Size = New System.Drawing.Size(422, 18)
        Me.Guna2HtmlLabel64.TabIndex = 11
        Me.Guna2HtmlLabel64.Text = "ENTER SCORE FOR INTRODUCTION TO PROGRAMMING: <fore color = ""red"">*</fore color/>"
        '
        'Guna2HtmlLabel65
        '
        Me.Guna2HtmlLabel65.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel65.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel65.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel65.Location = New System.Drawing.Point(37, 176)
        Me.Guna2HtmlLabel65.Name = "Guna2HtmlLabel65"
        Me.Guna2HtmlLabel65.Size = New System.Drawing.Size(475, 18)
        Me.Guna2HtmlLabel65.TabIndex = 9
        Me.Guna2HtmlLabel65.Text = "ENTER SCORE FOR INTRODUCTION TO DIGITAL ELECTRONICS: <fore color = ""red"">*</fore " & _
            "color/>"
        '
        'Guna2HtmlLabel66
        '
        Me.Guna2HtmlLabel66.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel66.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel66.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel66.Location = New System.Drawing.Point(25, 85)
        Me.Guna2HtmlLabel66.Name = "Guna2HtmlLabel66"
        Me.Guna2HtmlLabel66.Size = New System.Drawing.Size(398, 18)
        Me.Guna2HtmlLabel66.TabIndex = 2
        Me.Guna2HtmlLabel66.Text = "ENTER SCORE FOR INTRODUCTION TO COMPUTING: <fore color = ""red"">*</fore color/>"
        '
        'Guna2TextBox22
        '
        Me.Guna2TextBox22.BackColor = System.Drawing.Color.White
        Me.Guna2TextBox22.BorderRadius = 10
        Me.Guna2TextBox22.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom
        Me.Guna2TextBox22.BorderThickness = 0
        Me.Guna2TextBox22.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox22.DefaultText = ""
        Me.Guna2TextBox22.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox22.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox22.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox22.DisabledState.Parent = Me.Guna2TextBox22
        Me.Guna2TextBox22.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox22.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox22.FocusedState.Parent = Me.Guna2TextBox22
        Me.Guna2TextBox22.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2TextBox22.ForeColor = System.Drawing.Color.Black
        Me.Guna2TextBox22.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox22.HoverState.Parent = Me.Guna2TextBox22
        Me.Guna2TextBox22.Location = New System.Drawing.Point(614, 416)
        Me.Guna2TextBox22.Name = "Guna2TextBox22"
        Me.Guna2TextBox22.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox22.PlaceholderText = ""
        Me.Guna2TextBox22.SelectedText = ""
        Me.Guna2TextBox22.ShadowDecoration.Parent = Me.Guna2TextBox22
        Me.Guna2TextBox22.Size = New System.Drawing.Size(200, 36)
        Me.Guna2TextBox22.TabIndex = 25
        '
        'Guna2Button76
        '
        Me.Guna2Button76.CheckedState.Parent = Me.Guna2Button76
        Me.Guna2Button76.CustomImages.Parent = Me.Guna2Button76
        Me.Guna2Button76.FillColor = System.Drawing.Color.Gray
        Me.Guna2Button76.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button76.ForeColor = System.Drawing.Color.White
        Me.Guna2Button76.HoverState.Parent = Me.Guna2Button76
        Me.Guna2Button76.Location = New System.Drawing.Point(873, 551)
        Me.Guna2Button76.Name = "Guna2Button76"
        Me.Guna2Button76.ShadowDecoration.Parent = Me.Guna2Button76
        Me.Guna2Button76.Size = New System.Drawing.Size(133, 45)
        Me.Guna2Button76.TabIndex = 37
        Me.Guna2Button76.Text = "BACK TO MAIN "
        '
        'Guna2GroupBox4
        '
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button91)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button90)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button89)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button88)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button4)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button37)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button42)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button59)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button60)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button77)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button78)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button79)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button80)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button81)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button82)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button83)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button84)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button85)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button86)
        Me.Guna2GroupBox4.Controls.Add(Me.Guna2Button87)
        Me.Guna2GroupBox4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox4.Location = New System.Drawing.Point(1004, 9)
        Me.Guna2GroupBox4.Name = "Guna2GroupBox4"
        Me.Guna2GroupBox4.ShadowDecoration.Parent = Me.Guna2GroupBox4
        Me.Guna2GroupBox4.Size = New System.Drawing.Size(300, 552)
        Me.Guna2GroupBox4.TabIndex = 42
        Me.Guna2GroupBox4.Text = " COURSE UNIT"
        '
        'Guna2Button4
        '
        Me.Guna2Button4.CheckedState.Parent = Me.Guna2Button4
        Me.Guna2Button4.CustomImages.Parent = Me.Guna2Button4
        Me.Guna2Button4.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button4.ForeColor = System.Drawing.Color.White
        Me.Guna2Button4.HoverState.Parent = Me.Guna2Button4
        Me.Guna2Button4.Location = New System.Drawing.Point(214, 398)
        Me.Guna2Button4.Name = "Guna2Button4"
        Me.Guna2Button4.ShadowDecoration.Parent = Me.Guna2Button4
        Me.Guna2Button4.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button4.TabIndex = 15
        Me.Guna2Button4.Text = "2"
        '
        'Guna2Button37
        '
        Me.Guna2Button37.CheckedState.Parent = Me.Guna2Button37
        Me.Guna2Button37.CustomImages.Parent = Me.Guna2Button37
        Me.Guna2Button37.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button37.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button37.ForeColor = System.Drawing.Color.White
        Me.Guna2Button37.HoverState.Parent = Me.Guna2Button37
        Me.Guna2Button37.Location = New System.Drawing.Point(214, 346)
        Me.Guna2Button37.Name = "Guna2Button37"
        Me.Guna2Button37.ShadowDecoration.Parent = Me.Guna2Button37
        Me.Guna2Button37.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button37.TabIndex = 14
        Me.Guna2Button37.Text = "2"
        '
        'Guna2Button42
        '
        Me.Guna2Button42.CheckedState.Parent = Me.Guna2Button42
        Me.Guna2Button42.CustomImages.Parent = Me.Guna2Button42
        Me.Guna2Button42.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button42.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button42.ForeColor = System.Drawing.Color.White
        Me.Guna2Button42.HoverState.Parent = Me.Guna2Button42
        Me.Guna2Button42.Location = New System.Drawing.Point(12, 401)
        Me.Guna2Button42.Name = "Guna2Button42"
        Me.Guna2Button42.ShadowDecoration.Parent = Me.Guna2Button42
        Me.Guna2Button42.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button42.TabIndex = 13
        Me.Guna2Button42.Text = "GNS228"
        '
        'Guna2Button59
        '
        Me.Guna2Button59.CheckedState.Parent = Me.Guna2Button59
        Me.Guna2Button59.CustomImages.Parent = Me.Guna2Button59
        Me.Guna2Button59.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button59.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button59.ForeColor = System.Drawing.Color.White
        Me.Guna2Button59.HoverState.Parent = Me.Guna2Button59
        Me.Guna2Button59.Location = New System.Drawing.Point(12, 352)
        Me.Guna2Button59.Name = "Guna2Button59"
        Me.Guna2Button59.ShadowDecoration.Parent = Me.Guna2Button59
        Me.Guna2Button59.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button59.TabIndex = 12
        Me.Guna2Button59.Text = "EED126"
        '
        'Guna2Button60
        '
        Me.Guna2Button60.CheckedState.Parent = Me.Guna2Button60
        Me.Guna2Button60.CustomImages.Parent = Me.Guna2Button60
        Me.Guna2Button60.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button60.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button60.ForeColor = System.Drawing.Color.White
        Me.Guna2Button60.HoverState.Parent = Me.Guna2Button60
        Me.Guna2Button60.Location = New System.Drawing.Point(214, 93)
        Me.Guna2Button60.Name = "Guna2Button60"
        Me.Guna2Button60.ShadowDecoration.Parent = Me.Guna2Button60
        Me.Guna2Button60.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button60.TabIndex = 11
        Me.Guna2Button60.Text = "3"
        '
        'Guna2Button77
        '
        Me.Guna2Button77.CheckedState.Parent = Me.Guna2Button77
        Me.Guna2Button77.CustomImages.Parent = Me.Guna2Button77
        Me.Guna2Button77.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button77.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button77.ForeColor = System.Drawing.Color.White
        Me.Guna2Button77.HoverState.Parent = Me.Guna2Button77
        Me.Guna2Button77.Location = New System.Drawing.Point(213, 143)
        Me.Guna2Button77.Name = "Guna2Button77"
        Me.Guna2Button77.ShadowDecoration.Parent = Me.Guna2Button77
        Me.Guna2Button77.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button77.TabIndex = 10
        Me.Guna2Button77.Text = "3"
        '
        'Guna2Button78
        '
        Me.Guna2Button78.CheckedState.Parent = Me.Guna2Button78
        Me.Guna2Button78.CustomImages.Parent = Me.Guna2Button78
        Me.Guna2Button78.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button78.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button78.ForeColor = System.Drawing.Color.White
        Me.Guna2Button78.HoverState.Parent = Me.Guna2Button78
        Me.Guna2Button78.Location = New System.Drawing.Point(214, 192)
        Me.Guna2Button78.Name = "Guna2Button78"
        Me.Guna2Button78.ShadowDecoration.Parent = Me.Guna2Button78
        Me.Guna2Button78.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button78.TabIndex = 9
        Me.Guna2Button78.Text = "3"
        '
        'Guna2Button79
        '
        Me.Guna2Button79.CheckedState.Parent = Me.Guna2Button79
        Me.Guna2Button79.CustomImages.Parent = Me.Guna2Button79
        Me.Guna2Button79.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button79.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button79.ForeColor = System.Drawing.Color.White
        Me.Guna2Button79.HoverState.Parent = Me.Guna2Button79
        Me.Guna2Button79.Location = New System.Drawing.Point(214, 244)
        Me.Guna2Button79.Name = "Guna2Button79"
        Me.Guna2Button79.ShadowDecoration.Parent = Me.Guna2Button79
        Me.Guna2Button79.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button79.TabIndex = 8
        Me.Guna2Button79.Text = "3"
        '
        'Guna2Button80
        '
        Me.Guna2Button80.CheckedState.Parent = Me.Guna2Button80
        Me.Guna2Button80.CustomImages.Parent = Me.Guna2Button80
        Me.Guna2Button80.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button80.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button80.ForeColor = System.Drawing.Color.White
        Me.Guna2Button80.HoverState.Parent = Me.Guna2Button80
        Me.Guna2Button80.Location = New System.Drawing.Point(214, 295)
        Me.Guna2Button80.Name = "Guna2Button80"
        Me.Guna2Button80.ShadowDecoration.Parent = Me.Guna2Button80
        Me.Guna2Button80.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button80.TabIndex = 7
        Me.Guna2Button80.Text = "3"
        '
        'Guna2Button81
        '
        Me.Guna2Button81.CheckedState.Parent = Me.Guna2Button81
        Me.Guna2Button81.CustomImages.Parent = Me.Guna2Button81
        Me.Guna2Button81.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button81.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button81.ForeColor = System.Drawing.Color.White
        Me.Guna2Button81.HoverState.Parent = Me.Guna2Button81
        Me.Guna2Button81.Location = New System.Drawing.Point(214, 42)
        Me.Guna2Button81.Name = "Guna2Button81"
        Me.Guna2Button81.ShadowDecoration.Parent = Me.Guna2Button81
        Me.Guna2Button81.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button81.TabIndex = 6
        Me.Guna2Button81.Text = "3"
        '
        'Guna2Button82
        '
        Me.Guna2Button82.CheckedState.Parent = Me.Guna2Button82
        Me.Guna2Button82.CustomImages.Parent = Me.Guna2Button82
        Me.Guna2Button82.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button82.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button82.ForeColor = System.Drawing.Color.White
        Me.Guna2Button82.HoverState.Parent = Me.Guna2Button82
        Me.Guna2Button82.Location = New System.Drawing.Point(12, 301)
        Me.Guna2Button82.Name = "Guna2Button82"
        Me.Guna2Button82.ShadowDecoration.Parent = Me.Guna2Button82
        Me.Guna2Button82.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button82.TabIndex = 5
        Me.Guna2Button82.Text = "COM126"
        '
        'Guna2Button83
        '
        Me.Guna2Button83.CheckedState.Parent = Me.Guna2Button83
        Me.Guna2Button83.CustomImages.Parent = Me.Guna2Button83
        Me.Guna2Button83.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button83.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button83.ForeColor = System.Drawing.Color.White
        Me.Guna2Button83.HoverState.Parent = Me.Guna2Button83
        Me.Guna2Button83.Location = New System.Drawing.Point(12, 249)
        Me.Guna2Button83.Name = "Guna2Button83"
        Me.Guna2Button83.ShadowDecoration.Parent = Me.Guna2Button83
        Me.Guna2Button83.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button83.TabIndex = 4
        Me.Guna2Button83.Text = "COM125"
        '
        'Guna2Button84
        '
        Me.Guna2Button84.CheckedState.Parent = Me.Guna2Button84
        Me.Guna2Button84.CustomImages.Parent = Me.Guna2Button84
        Me.Guna2Button84.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button84.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button84.ForeColor = System.Drawing.Color.White
        Me.Guna2Button84.HoverState.Parent = Me.Guna2Button84
        Me.Guna2Button84.Location = New System.Drawing.Point(12, 96)
        Me.Guna2Button84.Name = "Guna2Button84"
        Me.Guna2Button84.ShadowDecoration.Parent = Me.Guna2Button84
        Me.Guna2Button84.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button84.TabIndex = 3
        Me.Guna2Button84.Text = "COM122"
        '
        'Guna2Button85
        '
        Me.Guna2Button85.CheckedState.Parent = Me.Guna2Button85
        Me.Guna2Button85.CustomImages.Parent = Me.Guna2Button85
        Me.Guna2Button85.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button85.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button85.ForeColor = System.Drawing.Color.White
        Me.Guna2Button85.HoverState.Parent = Me.Guna2Button85
        Me.Guna2Button85.Location = New System.Drawing.Point(12, 145)
        Me.Guna2Button85.Name = "Guna2Button85"
        Me.Guna2Button85.ShadowDecoration.Parent = Me.Guna2Button85
        Me.Guna2Button85.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button85.TabIndex = 2
        Me.Guna2Button85.Text = "COM123"
        '
        'Guna2Button86
        '
        Me.Guna2Button86.CheckedState.Parent = Me.Guna2Button86
        Me.Guna2Button86.CustomImages.Parent = Me.Guna2Button86
        Me.Guna2Button86.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button86.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button86.ForeColor = System.Drawing.Color.White
        Me.Guna2Button86.HoverState.Parent = Me.Guna2Button86
        Me.Guna2Button86.Location = New System.Drawing.Point(12, 196)
        Me.Guna2Button86.Name = "Guna2Button86"
        Me.Guna2Button86.ShadowDecoration.Parent = Me.Guna2Button86
        Me.Guna2Button86.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button86.TabIndex = 1
        Me.Guna2Button86.Text = "COM124"
        '
        'Guna2Button87
        '
        Me.Guna2Button87.CheckedState.Parent = Me.Guna2Button87
        Me.Guna2Button87.CustomImages.Parent = Me.Guna2Button87
        Me.Guna2Button87.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button87.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button87.ForeColor = System.Drawing.Color.White
        Me.Guna2Button87.HoverState.Parent = Me.Guna2Button87
        Me.Guna2Button87.Location = New System.Drawing.Point(12, 47)
        Me.Guna2Button87.Name = "Guna2Button87"
        Me.Guna2Button87.ShadowDecoration.Parent = Me.Guna2Button87
        Me.Guna2Button87.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button87.TabIndex = 0
        Me.Guna2Button87.Text = "COM121"
        '
        'Guna2Button88
        '
        Me.Guna2Button88.CheckedState.Parent = Me.Guna2Button88
        Me.Guna2Button88.CustomImages.Parent = Me.Guna2Button88
        Me.Guna2Button88.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button88.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button88.ForeColor = System.Drawing.Color.White
        Me.Guna2Button88.HoverState.Parent = Me.Guna2Button88
        Me.Guna2Button88.Location = New System.Drawing.Point(12, 452)
        Me.Guna2Button88.Name = "Guna2Button88"
        Me.Guna2Button88.ShadowDecoration.Parent = Me.Guna2Button88
        Me.Guna2Button88.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button88.TabIndex = 16
        Me.Guna2Button88.Text = "GNS102"
        '
        'Guna2Button89
        '
        Me.Guna2Button89.CheckedState.Parent = Me.Guna2Button89
        Me.Guna2Button89.CustomImages.Parent = Me.Guna2Button89
        Me.Guna2Button89.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button89.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button89.ForeColor = System.Drawing.Color.White
        Me.Guna2Button89.HoverState.Parent = Me.Guna2Button89
        Me.Guna2Button89.Location = New System.Drawing.Point(213, 450)
        Me.Guna2Button89.Name = "Guna2Button89"
        Me.Guna2Button89.ShadowDecoration.Parent = Me.Guna2Button89
        Me.Guna2Button89.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button89.TabIndex = 17
        Me.Guna2Button89.Text = "2"
        '
        'Guna2Button90
        '
        Me.Guna2Button90.CheckedState.Parent = Me.Guna2Button90
        Me.Guna2Button90.CustomImages.Parent = Me.Guna2Button90
        Me.Guna2Button90.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button90.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button90.ForeColor = System.Drawing.Color.White
        Me.Guna2Button90.HoverState.Parent = Me.Guna2Button90
        Me.Guna2Button90.Location = New System.Drawing.Point(12, 501)
        Me.Guna2Button90.Name = "Guna2Button90"
        Me.Guna2Button90.ShadowDecoration.Parent = Me.Guna2Button90
        Me.Guna2Button90.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button90.TabIndex = 18
        Me.Guna2Button90.Text = "GNS121"
        '
        'Guna2Button91
        '
        Me.Guna2Button91.CheckedState.Parent = Me.Guna2Button91
        Me.Guna2Button91.CustomImages.Parent = Me.Guna2Button91
        Me.Guna2Button91.FillColor = System.Drawing.Color.DarkGray
        Me.Guna2Button91.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button91.ForeColor = System.Drawing.Color.White
        Me.Guna2Button91.HoverState.Parent = Me.Guna2Button91
        Me.Guna2Button91.Location = New System.Drawing.Point(213, 501)
        Me.Guna2Button91.Name = "Guna2Button91"
        Me.Guna2Button91.ShadowDecoration.Parent = Me.Guna2Button91
        Me.Guna2Button91.Size = New System.Drawing.Size(71, 45)
        Me.Guna2Button91.TabIndex = 19
        Me.Guna2Button91.Text = "2"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGray
        Me.ClientSize = New System.Drawing.Size(1334, 661)
        Me.Controls.Add(Me.pnlND1_S2_Calculator)
        Me.Controls.Add(Me.pnlND2_S2_Calculator)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.pnlMainMenu)
        Me.Controls.Add(Me.pnlND2_S1_Calculator)
        Me.Controls.Add(Me.pnlND2Semesters)
        Me.Controls.Add(Me.pnlND1_S1_Calculator)
        Me.Controls.Add(Me.pnlND1Semesters)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.pnlMainMenu.ResumeLayout(False)
        Me.pnlMainMenu.PerformLayout()
        Me.pnlND1Semesters.ResumeLayout(False)
        Me.pnlND1Semesters.PerformLayout()
        Me.pnlND1_S1_Calculator.ResumeLayout(False)
        Me.pnlND1_S1_Calculator.PerformLayout()
        Me.GRPCOURSEUNIT.ResumeLayout(False)
        Me.pnlND1_S2_Calculator.ResumeLayout(False)
        Me.pnlND1_S2_Calculator.PerformLayout()
        Me.pnlND2Semesters.ResumeLayout(False)
        Me.pnlND2Semesters.PerformLayout()
        Me.pnlND2_S2_Calculator.ResumeLayout(False)
        Me.pnlND2_S2_Calculator.PerformLayout()
        Me.Guna2GroupBox2.ResumeLayout(False)
        Me.pnlND2_S1_Calculator.ResumeLayout(False)
        Me.pnlND2_S1_Calculator.PerformLayout()
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel2.PerformLayout()
        Me.Guna2GroupBox3.ResumeLayout(False)
        Me.Guna2GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlMainMenu As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents pnlND1Semesters As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents btnND2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnND1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnBackToMain As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnSecondSemester As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnFirstSemester As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents pnlND1_S1_Calculator As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents aa As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents com115_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com114_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com113_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com112_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com111_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents gns111_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel8 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents gns101_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents mth111_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel9 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents btnClear As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnExit As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel13 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel12 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel11 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel10 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents grade_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents gradePoint_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents totalScorePoint_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents GRPCOURSEUNIT As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2Button18 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button17 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button16 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button15 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button12 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button11 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button10 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button9 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button8 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button7 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button6 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button5 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button13 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button14 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents calculatebtn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button20 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnBackToSemester As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents pnlND1_S2_Calculator As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents btnBackToChoice_S2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnClear_S2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnExit_S2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel14 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel15 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel16 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel17 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents grade_txt_S2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents gradePoint_txt_S2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents totalScorePoint_txt_S2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents btnCalculate As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel18 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents gns228_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel19 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents eed126_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel20 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents com126_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com124_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com123_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com122_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com121_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel21 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel22 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel23 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel24 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel25 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents gns102_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com125_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel26 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents gns121_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel27 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel29 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents pnlND2Semesters As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents btnBackToMain_ND2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnND2SecondSemester As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnND2FirstSemester As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel28 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents pnlND2_S2_Calculator As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents btnClear_ND2S2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnExit_ND2S2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel30 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel31 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel32 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel33 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents grade_txt_NDS2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents gradePoint_txt_ND2S2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents totalScorePoint_txt_ND2S2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox2 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2Button43 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button44 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button45 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button46 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button47 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button48 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button49 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button50 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button51 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button52 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button53 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button54 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button55 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button56 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button57 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button58 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnCalculateND2S2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel34 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents com229_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel35 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents com226_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel36 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents com225_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com224_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com223_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com222_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com221_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel37 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel38 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel39 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel40 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel41 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents gns202_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents btnBack_ND2S2 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents pnlND2_S1_Calculator As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents btnClear_ND2S1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnExit_ND2S1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel42 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel43 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel44 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel45 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents grade_txt_ND2S1 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents gradePoint_txt_ND2S1 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents totalScorePoint_txt_ND2S1 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2Button23 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button24 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button25 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button26 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button27 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button28 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button29 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button30 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button31 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button32 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button33 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button34 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button35 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button36 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button38 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button39 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnCalculateND2S1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel46 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents gns201_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel47 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents eed216_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel48 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents com216_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com214_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com213_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com212_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents com211_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel49 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel50 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel51 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel52 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel53 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents sws210_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents btnBack_ND2S1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button62 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button61 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents com215_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel54 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Button3 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button19 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel55 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel56 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel57 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel58 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2TextBox12 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox13 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox14 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox3 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2Button21 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button22 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button40 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button41 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button63 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button64 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button65 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button66 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button67 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button68 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button69 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button70 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button71 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button72 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button73 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button74 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button75 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel59 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2TextBox15 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel60 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2TextBox16 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel61 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2TextBox17 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox18 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox19 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox20 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox21 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel62 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel63 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel64 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel65 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel66 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2TextBox22 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2Button76 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2GroupBox4 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2Button91 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button90 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button89 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button88 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button37 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button42 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button59 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button60 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button77 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button78 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button79 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button80 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button81 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button82 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button83 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button84 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button85 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button86 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button87 As Guna.UI2.WinForms.Guna2Button

End Class
